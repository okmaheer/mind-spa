# 28 — Days Between Dates

**Route:** `GET /days-between-dates`  
**File:** `resources/views/calculators/days-between-dates.blade.php`  
**Category:** Life  
**SEO Keyword:** `days between two dates` — 700,000/month  

---

## SEO

| Field | Value |
|---|---|
| Title | `Days Between Dates Calculator — Free Date Difference Tool | MindSnap` |
| Meta | `Free days between dates calculator. Find the exact number of days, weeks, months and years between any two dates. Includes business days option.` |
| H1 | `Days Between Dates — Calculate the Difference` |
| Canonical | `https://mindsnap.co/days-between-dates` |
| Category | [Life Tools](/life-tools) |

---

## What This Page Does

Days Between Dates page on MindSnap.co. Follows the standard 12-section tool page structure.

---

## Inputs

- **Start date:** date picker
- **End date:** date picker
- **Include business days only:** checkbox

---

## JavaScript Logic

```javascript
function daysBetween(startDate, endDate, businessOnly) {
  const diff = Math.abs(endDate - startDate);
  const totalDays = Math.floor(diff / 86400000);
  const weeks   = Math.floor(totalDays / 7);
  const months  = monthsBetween(startDate, endDate);
  const years   = Math.floor(months / 12);
  let businessDays = 0;
  if (businessOnly) {
    for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate()+1)) {
      if (d.getDay() !== 0 && d.getDay() !== 6) businessDays++;
    }
  }
  return { totalDays, weeks, months, years, businessDays };
}
```

---

## Result Output

Total days, weeks, months, years between dates. Business days count. Direction label (X days ago / X days from now). Example uses: 'How long until Christmas', 'How long have I been at my job'.

---

## Formula Explanation (Section 7)

Days = |End date − Start date| in milliseconds ÷ 86,400,000. Business days exclude Saturdays and Sundays (public holidays not included as they vary by country).

---

## Content Section (Section 8)

**H2:** `Calculating Time Between Dates — Common Uses`

List common uses: event countdowns, contract durations, pregnancy tracking, project planning, anniversary calculations. Tips for working with different calendar systems. ~280 words.

---

## FAQ (Section 9)

| # | Question | Answer |
|---|---|---|
| Q1 | Does this count the start and end day? | By default, the calculator counts the days between dates (exclusive of endpoints). You can include both endpoints by interpreting the result as 'including both days' which adds 1 to the total. |
| Q2 | Are weekends included in business days? | Business days exclude Saturdays and Sundays. Public holidays are not excluded as they vary by country and region. Add any applicable holidays manually for precise business day counts. |
| Q3 | Can I calculate days between dates in the past? | Yes — the calculator works for any historical or future dates. It handles leap years, month length variations, and year boundaries automatically. |
| Q4 | What is the maximum date range this handles? | This calculator handles any date range using JavaScript's Date object, which supports dates from year 100 to year 9999. The calculation remains accurate regardless of range. |
| Q5 | Is MindSnap's Days Between Dates free? | Yes — completely free, no signup, no download. Use it instantly on any device. |

---

## Related Tools (Section 10)

1. **Age Calculator** → `/age-calculator`
2. **Days Until Calculator** → `/days-until-calculator`
3. **Life Tools** → `/life-tools`

---



## Claude Prompt

```
Build the Days Between Dates page for MindSnap.co.

FILE: resources/views/calculators/days-between-dates.blade.php
ROUTE: GET /days-between-dates
CATEGORY COLOUR: #6f42c1

SEO:
Title:    "Days Between Dates Calculator — Free Date Difference Tool | MindSnap"
Meta:     "Free days between dates calculator. Find the exact number of days, weeks, months and years between any two dates. Includes business days option."
H1:       "Days Between Dates — Calculate the Difference"
Canonical: https://mindsnap.co/days-between-dates

BUILD ALL 12 SECTIONS:
1. Breadcrumb: Home > Life Tools > Days Between Dates + BreadcrumbList schema
2. H1 + 2-sentence description + trust badges (Free/No Signup/Instant/Mobile Friendly)
3. INPUT FORM:
- **Start date:** date picker
- **End date:** date picker
- **Include business days only:** checkbox
   Labels above inputs. Units toggle where applicable.
   #e94560 Calculate button, full-width mobile, min 52px height.
4. RESULT: fadeIn animation, large result in #6f42c1, interpretation text
5. SHARE CARD: canvas 420x220px, Copy/WhatsApp/Download buttons
6. HOW TO USE: H2 + 4-5 numbered steps
7. FORMULA: H2 + plain English + formula in styled box
8. CONTENT: H2 "Calculating Time Between Dates — Common Uses" + 300-400 words + 2-3 H3 subheadings
9. FAQ: H2 + Bootstrap accordion + 5 Q&As + FAQPage JSON-LD schema
10. RELATED TOOLS: 3 cards — Age Calculator, Days Until Calculator, Life Tools category page
11. CATEGORY LINK: text sentence linking back to /life-tools
12. SCHEMAS in @section('schema'):
    - WebApplication JSON-LD
    - BreadcrumbList JSON-LD  
    - FAQPage JSON-LD

VANILLA JS LOGIC:
function daysBetween(startDate, endDate, businessOnly) {
  const diff = Math.abs(endDate - startDate);
  const totalDays = Math.floor(diff / 86400000);
  const weeks   = Math.floor(totalDays / 7);
  const months  = monthsBetween(startDate, endDate);
  const years   = Math.floor(months / 12);
  let businessDays = 0;
  if (businessOnly) {
    for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate()+1)) {
      if (d.getDay() !== 0 && d.getDay() !== 6) businessDays++;
    }
  }
  return { totalDays, weeks, months, years, businessDays };
}

MOBILE: all inputs 100% width, 48px height, buttons 52px, test at 375px
PERFORMANCE: defer all JS, lazy load images
```
