# 46 — Kids Zone Homepage

**Route:** `GET /kids`  
**File:** `resources/views/kids/index.blade.php`  
**H1:** `Kids Zone — Free Learning Games & Puzzles for Children`  
**Title:** `Kids Zone — Free Learning Games for Kids Online | MindSnap`  
**Meta:** `Free educational games, puzzles and quizzes for kids aged 5-12. Math puzzles, word games, science quizzes. Safe, ad-free.`

---

## Design Rules (Kids Zone only)

| Rule | Value |
|---|---|
| Minimum font size | 18px everywhere |
| Minimum tap target | 48×48px |
| Ads | Zero — no ads anywhere in Kids Zone |
| Data collection | None |
| Account required | No |
| Colour scheme | Bright: teal, yellow, green, purple |
| Language | Age 8-10 reading level |

---

## 5 Page Sections

**1. Hero** — colourful animated header (CSS), H1, "For ages 5-12" badge, "No ads, no accounts, always free" note

**2. Age Selector**
```
How old are you?
[5-7 years]  [8-10 years]  [11-12 years]
Easy          Medium         Challenging
```
Selection filters the activity grid below (JS)

**3. Activity Grid** — 5 large colourful tiles
- 🟡 Math Puzzles — `/kids/math-puzzles`
- 🟢 Word Games — `/kids/word-games`
- 🔵 Science Fun — `/kids/science-quiz`
- 🟣 Brain Teasers — `/kids/animal-quiz`
- 🟠 Spelling Quiz — `/kids/spelling-quiz`

**4. Today's Challenge** — featured activity, difficulty stars, big "Play Now" button

**5. Parent Note** — "MindSnap Kids Zone: no ads, no personal data collection, no accounts needed"

---

## Claude Prompt

```
Build the Kids Zone homepage for MindSnap.co.

FILE: resources/views/kids/index.blade.php
IMPORTANT: No ads in this section. Larger fonts (18px min). Bright colours.

Build all 5 sections as specified.
Age selector filters activity cards using JavaScript (data-age attribute on cards).
Activity tiles: large Bootstrap cards, solid category colour, emoji (3rem), name (h2), "Play Now" button (56px height).
Parent note at bottom: reassuring message about safety and no data collection.

SEO:
Title: "Kids Zone — Free Learning Games for Kids Online | MindSnap"
Add FAQPage schema with questions parents ask: Is it safe? Are there ads? Do kids need an account?
```
