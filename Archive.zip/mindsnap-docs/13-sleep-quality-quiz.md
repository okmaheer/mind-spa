# 13 — Sleep Quality Quiz

**Route:** `GET /sleep-quality-quiz`  
**File:** `resources/views/calculators/sleep-quality-quiz.blade.php`  
**SEO Keyword:** `sleep quality test` — 300,000/month  
**H1:** `Sleep Quality Quiz — How Good Is Your Sleep?`  
**Title:** `Sleep Quality Quiz — Free Sleep Quality Test | MindSnap`  
**Meta:** `Free sleep quality quiz. Answer 10 questions to find out how well you are sleeping and get personalised tips to improve.`

---

## What This Is

A scored questionnaire (not a trivia quiz) — 10 questions about sleep habits, symptoms, and patterns. Result: sleep quality score + personalised recommendations.

---

## Questions

1. How many hours of sleep do you typically get? (options: <5 / 5-6 / 7-8 / 9+)
2. How long does it take you to fall asleep? (<5 min / 5-15 / 15-30 / 30+ min)
3. How often do you wake during the night? (rarely / 1-2x / 3+ / almost always)
4. Do you feel rested when you wake up? (always / usually / sometimes / rarely)
5. How consistent is your sleep schedule? (very / mostly / somewhat / not at all)
6. How often do you use screens in the hour before bed? (never / rarely / often / always)
7. Do you drink caffeine after 2pm? (never / rarely / sometimes / daily)
8. How often do you exercise? (daily / 3-5x/week / 1-2x / rarely)
9. Do you experience sleep apnea symptoms? (no / occasionally / regularly / yes diagnosed)
10. How would you rate your overall sleep? (excellent / good / fair / poor)

---

## Scoring & Results

```javascript
// Each answer scores 0-3 points (3=best)
// Total: 0-30

function getSleepScore(answers) {
  const total = answers.reduce((sum, a) => sum + a.score, 0);
  const pct   = Math.round((total / 30) * 100);
  const rating = total >= 24 ? 'Excellent' : total >= 18 ? 'Good' : total >= 12 ? 'Fair' : 'Poor';
  return { total, pct, rating, recommendations: getRecommendations(answers) };
}
```

Result shows: score %, rating badge, 3 personalised tips based on lowest-scoring answers.

---

## Claude Prompt

```
Build the Sleep Quality Quiz for MindSnap.co.

FILE: resources/views/calculators/sleep-quality-quiz.blade.php
ROUTE: GET /sleep-quality-quiz
CATEGORY COLOUR: #6c63ff

This is a scored questionnaire, not a trivia quiz.
10 questions, each with 4 options scored 0-3.
All questions shown at once (not one by one) on a clean card form.
Calculate button at bottom reveals score with fadeIn animation.

RESULT: percentage score, rating badge, 3 personalised recommendations
based on which specific questions scored lowest.

Share card: "My sleep quality score is 73% — take the free test at MindSnap.co"

Build all 12 standard tool page sections.
SEO: target "sleep quality test" and "how good is my sleep"
```
