# 36 — History Quiz

**Route:** `GET /quiz/history`  
**File:** Uses `resources/views/quizzes/quiz.blade.php` (shared template)  
**SEO Keyword:** `history trivia questions` — 1,500,000/month  
**H1:** `History Quiz — Test Your Knowledge Free`  
**Title:** `History Quiz — Free Online Questions | MindSnap`  
**Meta:** `Free history quiz. Test your knowledge of world history from ancient civilisations to modern events. No signup needed.`

---

## What This Quiz Contains

Test your knowledge of world history from ancient civilisations to modern events.

- **Questions:** 10 per session (randomised from DB pool)
- **Difficulty:** Easy → Medium → Hard progression
- **Time limit:** Optional 30 seconds per question
- **Age group:** All (teens and adults)

---

## FAQ

| # | Question | Answer |
|---|---|---|
| Q1 | In what year did World War 2 end? | 1945 — Japan surrendered on September 2, 1945. |
| Q2 | Who was the first US President? | George Washington — inaugurated on April 30, 1789. |
| Q3 | What ancient wonder was located in Alexandria? | The Lighthouse of Alexandria — one of the Seven Wonders of the Ancient World. |
| Q4 | Which empire was ruled by Genghis Khan? | The Mongol Empire — the largest contiguous empire in history. |
| Q5 | Is this history quiz free? | Yes — completely free, no signup, instant results. |

---

## SEO Structure

- Breadcrumb: Home > Quizzes > History Quiz
- Internal links: 2 related quizzes + /quizzes listing page
- Schema: BreadcrumbList + FAQPage

---

## Database Seed

Ask Claude to generate 50 history quiz questions in the quiz_questions table format:
```
category: 'history'
difficulty: mix of easy/medium/hard
age_group: 'all'
```

---

## Claude Prompt

```
Build the History Quiz page for MindSnap.co.
Route: /quiz/history
This page uses the shared quiz.blade.php template from Feature 34.

Controller method: QuizController@show('history')
Load 10 random questions from quiz_questions where category='history'

SEO:
Title: "History Quiz — Free Online Questions | MindSnap"
Meta:  "Free history quiz. Test your knowledge of world history from ancient civilisations to modern events. No signup."
H1:    "History Quiz — Test Your Knowledge Free"
Canonical: https://mindsnap.co/quiz/history

Add to controller: $meta array with title, description, h1, colour (#e94560), keyword
Pass to quiz.blade.php view

Generate 50 seed questions for this category in QuizSeeder.php
Include: question, option_a-d, correct_option, explanation, difficulty, age_group='all'
```
