# 17 — Macro Calculator

**Route:** `GET /macro-calculator`  
**File:** `resources/views/calculators/macro-calculator.blade.php`  
**Category:** Fitness  
**SEO Keyword:** `macro calculator` — 1,200,000/month  

---

## SEO

| Field | Value |
|---|---|
| Title | `Macro Calculator — Free Daily Macros Calculator | MindSnap` |
| Meta | `Free macro calculator. Get your daily protein, carbohydrate and fat targets based on your calorie goal and fitness goals. Instant results.` |
| H1 | `Macro Calculator — Find Your Daily Protein, Carb & Fat Targets` |
| Canonical | `https://mindsnap.co/macro-calculator` |
| Category | [Fitness Tools](/fitness-tools) |

---

## What This Page Does

Macro Calculator page on MindSnap.co. Follows the standard 12-section tool page structure.

---

## Inputs

- **Daily calories:** number (or auto-filled from TDEE calc)
- **Goal:** Weight loss / Muscle gain / Maintenance / Athletic performance
- **Body weight:** for protein calculation
- **Diet preference:** Standard / Low carb / High protein / Balanced

---

## JavaScript Logic

```javascript
const MACRO_SPLITS = {
  weight_loss:   { protein:0.35, carbs:0.35, fat:0.30 },
  muscle_gain:   { protein:0.30, carbs:0.45, fat:0.25 },
  maintenance:   { protein:0.25, carbs:0.50, fat:0.25 },
  athletic:      { protein:0.25, carbs:0.55, fat:0.20 },
  low_carb:      { protein:0.35, carbs:0.20, fat:0.45 },
};
function calcMacros(calories, goal, weightKg) {
  const split = MACRO_SPLITS[goal];
  return {
    protein: Math.round((calories * split.protein) / 4), // 4 cal/g
    carbs:   Math.round((calories * split.carbs)   / 4),
    fat:     Math.round((calories * split.fat)     / 9), // 9 cal/g
    minProteinG: Math.round(weightKg * 1.6), // minimum 1.6g/kg for muscle preservation
  };
}
```

---

## Result Output

Three macro targets (protein/carbs/fat) in grams and calories, shown as doughnut chart (CSS only) + gram amounts + example food equivalents.

---

## Formula Explanation (Section 7)

Protein = 4 cal/g. Carbs = 4 cal/g. Fat = 9 cal/g. Split percentages vary by goal. Minimum protein: 1.6g per kg bodyweight for muscle preservation.

---

## Content Section (Section 8)

**H2:** `Understanding Macros — Protein, Carbs and Fat Explained`

Explain what macros are, why protein matters most (satiety, muscle), why fat is essential, carbs as fuel, how to track macros simply. ~330 words.

---

## FAQ (Section 9)

| # | Question | Answer |
|---|---|---|
| Q1 | What are macros? | Macros (macronutrients) are the three main nutrients: protein, carbohydrates and fat. Each provides calories — protein and carbs provide 4 cal/g and fat provides 9 cal/g. |
| Q2 | How much protein do I need per day? | For general health, 0.8g per kg bodyweight is the minimum. For those exercising regularly or trying to maintain muscle while losing weight, 1.6-2.2g per kg is recommended. |
| Q3 | Do I need to track macros to lose weight? | No — tracking total calories is sufficient for weight loss. Macro tracking becomes valuable when you want to optimise body composition, improve athletic performance, or manage specific dietary conditions. |
| Q4 | What is the best macro split for weight loss? | Higher protein (30-35%) helps preserve muscle during a calorie deficit and increases satiety. Beyond that, the best macro split is one you can consistently maintain. |
| Q5 | Is MindSnap's Macro Calculator free? | Yes — completely free, no signup, no download. Use it instantly on any device. |

---

## Related Tools (Section 10)

1. **TDEE Calculator** → `/calorie-calculator`
2. **Protein Calculator** → `/protein-calculator`
3. **Fitness Tools** → `/fitness-tools`

---



## Claude Prompt

```
Build the Macro Calculator page for MindSnap.co.

FILE: resources/views/calculators/macro-calculator.blade.php
ROUTE: GET /macro-calculator
CATEGORY COLOUR: #28a745

SEO:
Title:    "Macro Calculator — Free Daily Macros Calculator | MindSnap"
Meta:     "Free macro calculator. Get your daily protein, carbohydrate and fat targets based on your calorie goal and fitness goals. Instant results."
H1:       "Macro Calculator — Find Your Daily Protein, Carb & Fat Targets"
Canonical: https://mindsnap.co/macro-calculator

BUILD ALL 12 SECTIONS:
1. Breadcrumb: Home > Fitness Tools > Macro Calculator + BreadcrumbList schema
2. H1 + 2-sentence description + trust badges (Free/No Signup/Instant/Mobile Friendly)
3. INPUT FORM:
- **Daily calories:** number (or auto-filled from TDEE calc)
- **Goal:** Weight loss / Muscle gain / Maintenance / Athletic performance
- **Body weight:** for protein calculation
- **Diet preference:** Standard / Low carb / High protein / Balanced
   Labels above inputs. Units toggle where applicable.
   #e94560 Calculate button, full-width mobile, min 52px height.
4. RESULT: fadeIn animation, large result in #28a745, interpretation text
5. SHARE CARD: canvas 420x220px, Copy/WhatsApp/Download buttons
6. HOW TO USE: H2 + 4-5 numbered steps
7. FORMULA: H2 + plain English + formula in styled box
8. CONTENT: H2 "Understanding Macros — Protein, Carbs and Fat Explained" + 300-400 words + 2-3 H3 subheadings
9. FAQ: H2 + Bootstrap accordion + 5 Q&As + FAQPage JSON-LD schema
10. RELATED TOOLS: 3 cards — TDEE Calculator, Protein Calculator, Fitness Tools category page
11. CATEGORY LINK: text sentence linking back to /fitness-tools
12. SCHEMAS in @section('schema'):
    - WebApplication JSON-LD
    - BreadcrumbList JSON-LD  
    - FAQPage JSON-LD

VANILLA JS LOGIC:
const MACRO_SPLITS = {
  weight_loss:   { protein:0.35, carbs:0.35, fat:0.30 },
  muscle_gain:   { protein:0.30, carbs:0.45, fat:0.25 },
  maintenance:   { protein:0.25, carbs:0.50, fat:0.25 },
  athletic:      { protein:0.25, carbs:0.55, fat:0.20 },
  low_carb:      { protein:0.35, carbs:0.20, fat:0.45 },
};
function calcMacros(calories, goal, weightKg) {
  const split = MACRO_SPLITS[goal];
  return {
    protein: Math.round((calories * split.protein) / 4), // 4 cal/g
    carbs:   Math.round((calories * split.carbs)   / 4),
    fat:     Math.round((calories * split.fat)     / 9), // 9 cal/g
    minProteinG: Math.round(weightKg * 1.6), // minimum 1.6g/kg for muscle preservation
  };
}

MOBILE: all inputs 100% width, 48px height, buttons 52px, test at 375px
PERFORMANCE: defer all JS, lazy load images
```
