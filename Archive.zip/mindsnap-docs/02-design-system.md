# 02 — Design System

> Paste the Claude prompt at the bottom into every coding session before building any page.

---

## Colours

```css
:root {
  /* Brand */
  --primary-dark:   #1a1a2e;   /* navbar, headings, footer bg */
  --primary-mid:    #0f3460;   /* section backgrounds, accents */
  --primary-cta:    #e94560;   /* all CTA buttons, highlights */

  /* Page */
  --bg:             #f8f9fa;   /* page background */
  --card:           #ffffff;   /* all cards */
  --text:           #555555;   /* body text */
  --text-muted:     #888888;   /* captions, labels */
  --border:         #e0e0e0;   /* dividers, card borders */

  /* Categories */
  --sleep:          #6c63ff;   /* purple */
  --fitness:        #28a745;   /* green */
  --nutrition:      #fd7e14;   /* orange */
  --quiz:           #e94560;   /* red-pink */
  --kids:           #17a2b8;   /* teal */
  --life:           #6f42c1;   /* violet */
  --games:          #ffc107;   /* yellow */
}
```

---

## Typography

```
Font family:  Inter (Google Fonts)
Import:       @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap')
Preconnect:   Add to <head> before stylesheet

H1:   2.5rem (40px) desktop / clamp(1.8rem, 5vw, 2.5rem) mobile — bold — #1a1a2e
H2:   2rem (32px)   — bold     — #0f3460
H3:   1.5rem (24px) — semibold — #16213e
Body: 1rem (16px)   — regular  — #555555
Small: 0.875rem     — regular  — #888888

Line height: 1.6 for body, 1.3 for headings
Minimum body font on mobile: 16px (prevents iOS zoom on form inputs)
```

---

## Spacing

```
Section padding:   80px top/bottom desktop  →  40px mobile
Card padding:      24px desktop             →  16px mobile
Border radius:     12px cards / 8px buttons / 50px badges
Box shadow:        0 4px 20px rgba(0,0,0,0.08)
Grid gap:          24px desktop / 16px mobile
```

---

## Components

### Tool Card
```html
<div class="card tool-card h-100"
     style="border-left: 4px solid var(--[category]);">
  <div class="card-body">
    <span class="tool-icon fs-3">😴</span>
    <h3 class="h5 mt-2">
      <a href="/sleep-calculator">Sleep Cycle Calculator</a>
    </h3>
    <p class="text-muted small">Find your perfect bedtime.</p>
    <span class="badge searches-badge">2.2M searches/month</span>
    <a href="/sleep-calculator" class="btn btn-cta btn-sm mt-2 d-block">
      Use Free Tool →
    </a>
  </div>
</div>
```

### CTA Button
```css
.btn-cta {
  background-color: var(--primary-cta);  /* #e94560 */
  color: #ffffff;
  border-radius: 8px;
  padding: 12px 28px;
  font-weight: 500;
  border: none;
  min-height: 48px;  /* mobile tap target */
}
.btn-cta:hover { background-color: #c73652; color: #fff; }
```

### Category Badge
```css
.badge-category {
  background-color: color-mix(in srgb, var(--category-colour) 15%, white);
  color: var(--category-colour);
  border-radius: 50px;
  padding: 4px 12px;
  font-size: 0.75rem;
  font-weight: 600;
}
```

### Result Box
```css
.result-box {
  background: #f0f2f5;
  border-left: 4px solid var(--category-colour);
  border-radius: 8px;
  padding: 20px 24px;
  animation: fadeIn 0.3s ease;
}
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(8px); }
  to   { opacity: 1; transform: translateY(0); }
}
```

### Trust Badge Row
```html
<div class="trust-badges d-flex flex-wrap gap-2 mt-2">
  <span class="badge bg-light text-success border">✓ Free</span>
  <span class="badge bg-light text-success border">✓ No Signup</span>
  <span class="badge bg-light text-success border">✓ Instant Results</span>
  <span class="badge bg-light text-success border">✓ Mobile Friendly</span>
</div>
```

---

## Responsive Grid Rules

| Element | Mobile (< 768px) | Tablet (768–1024px) | Desktop (> 1024px) |
|---|---|---|---|
| Category cards | `col-6` (2 per row) | `col-md-4` | `col-lg-3` (4 per row) |
| Tool cards | `col-12` | `col-md-6` | `col-lg-4` |
| Tool form / info | Stacked | Stacked | 60% / 40% split |
| Quiz answers | `col-12` (full width) | `col-12` | `col-12` |
| Related tools | `col-12` | `col-md-6` | `col-lg-4` |

---

## Master Claude Prompt (paste at start of every session)

```
We are building MindSnap.co — health calculators + brain quizzes, all free, no signup.
Stack: Laravel 10, Bootstrap 5, Vanilla JavaScript, MySQL
Hosting: Namecheap + Cloudflare CDN

DESIGN SYSTEM — apply to every file:
Colours: --primary-dark #1a1a2e / --primary-mid #0f3460 / --primary-cta #e94560
Background #f8f9fa / Cards #ffffff / Text #555555
Category colours: Sleep #6c63ff | Fitness #28a745 | Nutrition #fd7e14
                  Quiz #e94560 | Kids #17a2b8 | Life #6f42c1 | Games #ffc107
Font: Inter (Google Fonts), preconnect in head
Min body font: 16px | Min tap target: 48px | CTA buttons: #e94560

SEO — every page must have:
- Title: [Keyword first] — [Benefit] | MindSnap  (max 60 chars)
- Meta description: keyword in first 10 words, max 155 chars, soft CTA
- Exactly one H1 containing the target keyword
- Canonical URL tag
- Open Graph tags
- JSON-LD: WebApplication + BreadcrumbList + FAQPage schemas
- 200-400 words content with H2/H3 structure
- 5 FAQ questions
- 3 internal links minimum (2 related tools + category page)

TOOL PAGE STRUCTURE — always 12 sections in this order:
1.Breadcrumb 2.H1+badges 3.Input form 4.Result output
5.Share card 6.How to Use 7.Formula 8.Content(300-400w)
9.FAQ+schema 10.Related tools 11.Category link 12.All schemas

MOBILE — test at 375px:
- All inputs 100% width, 48px height
- Buttons 52px height, full width on mobile
- No horizontal scroll
- Font min 16px

PERFORMANCE:
- All JS has defer attribute
- Images have loading="lazy" + width + height
- No render-blocking resources
```
