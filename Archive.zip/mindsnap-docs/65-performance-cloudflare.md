# 65 — Performance & Cloudflare

---

## Target Metrics

| Metric | Target |
|---|---|
| PageSpeed (mobile) | 90+ |
| LCP | < 2.5 seconds |
| CLS | < 0.1 |
| INP | < 200ms |
| Total page size | < 500kb |

---

## Laravel/HTML Optimisations

```html
<!-- Fonts: preconnect first, swap display -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap"
      rel="stylesheet" media="print" onload="this.media='all'">

<!-- All scripts deferred -->
<script src="..." defer></script>

<!-- Images: always include width, height, lazy -->
<img src="..." width="400" height="300" loading="lazy" alt="...">

<!-- Ad containers: fixed min-height prevents CLS -->
<div style="min-height:250px"><!-- ad slot --></div>
```

---

## Cloudflare Setup (free, set once)

```
PAGE RULES:
mindsnap.co/sitemap.xml  → Cache Level: Bypass
mindsnap.co/api/*        → Cache Level: Bypass
mindsnap.co/*            → Cache Everything, Edge TTL: 1 day

SPEED TAB:
✓ Auto Minify: HTML + CSS + JS
✓ Brotli Compression: ON
✓ Rocket Loader: ON
✓ Polish: Lossy (auto image compression)

CACHING:
Browser Cache TTL: 1 year
Always Online: ON

SECURITY:
SSL/TLS: Full (Strict)
Always Use HTTPS: ON
HSTS: ON
```

---

## Claude Prompt

```
Optimise [PAGE] for Google PageSpeed. Target 90+ mobile.

1. Add defer to all non-critical script tags
2. Add preconnect + font-display:swap for Google Fonts
3. Add loading="lazy" + width + height to all images
4. Inline critical above-fold CSS in <style> tag
5. Set explicit min-height on all ad containers
6. Remove HTML comments and unused whitespace
7. Verify canonical tag and OG tags present
8. Report estimated page size reduction
```
