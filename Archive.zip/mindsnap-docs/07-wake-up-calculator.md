# 07 — Wake-Up Time Calculator

**Route:** `GET /wake-up-calculator`  
**File:** `resources/views/calculators/wake-up-calculator.blade.php`  
**Category:** Sleep  
**SEO Keyword:** `what time should i wake up` — 1,100,000/month  

---

## SEO

| Field | Value |
|---|---|
| Title | `Wake-Up Time Calculator — Free Bedtime Planner | MindSnap` |
| Meta | `Free wake-up time calculator. Enter your bedtime and find the best time to wake up based on sleep cycles. No signup needed.` |
| H1 | `Wake-Up Time Calculator — When Should I Wake Up?` |
| Canonical | `https://mindsnap.co/wake-up-calculator` |
| Category | [Sleep Tools](/sleep-tools) |

---

## What This Page Does

Wake-Up Time Calculator page on MindSnap.co. Follows the standard 12-section tool page structure.

---

## Inputs

- **Bedtime input:** hour + minute selects
- **Optional:** minutes to fall asleep (default 14)
- Shows multiple wake-up time options (after 4, 5, 6 complete cycles)

---

## JavaScript Logic

```javascript
// Inverse of sleep calculator — given bedtime, find best wake times
function calculateWakeTimes(bedtimeMinutes, fallAsleepMinutes) {
  const sleepStart = bedtimeMinutes + fallAsleepMinutes;
  const results = [];
  for (let cycles = 4; cycles <= 6; cycles++) {
    const wakeTime = sleepStart + (cycles * 90);
    results.push({
      wakeTime: minutesToTime(wakeTime % 1440),
      cycles, hours: (cycles * 90 / 60).toFixed(1),
      quality: cycles === 6 ? 'Ideal' : cycles === 5 ? 'Good' : 'Minimum'
    });
  }
  return results;
}
```

---

## Result Output

3 wake-up time options shown as cards: after 4 cycles (6h), 5 cycles (7.5h), 6 cycles (9h). Highlight 5-6 cycles as recommended.

---

## Formula Explanation (Section 7)

Wake time = Bedtime + Fall-asleep time + (Number of cycles × 90 min). For 10:00pm bedtime + 14min + 5 cycles = 7:44am wake time.

---

## Content Section (Section 8)

**H2:** `Finding Your Ideal Wake-Up Time`

Explain why waking at end of a cycle matters, how this differs from alarm-based waking, tips for consistent schedules. ~300 words.

---

## FAQ (Section 9)

| # | Question | Answer |
|---|---|---|
| Q1 | When is the best time to wake up? | The best wake-up time is at the end of a complete 90-minute sleep cycle. This calculator shows you exactly which times align with your natural cycle based on your bedtime. |
| Q2 | Is waking up at 6am or 7am better? | Neither is universally better — it depends on your bedtime. What matters is waking at the end of a sleep cycle. Use this calculator to find the ideal time based on when you go to sleep. |
| Q3 | What if I can't wake up at the suggested time? | Try to pick the closest suggested time to your alarm. Even 15 minutes adjustment toward a cycle endpoint can reduce morning grogginess significantly. |
| Q4 | How many hours of sleep do adults need? | Most adults need 7-9 hours (5-6 complete 90-minute sleep cycles). Consistently getting fewer than 6 hours increases health risks over time. |
| Q5 | Is MindSnap's Wake-Up Time Calculator free? | Yes — completely free, no signup, no download. Use it instantly on any device. |

---

## Related Tools (Section 10)

1. **Sleep Cycle Calculator** → `/sleep-calculator`
2. **Sleep Debt Calculator** → `/sleep-debt-calculator`
3. **Sleep Tools** → `/sleep-tools`

---



## Claude Prompt

```
Build the Wake-Up Time Calculator page for MindSnap.co.

FILE: resources/views/calculators/wake-up-calculator.blade.php
ROUTE: GET /wake-up-calculator
CATEGORY COLOUR: #6c63ff

SEO:
Title:    "Wake-Up Time Calculator — Free Bedtime Planner | MindSnap"
Meta:     "Free wake-up time calculator. Enter your bedtime and find the best time to wake up based on sleep cycles. No signup needed."
H1:       "Wake-Up Time Calculator — When Should I Wake Up?"
Canonical: https://mindsnap.co/wake-up-calculator

BUILD ALL 12 SECTIONS:
1. Breadcrumb: Home > Sleep Tools > Wake-Up Time Calculator + BreadcrumbList schema
2. H1 + 2-sentence description + trust badges (Free/No Signup/Instant/Mobile Friendly)
3. INPUT FORM:
- **Bedtime input:** hour + minute selects
- **Optional:** minutes to fall asleep (default 14)
- Shows multiple wake-up time options (after 4, 5, 6 complete cycles)
   Labels above inputs. Units toggle where applicable.
   #e94560 Calculate button, full-width mobile, min 52px height.
4. RESULT: fadeIn animation, large result in #6c63ff, interpretation text
5. SHARE CARD: canvas 420x220px, Copy/WhatsApp/Download buttons
6. HOW TO USE: H2 + 4-5 numbered steps
7. FORMULA: H2 + plain English + formula in styled box
8. CONTENT: H2 "Finding Your Ideal Wake-Up Time" + 300-400 words + 2-3 H3 subheadings
9. FAQ: H2 + Bootstrap accordion + 5 Q&As + FAQPage JSON-LD schema
10. RELATED TOOLS: 3 cards — Sleep Cycle Calculator, Sleep Debt Calculator, Sleep Tools category page
11. CATEGORY LINK: text sentence linking back to /sleep-tools
12. SCHEMAS in @section('schema'):
    - WebApplication JSON-LD
    - BreadcrumbList JSON-LD  
    - FAQPage JSON-LD

VANILLA JS LOGIC:
// Inverse of sleep calculator — given bedtime, find best wake times
function calculateWakeTimes(bedtimeMinutes, fallAsleepMinutes) {
  const sleepStart = bedtimeMinutes + fallAsleepMinutes;
  const results = [];
  for (let cycles = 4; cycles <= 6; cycles++) {
    const wakeTime = sleepStart + (cycles * 90);
    results.push({
      wakeTime: minutesToTime(wakeTime % 1440),
      cycles, hours: (cycles * 90 / 60).toFixed(1),
      quality: cycles === 6 ? 'Ideal' : cycles === 5 ? 'Good' : 'Minimum'
    });
  }
  return results;
}

MOBILE: all inputs 100% width, 48px height, buttons 52px, test at 375px
PERFORMANCE: defer all JS, lazy load images
```
