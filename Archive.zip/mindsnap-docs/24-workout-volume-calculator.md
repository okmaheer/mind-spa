# 24 — Workout Volume Calculator

**Route:** `GET /workout-volume-calculator`  
**File:** `resources/views/calculators/workout-volume-calculator.blade.php`  
**Category:** Fitness  
**SEO Keyword:** `workout volume calculator` — 350,000/month  

---

## SEO

| Field | Value |
|---|---|
| Title | `Workout Volume Calculator — Free Training Volume Tool | MindSnap` |
| Meta | `Free workout volume calculator. Calculate total training volume (sets × reps × weight) per exercise and muscle group to optimise your program.` |
| H1 | `Workout Volume Calculator — Track Your Training Load` |
| Canonical | `https://mindsnap.co/workout-volume-calculator` |
| Category | [Fitness Tools](/fitness-tools) |

---

## What This Page Does

Workout Volume Calculator page on MindSnap.co. Follows the standard 12-section tool page structure.

---

## Inputs

- **Exercise name:** text input
- **Sets:** number
- **Reps per set:** number
- **Weight:** kg/lbs
- **Add exercise** button (up to 10 exercises)

---

## JavaScript Logic

```javascript
function calcVolume(sets, reps, weightKg) {
  return { volume: sets * reps * weightKg, tonnage: (sets * reps * weightKg / 1000).toFixed(2) };
}
function calcTotalVolume(exercises) {
  const total = exercises.reduce((sum, ex) => sum + ex.sets * ex.reps * ex.weight, 0);
  const setCount = exercises.reduce((sum, ex) => sum + ex.sets, 0);
  return { totalVolume: total, totalSets: setCount, exercises };
}
```

---

## Result Output

Per-exercise volume + total session volume + total sets + average intensity. Comparison note (e.g. 'This is 15% higher than your last session' if data stored in localStorage).

---

## Formula Explanation (Section 7)

Volume = Sets × Reps × Weight (kg). Example: 4 sets × 8 reps × 80kg = 2,560kg volume load. Used to track progressive overload over time.

---

## Content Section (Section 8)

**H2:** `Training Volume — The Key Driver of Muscle Growth`

Explain progressive overload, what volume means in training, weekly set recommendations per muscle group (10-20 sets), how to track and progress. ~320 words.

---

## FAQ (Section 9)

| # | Question | Answer |
|---|---|---|
| Q1 | What is training volume? | Training volume is the total amount of work done: sets × reps × weight. It is one of the primary drivers of muscle growth (hypertrophy). Progressively increasing volume over time is key to continued progress. |
| Q2 | How many sets per muscle group per week? | Research suggests 10-20 sets per muscle group per week for hypertrophy. Beginners can see results with 8-10 sets. Advanced trainees may benefit from 15-20+. Recovery capacity limits upper volume. |
| Q3 | Should I track volume or just sets and reps? | Both are useful. Tracking volume (sets × reps × weight) gives a single number that accounts for all variables, making it easier to confirm you are progressing from session to session. |
| Q4 | What is progressive overload? | Progressive overload means gradually increasing the demands on your muscles over time — by adding weight, reps, sets, or reducing rest time. Without progressive overload, muscle growth stalls. |
| Q5 | Is MindSnap's Workout Volume Calculator free? | Yes — completely free, no signup, no download. Use it instantly on any device. |

---

## Related Tools (Section 10)

1. **One Rep Max Calculator** → `/one-rep-max-calculator`
2. **Protein Calculator** → `/protein-calculator`
3. **Fitness Tools** → `/fitness-tools`

---



## Claude Prompt

```
Build the Workout Volume Calculator page for MindSnap.co.

FILE: resources/views/calculators/workout-volume-calculator.blade.php
ROUTE: GET /workout-volume-calculator
CATEGORY COLOUR: #28a745

SEO:
Title:    "Workout Volume Calculator — Free Training Volume Tool | MindSnap"
Meta:     "Free workout volume calculator. Calculate total training volume (sets × reps × weight) per exercise and muscle group to optimise your program."
H1:       "Workout Volume Calculator — Track Your Training Load"
Canonical: https://mindsnap.co/workout-volume-calculator

BUILD ALL 12 SECTIONS:
1. Breadcrumb: Home > Fitness Tools > Workout Volume Calculator + BreadcrumbList schema
2. H1 + 2-sentence description + trust badges (Free/No Signup/Instant/Mobile Friendly)
3. INPUT FORM:
- **Exercise name:** text input
- **Sets:** number
- **Reps per set:** number
- **Weight:** kg/lbs
- **Add exercise** button (up to 10 exercises)
   Labels above inputs. Units toggle where applicable.
   #e94560 Calculate button, full-width mobile, min 52px height.
4. RESULT: fadeIn animation, large result in #28a745, interpretation text
5. SHARE CARD: canvas 420x220px, Copy/WhatsApp/Download buttons
6. HOW TO USE: H2 + 4-5 numbered steps
7. FORMULA: H2 + plain English + formula in styled box
8. CONTENT: H2 "Training Volume — The Key Driver of Muscle Growth" + 300-400 words + 2-3 H3 subheadings
9. FAQ: H2 + Bootstrap accordion + 5 Q&As + FAQPage JSON-LD schema
10. RELATED TOOLS: 3 cards — One Rep Max Calculator, Protein Calculator, Fitness Tools category page
11. CATEGORY LINK: text sentence linking back to /fitness-tools
12. SCHEMAS in @section('schema'):
    - WebApplication JSON-LD
    - BreadcrumbList JSON-LD  
    - FAQPage JSON-LD

VANILLA JS LOGIC:
function calcVolume(sets, reps, weightKg) {
  return { volume: sets * reps * weightKg, tonnage: (sets * reps * weightKg / 1000).toFixed(2) };
}
function calcTotalVolume(exercises) {
  const total = exercises.reduce((sum, ex) => sum + ex.sets * ex.reps * ex.weight, 0);
  const setCount = exercises.reduce((sum, ex) => sum + ex.sets, 0);
  return { totalVolume: total, totalSets: setCount, exercises };
}

MOBILE: all inputs 100% width, 48px height, buttons 52px, test at 375px
PERFORMANCE: defer all JS, lazy load images
```
