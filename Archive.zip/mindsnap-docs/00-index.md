# MindSnap.co — Master Index

> Every feature has its own file. Read them in order when starting a new build session.

---

## 📁 File Structure

### Foundation
- [00-index.md](./00-index.md) — this file
- [01-project-setup.md](./01-project-setup.md) — stack, folder structure, routes, DB, env
- [02-design-system.md](./02-design-system.md) — colours, fonts, spacing, components
- [03-master-layout-navbar-footer.md](./03-master-layout-navbar-footer.md) — app.blade.php, navbar, footer

### Core Pages
- [04-homepage.md](./04-homepage.md) — homepage all 7 sections
- [05-category-pages.md](./05-category-pages.md) — all 8 category landing pages

### Sleep Tools
- [06-sleep-calculator.md](./06-sleep-calculator.md) — sleep cycle calculator
- [07-wake-up-calculator.md](./07-wake-up-calculator.md) — wake-up time calculator
- [08-nap-calculator.md](./08-nap-calculator.md) — nap calculator
- [09-baby-sleep-calculator.md](./09-baby-sleep-calculator.md) — baby sleep schedule
- [10-sleep-debt-calculator.md](./10-sleep-debt-calculator.md) — sleep debt calculator
- [11-caffeine-calculator.md](./11-caffeine-calculator.md) — caffeine cut-off calculator
- [12-jet-lag-calculator.md](./12-jet-lag-calculator.md) — jet lag recovery
- [13-sleep-quality-quiz.md](./13-sleep-quality-quiz.md) — sleep quality test

### Fitness Tools
- [14-bmi-calculator.md](./14-bmi-calculator.md) — BMI calculator
- [15-tdee-calculator.md](./15-tdee-calculator.md) — TDEE / calorie calculator
- [16-calorie-deficit-calculator.md](./16-calorie-deficit-calculator.md) — calorie deficit
- [17-macro-calculator.md](./17-macro-calculator.md) — macro calculator
- [18-protein-calculator.md](./18-protein-calculator.md) — protein intake
- [19-one-rep-max-calculator.md](./19-one-rep-max-calculator.md) — one rep max
- [20-body-fat-calculator.md](./20-body-fat-calculator.md) — body fat %
- [21-heart-rate-calculator.md](./21-heart-rate-calculator.md) — heart rate zones
- [22-running-pace-calculator.md](./22-running-pace-calculator.md) — running pace
- [23-ideal-weight-calculator.md](./23-ideal-weight-calculator.md) — ideal weight
- [24-workout-volume-calculator.md](./24-workout-volume-calculator.md) — workout volume

### Nutrition Tools
- [25-water-intake-calculator.md](./25-water-intake-calculator.md) — water intake
- [26-intermittent-fasting-calculator.md](./26-intermittent-fasting-calculator.md) — IF timer

### Life Tools
- [27-age-calculator.md](./27-age-calculator.md) — age calculator
- [28-days-between-dates.md](./28-days-between-dates.md) — days between dates
- [29-days-until-calculator.md](./29-days-until-calculator.md) — days until
- [30-pregnancy-due-date.md](./30-pregnancy-due-date.md) — due date calculator
- [31-ovulation-calculator.md](./31-ovulation-calculator.md) — ovulation calculator
- [32-retirement-countdown.md](./32-retirement-countdown.md) — retirement countdown
- [33-life-percentage-calculator.md](./33-life-percentage-calculator.md) — life % lived

### Quiz System
- [34-quiz-system-core.md](./34-quiz-system-core.md) — quiz engine, DB, controller
- [35-quiz-general-knowledge.md](./35-quiz-general-knowledge.md) — GK quiz
- [36-quiz-history.md](./36-quiz-history.md) — history quiz
- [37-quiz-biology.md](./37-quiz-biology.md) — biology quiz
- [38-quiz-science.md](./38-quiz-science.md) — science quiz
- [39-quiz-geography.md](./39-quiz-geography.md) — geography quiz
- [40-quiz-math.md](./40-quiz-math.md) — math quiz
- [41-iq-test.md](./41-iq-test.md) — IQ test
- [42-quiz-world-war-2.md](./42-quiz-world-war-2.md) — WW2 quiz
- [43-quiz-human-body.md](./43-quiz-human-body.md) — human body quiz
- [44-ai-quiz-generator.md](./44-ai-quiz-generator.md) — AI quiz generator
- [45-daily-quiz.md](./45-daily-quiz.md) — daily quiz + daily challenge page

### Kids Zone
- [46-kids-zone-home.md](./46-kids-zone-home.md) — kids zone homepage
- [47-kids-math-puzzles.md](./47-kids-math-puzzles.md) — math puzzles for kids
- [48-kids-word-games.md](./48-kids-word-games.md) — word games for kids
- [49-kids-science-quiz.md](./49-kids-science-quiz.md) — science quiz for kids
- [50-kids-animal-quiz.md](./50-kids-animal-quiz.md) — animal quiz for kids
- [51-kids-spelling-quiz.md](./51-kids-spelling-quiz.md) — spelling quiz for kids

### Games
- [52-typing-speed-test.md](./52-typing-speed-test.md) — typing speed test
- [53-reaction-time-test.md](./53-reaction-time-test.md) — reaction time test
- [54-memory-test.md](./54-memory-test.md) — memory test
- [55-word-scramble.md](./55-word-scramble.md) — word scramble game
- [56-color-blind-test.md](./56-color-blind-test.md) — color blind test

### SEO Content Pages
- [57-what-time-should-i-sleep.md](./57-what-time-should-i-sleep.md) — SEO guide page
- [58-how-much-sleep-do-i-need.md](./58-how-much-sleep-do-i-need.md) — SEO guide page
- [59-what-is-a-good-bmi.md](./59-what-is-a-good-bmi.md) — SEO guide page
- [60-calories-to-lose-weight.md](./60-calories-to-lose-weight.md) — SEO guide page

### Site Features
- [61-site-search.md](./61-site-search.md) — search modal + results page
- [62-share-cards.md](./62-share-cards.md) — shareable result cards (canvas)
- [63-adsense-integration.md](./63-adsense-integration.md) — ad slots + placement
- [64-seo-standards.md](./64-seo-standards.md) — title/meta/schema rules for every page
- [65-performance-cloudflare.md](./65-performance-cloudflare.md) — speed optimisation
- [66-sitemap-robots.md](./66-sitemap-robots.md) — sitemap.xml, robots.txt, Search Console

---

## How to Use These Files

1. Open VS Code with Claude extension
2. Start every session with the master prompt from `02-design-system.md`
3. Open the specific feature file you are building
4. Copy the Claude prompt at the bottom of that file
5. Paste into Claude and build
6. Run the audit checklist from `64-seo-standards.md` before committing

---

## Build Order (follow strictly)

| Week | Files to Build |
|---|---|
| Week 1 | 01 → 02 → 03 → 04 → 05 → 06 → 14 → 15 |
| Week 2 | 07 → 08 → 09 → 10 → 11 → 16 → 17 → 18 |
| Week 3 | 34 → 35 → 36 → 45 → 25 → 26 → 27 → 28 |
| Week 4 | 46 → 47 → 48 → 52 → 53 → 61 → 62 → 63 |
| Month 2 | Remaining tools in order of monthly search volume |
