# 57 — SEO Content Page: What Time Should I Sleep?

**Route:** `GET /what-time-should-i-sleep`  
**File:** `resources/views/seo/what-time-should-i-sleep.blade.php`  
**SEO Keyword:** `what time should i sleep` — 1,800,000/month  
**H1:** `What Time Should I Sleep?`  
**Title:** `What Time Should I Sleep? — Complete Guide | MindSnap`  
**Meta:** `Informational guide answering the common question with age-based sleep time tables. Free tools included.`  
**Type:** Pure SEO content page — no calculator, just well-structured information

---

## What This Page Is

An informational guide that ranks for the question keyword and funnels readers to the relevant calculator tool. These pages rank for "question-style" searches and are among the highest-traffic content types in the health niche.

---

## Page Structure

```
H1: What Time Should I Sleep?
Short intro (50 words): direct answer to the question

H2: The Short Answer
  Direct answer in 2-3 sentences. Keyword used naturally.

H2: [Main Table or Data]
  Sleep timing recommendations by age group (children, teens, adults, seniors). Links to sleep calculator.

H2: Factors That Affect [Topic]
  3-4 factors in a list with explanation

H2: How to [Action Related to Topic]
  CTA box linking to the calculator tool

H2: FAQ (5 questions + FAQPage JSON-LD schema)

Related tools section (3 cards)
```

Total content: 400-600 words. No fluff. Accurate and helpful.

---

## Claude Prompt

```
Build the SEO content page "What Time Should I Sleep?" for MindSnap.co.

FILE: resources/views/seo/what-time-should-i-sleep.blade.php
ROUTE: GET /what-time-should-i-sleep

@extends('layouts.app')
@section('title', 'What Time Should I Sleep? — Complete Guide | MindSnap')
@section('description', 'Informational guide answering the common question with age-based sleep time tables. Free tools included.')
@section('canonical', 'https://mindsnap.co/what-time-should-i-sleep')

This is an informational page — no calculator widget.
Structure: Sleep timing recommendations by age group (children, teens, adults, seniors). Links to sleep calculator.

Write 400-600 words of accurate, helpful content.
Include target keyword "what time should i sleep" naturally 4-6 times.
Use H2/H3 hierarchy. Short paragraphs (2-3 sentences each).
Include a prominent CTA box linking to the relevant calculator tool.
Add FAQPage JSON-LD schema with 5 questions.
Add BreadcrumbList schema.

Internal links: 2-3 related calculators + 1 category page
```
