# 11 — Caffeine Cut-Off Calculator

**Route:** `GET /caffeine-sleep-calculator`  
**File:** `resources/views/calculators/caffeine-sleep-calculator.blade.php`  
**Category:** Sleep  
**SEO Keyword:** `caffeine cut off time calculator` — 400,000/month  

---

## SEO

| Field | Value |
|---|---|
| Title | `Caffeine Cut-Off Calculator — Last Safe Coffee Time | MindSnap` |
| Meta | `Free caffeine cut-off calculator. Find the latest safe time to drink coffee based on your bedtime. Backed by caffeine half-life science.` |
| H1 | `Caffeine Cut-Off Calculator — When to Stop Drinking Coffee` |
| Canonical | `https://mindsnap.co/caffeine-sleep-calculator` |
| Category | [Sleep Tools](/sleep-tools) |

---

## What This Page Does

Caffeine Cut-Off Calculator page on MindSnap.co. Follows the standard 12-section tool page structure.

---

## Inputs

- **Bedtime:** hour + minute selects
- **Caffeine sensitivity:** Low / Average / High (affects half-life used)
- **Drink type:** Coffee / Espresso / Energy drink / Tea / Cola (sets caffeine mg)

---

## JavaScript Logic

```javascript
const CAFFEINE_MG = {
  coffee: 95, espresso: 63, energy_drink: 150, tea: 47, cola: 34
};
const HALF_LIFE_HOURS = { low: 4, average: 5, high: 7 }; // caffeine half-life by sensitivity

function calculateCutoff(bedtimeMinutes, sensitivity, drinkType) {
  const halfLife    = HALF_LIFE_HOURS[sensitivity];
  const mg          = CAFFEINE_MG[drinkType];
  // Need < 25mg caffeine at bedtime to not disrupt sleep
  const hoursNeeded = halfLife * Math.log2(mg / 25);
  const cutoffMinutes = bedtimeMinutes - (hoursNeeded * 60);
  return { cutoff: minutesToTime(((cutoffMinutes % 1440) + 1440) % 1440), hoursNeeded };
}
```

---

## Result Output

Shows the latest safe time to have the selected drink, how many mg of caffeine remain at bedtime if consumed at cutoff, and a visual timeline from wake to sleep.

---

## Formula Explanation (Section 7)

Caffeine half-life formula: time needed = half-life × log₂(starting mg / target mg). Target: under 25mg caffeine at bedtime. Average coffee has 95mg with 5-hour half-life.

---

## Content Section (Section 8)

**H2:** `Caffeine and Sleep: The Science of Cut-Off Times`

Explain caffeine half-life, how it varies by person, why afternoon coffee disrupts deep sleep even when you fall asleep fine, adenosine blocking mechanism. ~320 words.

---

## FAQ (Section 9)

| # | Question | Answer |
|---|---|---|
| Q1 | How long does caffeine stay in your system? | Caffeine has a half-life of approximately 5 hours in most adults. This means half of a 95mg coffee is still in your system 5 hours later. It takes 8-10 hours for most of it to clear. |
| Q2 | Can caffeine affect sleep even if I fall asleep fine? | Yes. Research shows caffeine reduces deep sleep (slow-wave sleep) even when you fall asleep normally. You may sleep but not get the full restorative benefit. |
| Q3 | What drinks have the most caffeine? | Energy drinks typically have 150-300mg, filter coffee 80-120mg, espresso 60-75mg per shot, black tea 40-70mg, and cola 30-40mg per can. |
| Q4 | Does caffeine sensitivity change with age? | Yes. Older adults and pregnant women typically process caffeine more slowly, extending its half-life. Some medications also slow caffeine metabolism. |
| Q5 | Is MindSnap's Caffeine Cut-Off Calculator free? | Yes — completely free, no signup, no download. Use it instantly on any device. |

---

## Related Tools (Section 10)

1. **Sleep Cycle Calculator** → `/sleep-calculator`
2. **Nap Calculator** → `/nap-calculator`
3. **Sleep Tools** → `/sleep-tools`

---



## Claude Prompt

```
Build the Caffeine Cut-Off Calculator page for MindSnap.co.

FILE: resources/views/calculators/caffeine-sleep-calculator.blade.php
ROUTE: GET /caffeine-sleep-calculator
CATEGORY COLOUR: #6c63ff

SEO:
Title:    "Caffeine Cut-Off Calculator — Last Safe Coffee Time | MindSnap"
Meta:     "Free caffeine cut-off calculator. Find the latest safe time to drink coffee based on your bedtime. Backed by caffeine half-life science."
H1:       "Caffeine Cut-Off Calculator — When to Stop Drinking Coffee"
Canonical: https://mindsnap.co/caffeine-sleep-calculator

BUILD ALL 12 SECTIONS:
1. Breadcrumb: Home > Sleep Tools > Caffeine Cut-Off Calculator + BreadcrumbList schema
2. H1 + 2-sentence description + trust badges (Free/No Signup/Instant/Mobile Friendly)
3. INPUT FORM:
- **Bedtime:** hour + minute selects
- **Caffeine sensitivity:** Low / Average / High (affects half-life used)
- **Drink type:** Coffee / Espresso / Energy drink / Tea / Cola (sets caffeine mg)
   Labels above inputs. Units toggle where applicable.
   #e94560 Calculate button, full-width mobile, min 52px height.
4. RESULT: fadeIn animation, large result in #6c63ff, interpretation text
5. SHARE CARD: canvas 420x220px, Copy/WhatsApp/Download buttons
6. HOW TO USE: H2 + 4-5 numbered steps
7. FORMULA: H2 + plain English + formula in styled box
8. CONTENT: H2 "Caffeine and Sleep: The Science of Cut-Off Times" + 300-400 words + 2-3 H3 subheadings
9. FAQ: H2 + Bootstrap accordion + 5 Q&As + FAQPage JSON-LD schema
10. RELATED TOOLS: 3 cards — Sleep Cycle Calculator, Nap Calculator, Sleep Tools category page
11. CATEGORY LINK: text sentence linking back to /sleep-tools
12. SCHEMAS in @section('schema'):
    - WebApplication JSON-LD
    - BreadcrumbList JSON-LD  
    - FAQPage JSON-LD

VANILLA JS LOGIC:
const CAFFEINE_MG = {
  coffee: 95, espresso: 63, energy_drink: 150, tea: 47, cola: 34
};
const HALF_LIFE_HOURS = { low: 4, average: 5, high: 7 }; // caffeine half-life by sensitivity

function calculateCutoff(bedtimeMinutes, sensitivity, drinkType) {
  const halfLife    = HALF_LIFE_HOURS[sensitivity];
  const mg          = CAFFEINE_MG[drinkType];
  // Need < 25mg caffeine at bedtime to not disrupt sleep
  const hoursNeeded = halfLife * Math.log2(mg / 25);
  const cutoffMinutes = bedtimeMinutes - (hoursNeeded * 60);
  return { cutoff: minutesToTime(((cutoffMinutes % 1440) + 1440) % 1440), hoursNeeded };
}

MOBILE: all inputs 100% width, 48px height, buttons 52px, test at 375px
PERFORMANCE: defer all JS, lazy load images
```
