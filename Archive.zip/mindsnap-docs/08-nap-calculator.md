# 08 — Nap Calculator

**Route:** `GET /nap-calculator`  
**File:** `resources/views/calculators/nap-calculator.blade.php`  
**Category:** Sleep  
**SEO Keyword:** `nap calculator` — 400,000/month  

---

## SEO

| Field | Value |
|---|---|
| Title | `Nap Calculator — Best Nap Length & Time | MindSnap` |
| Meta | `Free nap calculator. Find the perfect nap length — 10, 20 or 90 minutes — and the best time to nap without affecting night sleep.` |
| H1 | `Nap Calculator — Find the Best Nap Length for You` |
| Canonical | `https://mindsnap.co/nap-calculator` |
| Category | [Sleep Tools](/sleep-tools) |

---

## What This Page Does

Nap Calculator page on MindSnap.co. Follows the standard 12-section tool page structure.

---

## Inputs

- **Nap start time:** hour + minute selects
- **Nap goal:** Feel refreshed / Deep rest / Full cycle
- **Usual bedtime:** to warn if nap is too close to bedtime

---

## JavaScript Logic

```javascript
const NAP_TYPES = {
  power:  { duration: 10, label: 'Power Nap',    benefit: 'Quick alertness boost' },
  refresh:{ duration: 20, label: 'Refresh Nap',  benefit: 'Alertness + memory boost' },
  full:   { duration: 90, label: 'Full Cycle Nap',benefit: 'Full REM cycle, deep rest' }
};
// Warn if nap end time is within 3 hours of bedtime
function checkBedtimeConflict(napEndMinutes, bedtimeMinutes) {
  const gap = ((bedtimeMinutes - napEndMinutes) + 1440) % 1440;
  return gap < 180; // less than 3 hours warning
}
```

---

## Result Output

Shows 3 nap options as cards: 10-min power nap, 20-min refresh nap, 90-min full cycle. Each shows wake-up time, benefits, and warning if too close to bedtime.

---

## Formula Explanation (Section 7)

Power nap: 10-20 minutes — avoids deep sleep, prevents grogginess. Full nap: 90 minutes — completes one full sleep cycle. Avoid naps ending within 3 hours of bedtime.

---

## Content Section (Section 8)

**H2:** `Napping: How to Get It Right`

Explain the science of napping, sleep inertia (grogginess from waking mid-cycle), why 20-min is the sweet spot for most people, best time of day to nap (1-3pm). ~300 words.

---

## FAQ (Section 9)

| # | Question | Answer |
|---|---|---|
| Q1 | How long should a nap be? | The ideal nap is 10-20 minutes for a quick energy boost, or 90 minutes for a full sleep cycle. Avoid naps of 30-60 minutes which often cause sleep inertia (grogginess). |
| Q2 | What is sleep inertia? | Sleep inertia is the groggy, disoriented feeling when you wake up during deep sleep. A 20-minute nap ends before deep sleep begins, avoiding this effect entirely. |
| Q3 | What is the best time to take a nap? | The optimal nap time is between 1:00pm and 3:00pm when the body's circadian rhythm naturally dips. Napping after 3pm can interfere with night sleep. |
| Q4 | Can napping make up for lost sleep? | Short naps improve alertness and performance but do not fully compensate for chronic sleep deprivation. Use the Sleep Debt Calculator to track your deficit. |
| Q5 | Is MindSnap's Nap Calculator free? | Yes — completely free, no signup, no download. Use it instantly on any device. |

---

## Related Tools (Section 10)

1. **Sleep Cycle Calculator** → `/sleep-calculator`
2. **Caffeine Cut-Off Calculator** → `/caffeine-sleep-calculator`
3. **Sleep Tools** → `/sleep-tools`

---



## Claude Prompt

```
Build the Nap Calculator page for MindSnap.co.

FILE: resources/views/calculators/nap-calculator.blade.php
ROUTE: GET /nap-calculator
CATEGORY COLOUR: #6c63ff

SEO:
Title:    "Nap Calculator — Best Nap Length & Time | MindSnap"
Meta:     "Free nap calculator. Find the perfect nap length — 10, 20 or 90 minutes — and the best time to nap without affecting night sleep."
H1:       "Nap Calculator — Find the Best Nap Length for You"
Canonical: https://mindsnap.co/nap-calculator

BUILD ALL 12 SECTIONS:
1. Breadcrumb: Home > Sleep Tools > Nap Calculator + BreadcrumbList schema
2. H1 + 2-sentence description + trust badges (Free/No Signup/Instant/Mobile Friendly)
3. INPUT FORM:
- **Nap start time:** hour + minute selects
- **Nap goal:** Feel refreshed / Deep rest / Full cycle
- **Usual bedtime:** to warn if nap is too close to bedtime
   Labels above inputs. Units toggle where applicable.
   #e94560 Calculate button, full-width mobile, min 52px height.
4. RESULT: fadeIn animation, large result in #6c63ff, interpretation text
5. SHARE CARD: canvas 420x220px, Copy/WhatsApp/Download buttons
6. HOW TO USE: H2 + 4-5 numbered steps
7. FORMULA: H2 + plain English + formula in styled box
8. CONTENT: H2 "Napping: How to Get It Right" + 300-400 words + 2-3 H3 subheadings
9. FAQ: H2 + Bootstrap accordion + 5 Q&As + FAQPage JSON-LD schema
10. RELATED TOOLS: 3 cards — Sleep Cycle Calculator, Caffeine Cut-Off Calculator, Sleep Tools category page
11. CATEGORY LINK: text sentence linking back to /sleep-tools
12. SCHEMAS in @section('schema'):
    - WebApplication JSON-LD
    - BreadcrumbList JSON-LD  
    - FAQPage JSON-LD

VANILLA JS LOGIC:
const NAP_TYPES = {
  power:  { duration: 10, label: 'Power Nap',    benefit: 'Quick alertness boost' },
  refresh:{ duration: 20, label: 'Refresh Nap',  benefit: 'Alertness + memory boost' },
  full:   { duration: 90, label: 'Full Cycle Nap',benefit: 'Full REM cycle, deep rest' }
};
// Warn if nap end time is within 3 hours of bedtime
function checkBedtimeConflict(napEndMinutes, bedtimeMinutes) {
  const gap = ((bedtimeMinutes - napEndMinutes) + 1440) % 1440;
  return gap < 180; // less than 3 hours warning
}

MOBILE: all inputs 100% width, 48px height, buttons 52px, test at 375px
PERFORMANCE: defer all JS, lazy load images
```
