# 55 — Word Scramble

**Route:** `GET /word-scramble`  
**File:** `resources/views/games/word-scramble.blade.php`  
**SEO Keyword:** `word scramble game online` — 800,000/month  
**H1:** `Word Scramble — Unscramble jumbled words against a timer`  
**Title:** `Word Scramble — Free Online | MindSnap`  
**Meta:** `Free word scramble. Unscramble jumbled words against a timer. Words increase in difficulty. No signup, play instantly.`

---

## What This Game Does

Unscramble jumbled words against a timer. Words increase in difficulty.

---

## JavaScript Logic

```javascript
// Show scrambled word, timer 30s, user types answer
// Categories: Animals, Countries, Foods, Movies, Science
// Score: points per correct word (more for harder/longer words)
// Hint button: reveal one letter (-50% points)
// 10 words per round
```

---

## Result Display

Scrambled word display, timer bar, score counter, hint button, category selector. End of round: correct words list, final score, share card.

---

## SEO Structure
- Breadcrumb: Home > Games > Word Scramble
- Internal links: 2 related games + /games category page
- Schema: WebApplication + FAQPage

---

## Claude Prompt

```
Build the Word Scramble for MindSnap.co.

FILE: resources/views/games/word-scramble.blade.php
ROUTE: GET /word-scramble
CATEGORY COLOUR: #ffc107

SEO:
Title: "Word Scramble — Free Online | MindSnap"
Meta:  "Free word scramble. Unscramble jumbled words against a timer. Words increase in difficulty. No signup."
H1:    "Word Scramble — Unscramble jumbled words against a timer"

GAME LOGIC (Vanilla JS):
// Show scrambled word, timer 30s, user types answer
// Categories: Animals, Countries, Foods, Movies, Science
// Score: points per correct word (more for harder/longer words)
// Hint button: reveal one letter (-50% points)
// 10 words per round

RESULT:
Scrambled word display, timer bar, score counter, hint button, category selector. End of round: correct words list, final score, share card.

SHARE CARD: Canvas 420×220px with result + mindsnap.co URL
Share buttons: Copy, WhatsApp, Download image

BUILD 12 SECTIONS (standard tool page structure):
1.Breadcrumb 2.H1+badges 3.Game interface 4.Score/result
5.Share card 6.How to play 7.About the test 8.Content 300w
9.FAQ+schema 10.Related games 11.Category link 12.Schemas

MOBILE: Large tap targets (min 48px), works on touchscreen, no horizontal scroll
```
