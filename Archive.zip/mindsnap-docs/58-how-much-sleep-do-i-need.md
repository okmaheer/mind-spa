# 58 — SEO Content Page: How Much Sleep Do I Need?

**Route:** `GET /how-much-sleep-do-i-need`  
**File:** `resources/views/seo/how-much-sleep-do-i-need.blade.php`  
**SEO Keyword:** `how much sleep do i need` — 2,000,000/month  
**H1:** `How Much Sleep Do I Need?`  
**Title:** `How Much Sleep Do I Need? — Complete Guide | MindSnap`  
**Meta:** `Guide covering recommended sleep hours by age from newborns to seniors. Free tools included.`  
**Type:** Pure SEO content page — no calculator, just well-structured information

---

## What This Page Is

An informational guide that ranks for the question keyword and funnels readers to the relevant calculator tool. These pages rank for "question-style" searches and are among the highest-traffic content types in the health niche.

---

## Page Structure

```
H1: How Much Sleep Do I Need?
Short intro (50 words): direct answer to the question

H2: The Short Answer
  Direct answer in 2-3 sentences. Keyword used naturally.

H2: [Main Table or Data]
  NHS/CDC recommended sleep hours table. Signs of sleep deprivation. Links to sleep tools.

H2: Factors That Affect [Topic]
  3-4 factors in a list with explanation

H2: How to [Action Related to Topic]
  CTA box linking to the calculator tool

H2: FAQ (5 questions + FAQPage JSON-LD schema)

Related tools section (3 cards)
```

Total content: 400-600 words. No fluff. Accurate and helpful.

---

## Claude Prompt

```
Build the SEO content page "How Much Sleep Do I Need?" for MindSnap.co.

FILE: resources/views/seo/how-much-sleep-do-i-need.blade.php
ROUTE: GET /how-much-sleep-do-i-need

@extends('layouts.app')
@section('title', 'How Much Sleep Do I Need? — Complete Guide | MindSnap')
@section('description', 'Guide covering recommended sleep hours by age from newborns to seniors. Free tools included.')
@section('canonical', 'https://mindsnap.co/how-much-sleep-do-i-need')

This is an informational page — no calculator widget.
Structure: NHS/CDC recommended sleep hours table. Signs of sleep deprivation. Links to sleep tools.

Write 400-600 words of accurate, helpful content.
Include target keyword "how much sleep do i need" naturally 4-6 times.
Use H2/H3 hierarchy. Short paragraphs (2-3 sentences each).
Include a prominent CTA box linking to the relevant calculator tool.
Add FAQPage JSON-LD schema with 5 questions.
Add BreadcrumbList schema.

Internal links: 2-3 related calculators + 1 category page
```
