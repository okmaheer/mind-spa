# 59 — SEO Content Page: What Is a Good BMI?

**Route:** `GET /what-is-a-good-bmi`  
**File:** `resources/views/seo/what-is-a-good-bmi.blade.php`  
**SEO Keyword:** `what is a good bmi` — 600,000/month  
**H1:** `What Is a Good BMI?`  
**Title:** `What Is a Good BMI? — Complete Guide | MindSnap`  
**Meta:** `Informational guide explaining BMI ranges, what each means, and limitations of BMI. Free tools included.`  
**Type:** Pure SEO content page — no calculator, just well-structured information

---

## What This Page Is

An informational guide that ranks for the question keyword and funnels readers to the relevant calculator tool. These pages rank for "question-style" searches and are among the highest-traffic content types in the health niche.

---

## Page Structure

```
H1: What Is a Good BMI?
Short intro (50 words): direct answer to the question

H2: The Short Answer
  Direct answer in 2-3 sentences. Keyword used naturally.

H2: [Main Table or Data]
  BMI category table. Limitations section. Links to BMI calculator and body fat calculator.

H2: Factors That Affect [Topic]
  3-4 factors in a list with explanation

H2: How to [Action Related to Topic]
  CTA box linking to the calculator tool

H2: FAQ (5 questions + FAQPage JSON-LD schema)

Related tools section (3 cards)
```

Total content: 400-600 words. No fluff. Accurate and helpful.

---

## Claude Prompt

```
Build the SEO content page "What Is a Good BMI?" for MindSnap.co.

FILE: resources/views/seo/what-is-a-good-bmi.blade.php
ROUTE: GET /what-is-a-good-bmi

@extends('layouts.app')
@section('title', 'What Is a Good BMI? — Complete Guide | MindSnap')
@section('description', 'Informational guide explaining BMI ranges, what each means, and limitations of BMI. Free tools included.')
@section('canonical', 'https://mindsnap.co/what-is-a-good-bmi')

This is an informational page — no calculator widget.
Structure: BMI category table. Limitations section. Links to BMI calculator and body fat calculator.

Write 400-600 words of accurate, helpful content.
Include target keyword "what is a good bmi" naturally 4-6 times.
Use H2/H3 hierarchy. Short paragraphs (2-3 sentences each).
Include a prominent CTA box linking to the relevant calculator tool.
Add FAQPage JSON-LD schema with 5 questions.
Add BreadcrumbList schema.

Internal links: 2-3 related calculators + 1 category page
```
