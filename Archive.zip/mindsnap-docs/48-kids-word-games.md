# 48 — Kids Word Games

**Route:** `GET /kids/word-games`  
**File:** `resources/views/kids/word-games.blade.php`  
**SEO Keyword:** `word games for kids online`  
**H1:** `Kids Word Games — Free Games for Kids`  
**Title:** `Kids Word Games — Free Online | MindSnap Kids Zone`  
**Meta:** `Free kids word games for children. Spelling, word scramble, fill-in-the-blank and vocabulary games for children. Safe, ad-free, no accounts.`

---

## What This Page Is

Spelling, word scramble, fill-in-the-blank and vocabulary games for children.

### Age Differentiation
Ages 5-7: simple 3-4 letter words. Ages 8-10: common words. Ages 11-12: vocabulary builder.

---

## Features

Word scramble (unscramble letters). Fill in the blank sentences. Rhyme finder. Vocabulary matching.

---

## Kids Zone Design Rules Apply
- Minimum 18px font
- Minimum 48×48px tap targets
- No ads
- Encouraging messages only (no "Wrong!" — use "Great try! The answer was...")
- Stars rating instead of percentage
- Large colourful buttons

---

## Claude Prompt

```
Build the Kids Word Games page for MindSnap.co Kids Zone.

FILE: resources/views/kids/word-games.blade.php
ROUTE: GET /kids/word-games

DESIGN RULES: min 18px font, 48×48px tap targets, NO ads, encouraging messages, star rating.

Content: Word scramble (unscramble letters). Fill in the blank sentences. Rhyme finder. Vocabulary matching.
Age selector inherited from Kids Zone home (localStorage key 'ms_kid_age').
Filter difficulty based on age selection.

SEO:
Title: "Kids Word Games — Free Online | MindSnap Kids Zone"
Meta: "Free kids word games for children. Spelling, word scramble, fill-in-the-blank and vocabulary games for children. Safe, ad-free."
H1: "Kids Word Games — Free Games for Kids"
Internal links: Kids Zone home + 2 related kids activities
FAQPage schema with questions parents ask.
```
