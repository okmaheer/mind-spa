# 52 — Typing Speed Test

**Route:** `GET /typing-speed-test`  
**File:** `resources/views/games/typing-speed-test.blade.php`  
**SEO Keyword:** `typing speed test` — 2,500,000/month  
**H1:** `Typing Speed Test — Test typing speed in WPM with accuracy tracking across 1, 2, or 3 minute modes`  
**Title:** `Typing Speed Test — Free Online | MindSnap`  
**Meta:** `Free typing speed test. Test typing speed in WPM with accuracy tracking across 1, 2, or 3 minute modes. No signup, play instantly.`

---

## What This Game Does

Test typing speed in WPM with accuracy tracking across 1, 2, or 3 minute modes.

---

## JavaScript Logic

```javascript
const paragraphs = ['The quick brown fox jumps over the lazy dog...', ...10 total];
let typed=0, errors=0, startTime=null;
// Start timer on first keypress
// Compare each character in real-time: green=correct, red=wrong
// Calculate WPM = (words typed / time in minutes), accuracy = ((total-errors)/total)*100
// Show percentile: "You type faster than X% of people" 
```

---

## Result Display

WPM counter, accuracy %, error count, time remaining bar. Result: WPM + accuracy + percentile. Share card: 'I type 87 WPM at 96% accuracy — beat me!'

---

## SEO Structure
- Breadcrumb: Home > Games > Typing Speed Test
- Internal links: 2 related games + /games category page
- Schema: WebApplication + FAQPage

---

## Claude Prompt

```
Build the Typing Speed Test for MindSnap.co.

FILE: resources/views/games/typing-speed-test.blade.php
ROUTE: GET /typing-speed-test
CATEGORY COLOUR: #ffc107

SEO:
Title: "Typing Speed Test — Free Online | MindSnap"
Meta:  "Free typing speed test. Test typing speed in WPM with accuracy tracking across 1, 2, or 3 minute modes. No signup."
H1:    "Typing Speed Test — Test typing speed in WPM with accuracy tracking across 1, 2, or 3 minute modes"

GAME LOGIC (Vanilla JS):
const paragraphs = ['The quick brown fox jumps over the lazy dog...', ...10 total];
let typed=0, errors=0, startTime=null;
// Start timer on first keypress
// Compare each character in real-time: green=correct, red=wrong
// Calculate WPM = (words typed / time in minutes), accuracy = ((total-errors)/total)*100
// Show percentile: "You type faster than X% of people" 

RESULT:
WPM counter, accuracy %, error count, time remaining bar. Result: WPM + accuracy + percentile. Share card: 'I type 87 WPM at 96% accuracy — beat me!'

SHARE CARD: Canvas 420×220px with result + mindsnap.co URL
Share buttons: Copy, WhatsApp, Download image

BUILD 12 SECTIONS (standard tool page structure):
1.Breadcrumb 2.H1+badges 3.Game interface 4.Score/result
5.Share card 6.How to play 7.About the test 8.Content 300w
9.FAQ+schema 10.Related games 11.Category link 12.Schemas

MOBILE: Large tap targets (min 48px), works on touchscreen, no horizontal scroll
```
