# 50 — Kids Animal Quiz

**Route:** `GET /kids/animal-quiz`  
**File:** `resources/views/kids/animal-quiz.blade.php`  
**SEO Keyword:** `animal quiz for kids`  
**H1:** `Kids Animal Quiz — Free Games for Kids`  
**Title:** `Kids Animal Quiz — Free Online | MindSnap Kids Zone`  
**Meta:** `Free kids animal quiz for children. Fun animal facts quiz testing knowledge of habitats, diets, sounds and animal families. Safe, ad-free, no accounts.`

---

## What This Page Is

Fun animal facts quiz testing knowledge of habitats, diets, sounds and animal families.

### Age Differentiation
All ages — questions scaled by difficulty selector.

---

## Features

Animal sounds, habitats, diets, baby animal names, fastest/biggest/smallest. Fun facts revealed after each answer.

---

## Kids Zone Design Rules Apply
- Minimum 18px font
- Minimum 48×48px tap targets
- No ads
- Encouraging messages only (no "Wrong!" — use "Great try! The answer was...")
- Stars rating instead of percentage
- Large colourful buttons

---

## Claude Prompt

```
Build the Kids Animal Quiz page for MindSnap.co Kids Zone.

FILE: resources/views/kids/animal-quiz.blade.php
ROUTE: GET /kids/animal-quiz

DESIGN RULES: min 18px font, 48×48px tap targets, NO ads, encouraging messages, star rating.

Content: Animal sounds, habitats, diets, baby animal names, fastest/biggest/smallest. Fun facts revealed after each answer.
Age selector inherited from Kids Zone home (localStorage key 'ms_kid_age').
Filter difficulty based on age selection.

SEO:
Title: "Kids Animal Quiz — Free Online | MindSnap Kids Zone"
Meta: "Free kids animal quiz for children. Fun animal facts quiz testing knowledge of habitats, diets, sounds and animal families. Safe, ad-free."
H1: "Kids Animal Quiz — Free Games for Kids"
Internal links: Kids Zone home + 2 related kids activities
FAQPage schema with questions parents ask.
```
