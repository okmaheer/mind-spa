# 51 — Kids Spelling Quiz

**Route:** `GET /kids/spelling-quiz`  
**File:** `resources/views/kids/spelling-quiz.blade.php`  
**SEO Keyword:** `spelling quiz for kids`  
**H1:** `Kids Spelling Quiz — Free Games for Kids`  
**Title:** `Kids Spelling Quiz — Free Online | MindSnap Kids Zone`  
**Meta:** `Free kids spelling quiz for children. Grade-appropriate spelling quiz helping children practice common English words. Safe, ad-free, no accounts.`

---

## What This Page Is

Grade-appropriate spelling quiz helping children practice common English words.

### Age Differentiation
Grade 1 (ages 5-7): 3-4 letter words. Grade 2-3 (8-10): common words. Grade 4-6 (11-12): harder vocabulary.

---

## Features

Word displayed → hidden → user types spelling → instant feedback. Audio pronunciation button (browser TTS API).

---

## Kids Zone Design Rules Apply
- Minimum 18px font
- Minimum 48×48px tap targets
- No ads
- Encouraging messages only (no "Wrong!" — use "Great try! The answer was...")
- Stars rating instead of percentage
- Large colourful buttons

---

## Claude Prompt

```
Build the Kids Spelling Quiz page for MindSnap.co Kids Zone.

FILE: resources/views/kids/spelling-quiz.blade.php
ROUTE: GET /kids/spelling-quiz

DESIGN RULES: min 18px font, 48×48px tap targets, NO ads, encouraging messages, star rating.

Content: Word displayed → hidden → user types spelling → instant feedback. Audio pronunciation button (browser TTS API).
Age selector inherited from Kids Zone home (localStorage key 'ms_kid_age').
Filter difficulty based on age selection.

SEO:
Title: "Kids Spelling Quiz — Free Online | MindSnap Kids Zone"
Meta: "Free kids spelling quiz for children. Grade-appropriate spelling quiz helping children practice common English words. Safe, ad-free."
H1: "Kids Spelling Quiz — Free Games for Kids"
Internal links: Kids Zone home + 2 related kids activities
FAQPage schema with questions parents ask.
```
