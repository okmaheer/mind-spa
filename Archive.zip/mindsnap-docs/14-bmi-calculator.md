# 14 — BMI Calculator

**Route:** `GET /bmi-calculator`  
**File:** `resources/views/calculators/bmi-calculator.blade.php`  
**Category:** Fitness  
**SEO Keyword:** `bmi calculator` — 4,000,000/month  

---

## SEO

| Field | Value |
|---|---|
| Title | `BMI Calculator — Free Body Mass Index Tool | MindSnap` |
| Meta | `Free BMI calculator for adults and children. Enter your height and weight to get your Body Mass Index and healthy weight range instantly.` |
| H1 | `BMI Calculator — Check Your Body Mass Index Free` |
| Canonical | `https://mindsnap.co/bmi-calculator` |
| Category | [Fitness Tools](/fitness-tools) |

---

## What This Page Does

BMI Calculator page on MindSnap.co. Follows the standard 12-section tool page structure.

---

## Inputs

- **Weight:** number input + kg/lbs toggle
- **Height:** number input + cm / ft+in toggle  
- **Age:** optional (for contextual info)
- **Gender:** optional (for contextual info)

---

## JavaScript Logic

```javascript
function calcBMI(weightKg, heightM) {
  return +(weightKg / (heightM * heightM)).toFixed(1);
}
function getBMICategory(bmi) {
  if (bmi < 18.5) return { label:'Underweight', colour:'#17a2b8', tip:'Consider consulting a doctor.' };
  if (bmi < 25)   return { label:'Normal Weight', colour:'#28a745', tip:'Keep up the good work!' };
  if (bmi < 30)   return { label:'Overweight', colour:'#ffc107', tip:'Small lifestyle changes can help.' };
  return           { label:'Obese', colour:'#dc3545', tip:'Consult a healthcare provider.' };
}
function getHealthyWeightRange(heightM) {
  return { min:+(18.5*heightM*heightM).toFixed(1), max:+(24.9*heightM*heightM).toFixed(1) };
}
```

---

## Result Output

Large BMI number in category colour + category label + visual horizontal gauge (CSS, colour-coded) + healthy weight range for their height. Important: disclaimer that BMI is one indicator, not a full health assessment.

---

## Formula Explanation (Section 7)

BMI = weight(kg) / height(m)². Example: 70kg / (1.75m)² = 22.9. Categories: <18.5 Underweight, 18.5-24.9 Normal, 25-29.9 Overweight, ≥30 Obese (WHO classification).

---

## Content Section (Section 8)

**H2:** `Understanding Your BMI — What the Numbers Mean`

Explain BMI, its limitations (doesn't account for muscle mass), healthy ranges by age and sex, when to see a doctor. ~350 words.

---

## FAQ (Section 9)

| # | Question | Answer |
|---|---|---|
| Q1 | What is a healthy BMI for adults? | For most adults, a BMI between 18.5 and 24.9 is considered healthy. BMI 25-29.9 is overweight and 30+ is obese according to WHO classification. |
| Q2 | Is BMI accurate for athletes? | BMI can misclassify athletes as overweight or obese because muscle weighs more than fat. Athletes and very muscular individuals should use body fat percentage as a more accurate measure. |
| Q3 | Does BMI differ for men and women? | The BMI formula is the same for both, but health risks at the same BMI differ slightly. Women naturally carry more body fat than men at equivalent BMI values. |
| Q4 | What is a healthy BMI for children? | For children and teens, BMI is age and sex specific, expressed as a percentile. A healthy range is the 5th to 85th percentile. Use a paediatric BMI chart for under-18s. |
| Q5 | Is MindSnap's BMI Calculator free? | Yes — completely free, no signup, no download. Use it instantly on any device. |

---

## Related Tools (Section 10)

1. **Body Fat Calculator** → `/body-fat-calculator`
2. **Ideal Weight Calculator** → `/ideal-weight-calculator`
3. **Fitness Tools** → `/fitness-tools`

---



## Claude Prompt

```
Build the BMI Calculator page for MindSnap.co.

FILE: resources/views/calculators/bmi-calculator.blade.php
ROUTE: GET /bmi-calculator
CATEGORY COLOUR: #28a745

SEO:
Title:    "BMI Calculator — Free Body Mass Index Tool | MindSnap"
Meta:     "Free BMI calculator for adults and children. Enter your height and weight to get your Body Mass Index and healthy weight range instantly."
H1:       "BMI Calculator — Check Your Body Mass Index Free"
Canonical: https://mindsnap.co/bmi-calculator

BUILD ALL 12 SECTIONS:
1. Breadcrumb: Home > Fitness Tools > BMI Calculator + BreadcrumbList schema
2. H1 + 2-sentence description + trust badges (Free/No Signup/Instant/Mobile Friendly)
3. INPUT FORM:
- **Weight:** number input + kg/lbs toggle
- **Height:** number input + cm / ft+in toggle  
- **Age:** optional (for contextual info)
- **Gender:** optional (for contextual info)
   Labels above inputs. Units toggle where applicable.
   #e94560 Calculate button, full-width mobile, min 52px height.
4. RESULT: fadeIn animation, large result in #28a745, interpretation text
5. SHARE CARD: canvas 420x220px, Copy/WhatsApp/Download buttons
6. HOW TO USE: H2 + 4-5 numbered steps
7. FORMULA: H2 + plain English + formula in styled box
8. CONTENT: H2 "Understanding Your BMI — What the Numbers Mean" + 300-400 words + 2-3 H3 subheadings
9. FAQ: H2 + Bootstrap accordion + 5 Q&As + FAQPage JSON-LD schema
10. RELATED TOOLS: 3 cards — Body Fat Calculator, Ideal Weight Calculator, Fitness Tools category page
11. CATEGORY LINK: text sentence linking back to /fitness-tools
12. SCHEMAS in @section('schema'):
    - WebApplication JSON-LD
    - BreadcrumbList JSON-LD  
    - FAQPage JSON-LD

VANILLA JS LOGIC:
function calcBMI(weightKg, heightM) {
  return +(weightKg / (heightM * heightM)).toFixed(1);
}
function getBMICategory(bmi) {
  if (bmi < 18.5) return { label:'Underweight', colour:'#17a2b8', tip:'Consider consulting a doctor.' };
  if (bmi < 25)   return { label:'Normal Weight', colour:'#28a745', tip:'Keep up the good work!' };
  if (bmi < 30)   return { label:'Overweight', colour:'#ffc107', tip:'Small lifestyle changes can help.' };
  return           { label:'Obese', colour:'#dc3545', tip:'Consult a healthcare provider.' };
}
function getHealthyWeightRange(heightM) {
  return { min:+(18.5*heightM*heightM).toFixed(1), max:+(24.9*heightM*heightM).toFixed(1) };
}

MOBILE: all inputs 100% width, 48px height, buttons 52px, test at 375px
PERFORMANCE: defer all JS, lazy load images
```
