# 63 — Google AdSense Integration

---

## Ad Slot Component

**File:** `resources/views/components/ad-slot.blade.php`

```blade
@props(['position' => 'inline', 'size' => 'responsive'])

@if(config('adsense.enabled') && app()->environment('production'))
<div class="ad-container ad-{{ $position }}"
     style="min-height: {{ $size === 'banner' ? '90px' : '250px' }};">
  <ins class="adsbygoogle"
       style="display:block"
       data-ad-client="{{ config('adsense.publisher_id') }}"
       data-ad-slot="{{ config('adsense.slots.' . $position) }}"
       data-ad-format="auto"
       data-full-width-responsive="true">
  </ins>
  <script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
</div>
@endif
```

---

## Placement Rules

| Position | Placement | Size | When |
|---|---|---|---|
| `top` | Below H1 + badges, above tool form | 728×90 leaderboard | Desktop only |
| `sidebar` | Right column, desktop only | 300×250 rectangle | Desktop (≥1200px) |
| `below_result` | After result appears, before How to Use | 336×280 large rectangle | All devices |
| `between_sections` | Between content and FAQ | 320×50 mobile banner | Mobile only |

**Never place ads:**
- Inside the calculator form itself
- Inside quiz question interface
- In Kids Zone (zero ads)
- Inside error states

---

## config/adsense.php

```php
return [
  'enabled'      => env('ADSENSE_ENABLED', false),
  'publisher_id' => env('ADSENSE_PUBLISHER_ID'),
  'slots' => [
    'top'           => env('ADSENSE_SLOT_TOP'),
    'sidebar'       => env('ADSENSE_SLOT_SIDEBAR'),
    'below_result'  => env('ADSENSE_SLOT_BELOW_RESULT'),
    'between'       => env('ADSENSE_SLOT_BETWEEN'),
  ]
];
```

---

## Claude Prompt

```
Build the AdSense integration for MindSnap.co.

FILES:
- resources/views/components/ad-slot.blade.php
- config/adsense.php

RULES:
- Only render ads when APP_ENV=production AND ADSENSE_ENABLED=true
- Set min-height on all ad containers to prevent CLS (layout shift)
- Lazy load ads: inject adsbygoogle.push() only after page content is interactive
- Never show ads in /kids/* routes (detect in middleware or component)
- Add <x-ad-slot position="below_result"> to every calculator/quiz page template

PLACEMENTS:
- Add to tool-page layout in sections 4 (below result) and 8 (between content sections)
- sidebar: visible only on lg+ breakpoint via Bootstrap d-none d-lg-block
```
