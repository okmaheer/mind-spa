# 35 — General Knowledge Quiz

**Route:** `GET /quiz/general-knowledge`  
**File:** Uses `resources/views/quizzes/quiz.blade.php` (shared template)  
**SEO Keyword:** `general knowledge quiz` — 2,000,000/month  
**H1:** `General Knowledge Quiz — Test Your Knowledge Free`  
**Title:** `General Knowledge Quiz — Free Online Questions | MindSnap`  
**Meta:** `Free general knowledge quiz. Test your general knowledge across history, science, geography, pop culture and more. No signup needed.`

---

## What This Quiz Contains

Test your general knowledge across history, science, geography, pop culture and more.

- **Questions:** 10 per session (randomised from DB pool)
- **Difficulty:** Easy → Medium → Hard progression
- **Time limit:** Optional 30 seconds per question
- **Age group:** All (teens and adults)

---

## FAQ

| # | Question | Answer |
|---|---|---|
| Q1 | What country has the most natural lakes? | Canada — with over 60% of the world's lakes. |
| Q2 | What is the chemical symbol for gold? | Au — from the Latin 'aurum', meaning gold. |
| Q3 | Which planet is closest to the Sun? | Mercury — it orbits the Sun every 88 Earth days. |
| Q4 | Who painted the Mona Lisa? | Leonardo da Vinci — painted between 1503 and 1519. |
| Q5 | Is this general knowledge quiz free? | Yes — completely free, no signup, instant results. |

---

## SEO Structure

- Breadcrumb: Home > Quizzes > General Knowledge Quiz
- Internal links: 2 related quizzes + /quizzes listing page
- Schema: BreadcrumbList + FAQPage

---

## Database Seed

Ask Claude to generate 50 general knowledge quiz questions in the quiz_questions table format:
```
category: 'general knowledge'
difficulty: mix of easy/medium/hard
age_group: 'all'
```

---

## Claude Prompt

```
Build the General Knowledge Quiz page for MindSnap.co.
Route: /quiz/general-knowledge
This page uses the shared quiz.blade.php template from Feature 34.

Controller method: QuizController@show('general knowledge')
Load 10 random questions from quiz_questions where category='general knowledge'

SEO:
Title: "General Knowledge Quiz — Free Online Questions | MindSnap"
Meta:  "Free general knowledge quiz. Test your general knowledge across history, science, geography, pop culture and more. No signup."
H1:    "General Knowledge Quiz — Test Your Knowledge Free"
Canonical: https://mindsnap.co/quiz/general-knowledge

Add to controller: $meta array with title, description, h1, colour (#e94560), keyword
Pass to quiz.blade.php view

Generate 50 seed questions for this category in QuizSeeder.php
Include: question, option_a-d, correct_option, explanation, difficulty, age_group='all'
```
