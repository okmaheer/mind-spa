# 05 — Category Pages (All 8)

All 8 category pages use one shared template: `resources/views/categories/show.blade.php`

---

## Category Data

| Category | Route | H1 | Colour | Keyword | Searches |
|---|---|---|---|---|---|
| Sleep | /sleep-tools | Sleep Tools — Free Sleep Calculators Online | #6c63ff | free sleep tools online | 800K |
| Fitness | /fitness-tools | Fitness Calculators — Free Health Tools | #28a745 | free fitness calculators | 1.2M |
| Nutrition | /nutrition-tools | Nutrition Tools — Free Diet Calculators | #fd7e14 | free nutrition calculators | 600K |
| Quizzes | /quizzes | Free Quiz Website — Test Your Knowledge | #e94560 | free quiz website | 2M |
| Kids Zone | /kids | Kids Zone — Free Learning Games for Children | #17a2b8 | free learning games for kids | 900K |
| Life Tools | /life-tools | Life Calculators — Free Date & Time Tools | #6f42c1 | free life calculators | 400K |
| Games | /games | Free Brain Games Online — Play & Learn | #ffc107 | free brain games online | 1.5M |
| Daily | /daily | Daily Brain Challenge — New Quiz Every Day | #e94560 | daily brain challenge | 300K |

---

## 5 Sections per Category Page

1. **Category Hero** — category gradient bg, emoji, H1, breadcrumb + BreadcrumbList schema
2. **Tools Grid** — Bootstrap col-lg-4 col-md-6 col-12. Cards: 4px left border in cat colour, H3 linked, description, searches badge, "Use Free Tool →"
3. **About Section** — 150-200 words, H2 + 2x H3, keyword 3-4 times naturally
4. **Related Categories** — 3 cards linking to other categories
5. **FAQ** — 5 questions + FAQPage JSON-LD schema

---

## Title Tag Formulas per Category

```
/sleep-tools:   "Free Sleep Tools & Calculators Online | MindSnap"
/fitness-tools: "Free Fitness Calculators Online | MindSnap"
/quizzes:       "Free Quiz Website — Test Your Knowledge Online | MindSnap"
/kids:          "Free Learning Games for Kids Online | MindSnap"
/games:         "Free Brain Games Online — Play & Learn | MindSnap"
```

---

## Claude Prompt

```
Build the category page template for MindSnap.co.

FILE: resources/views/categories/show.blade.php
CONTROLLER: CategoryController — each method passes $category data array

The template receives:
$category = [
  'name'     => 'Sleep Tools',
  'colour'   => '#6c63ff',
  'h1'       => 'Sleep Tools — Free Sleep Calculators Online',
  'keyword'  => 'free sleep tools online',
  'tools'    => [...], // array of tool arrays
]

Build 5 sections as specified.
Each tool card: left border 4px solid $category['colour'], linked H3, description, searches badge, CTA.
About section: 150-200 words, include $category['keyword'] naturally 3-4 times.
BreadcrumbList + FAQPage JSON-LD schemas.
Mobile: cards stack to 1 column at 768px.
```
