# 33 — Life Percentage Calculator

**Route:** `GET /life-percentage-calculator`  
**File:** `resources/views/calculators/life-percentage-calculator.blade.php`  
**Category:** Life  
**SEO Keyword:** `what percentage of life have i lived` — 200,000/month  

---

## SEO

| Field | Value |
|---|---|
| Title | `Life Percentage Calculator — How Much Life Is Left? | MindSnap` |
| Meta | `Free life percentage calculator. Find what percentage of your expected lifespan you have lived. Thought-provoking and shareable. No signup.` |
| H1 | `Life Percentage Calculator — What % of Your Life Have You Lived?` |
| Canonical | `https://mindsnap.co/life-percentage-calculator` |
| Category | [Life Tools](/life-tools) |

---

## What This Page Does

Life Percentage Calculator page on MindSnap.co. Follows the standard 12-section tool page structure.

---

## Inputs

- **Date of birth:** date picker
- **Country:** select (sets life expectancy data)
- **Custom life expectancy:** optional override

---

## JavaScript Logic

```javascript
const LIFE_EXPECTANCY = {
  'us': {male:76, female:81}, 'uk': {male:79, female:83},
  'ca': {male:80, female:84}, 'au': {male:81, female:85},
  // ... global averages
  'global': {male:72, female:76}
};
function calcLifePct(dob, country, gender, customExpectancy) {
  const ageMs = Date.now() - dob.getTime();
  const ageYears = ageMs / 31536000000;
  const expectancy = customExpectancy || LIFE_EXPECTANCY[country][gender];
  const pct = (ageYears / expectancy) * 100;
  const remaining = expectancy - ageYears;
  return { pct: +pct.toFixed(1), remaining: +remaining.toFixed(1), ageYears: +ageYears.toFixed(1) };
}
```

---

## Result Output

Large percentage display + a progress bar (life timeline) + years remaining estimate + one motivational or philosophical note. Highly shareable — 'I have lived X% of my life'.

---

## Formula Explanation (Section 7)

Life lived % = (Current age ÷ Life expectancy) × 100. Life expectancy data sourced from WHO by country and gender.

---

## Content Section (Section 8)

**H2:** `Your Life in Perspective — Making Every Year Count`

Reflective content on using this data constructively, the concept of 'memento mori' as motivation not morbidity, research on how thinking about time increases life satisfaction. ~300 words.

---

## FAQ (Section 9)

| # | Question | Answer |
|---|---|---|
| Q1 | Is this calculation morbid? | Many people find this calculator motivating rather than morbid. Research shows that awareness of time's passage can increase focus on meaningful goals and reduce time spent on trivial concerns. |
| Q2 | Where does the life expectancy data come from? | Life expectancy data is sourced from the World Health Organization (WHO) and updated periodically. These are population averages — individual life expectancy varies greatly based on health and lifestyle. |
| Q3 | How does lifestyle affect life expectancy? | Non-smoking, regular exercise, healthy diet, and not being obese can add 10-14 years to average life expectancy according to major epidemiological studies. |
| Q4 | Does this account for improvements in medicine? | Current data reflects today's life expectancy averages. Future medical advances may extend these significantly. The calculator uses current WHO data as a baseline estimate. |
| Q5 | Is MindSnap's Life Percentage Calculator free? | Yes — completely free, no signup, no download. Use it instantly on any device. |

---

## Related Tools (Section 10)

1. **Age Calculator** → `/age-calculator`
2. **Retirement Countdown** → `/retirement-calculator`
3. **Life Tools** → `/life-tools`

---



## Claude Prompt

```
Build the Life Percentage Calculator page for MindSnap.co.

FILE: resources/views/calculators/life-percentage-calculator.blade.php
ROUTE: GET /life-percentage-calculator
CATEGORY COLOUR: #6f42c1

SEO:
Title:    "Life Percentage Calculator — How Much Life Is Left? | MindSnap"
Meta:     "Free life percentage calculator. Find what percentage of your expected lifespan you have lived. Thought-provoking and shareable. No signup."
H1:       "Life Percentage Calculator — What % of Your Life Have You Lived?"
Canonical: https://mindsnap.co/life-percentage-calculator

BUILD ALL 12 SECTIONS:
1. Breadcrumb: Home > Life Tools > Life Percentage Calculator + BreadcrumbList schema
2. H1 + 2-sentence description + trust badges (Free/No Signup/Instant/Mobile Friendly)
3. INPUT FORM:
- **Date of birth:** date picker
- **Country:** select (sets life expectancy data)
- **Custom life expectancy:** optional override
   Labels above inputs. Units toggle where applicable.
   #e94560 Calculate button, full-width mobile, min 52px height.
4. RESULT: fadeIn animation, large result in #6f42c1, interpretation text
5. SHARE CARD: canvas 420x220px, Copy/WhatsApp/Download buttons
6. HOW TO USE: H2 + 4-5 numbered steps
7. FORMULA: H2 + plain English + formula in styled box
8. CONTENT: H2 "Your Life in Perspective — Making Every Year Count" + 300-400 words + 2-3 H3 subheadings
9. FAQ: H2 + Bootstrap accordion + 5 Q&As + FAQPage JSON-LD schema
10. RELATED TOOLS: 3 cards — Age Calculator, Retirement Countdown, Life Tools category page
11. CATEGORY LINK: text sentence linking back to /life-tools
12. SCHEMAS in @section('schema'):
    - WebApplication JSON-LD
    - BreadcrumbList JSON-LD  
    - FAQPage JSON-LD

VANILLA JS LOGIC:
const LIFE_EXPECTANCY = {
  'us': {male:76, female:81}, 'uk': {male:79, female:83},
  'ca': {male:80, female:84}, 'au': {male:81, female:85},
  // ... global averages
  'global': {male:72, female:76}
};
function calcLifePct(dob, country, gender, customExpectancy) {
  const ageMs = Date.now() - dob.getTime();
  const ageYears = ageMs / 31536000000;
  const expectancy = customExpectancy || LIFE_EXPECTANCY[country][gender];
  const pct = (ageYears / expectancy) * 100;
  const remaining = expectancy - ageYears;
  return { pct: +pct.toFixed(1), remaining: +remaining.toFixed(1), ageYears: +ageYears.toFixed(1) };
}

MOBILE: all inputs 100% width, 48px height, buttons 52px, test at 375px
PERFORMANCE: defer all JS, lazy load images
```
