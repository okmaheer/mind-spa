# 04 — Homepage

**Route:** `GET /`  
**File:** `resources/views/home.blade.php`  
**SEO Keyword:** `free health tools online`  
**H1:** `Free Tools for a Sharper Mind & Healthier Life`  
**Title:** `Free Health Calculators & Brain Quizzes for Everyone | MindSnap`  
**Meta:** `MindSnap — free health tools, sleep calculators and brain quizzes for all ages. No signup. Works worldwide.`

---

## 7 Sections in Order

### Section 1 — Hero
- Background: gradient `#1a1a2e` → `#0f3460`, min-height 85vh
- H1 (white, clamp 2rem to 3rem)
- Subtext: "Sleep calculators, fitness tools, brain quizzes — all free, no signup, for everyone"
- Two buttons: `[Explore Tools]` (#e94560) + `[Take Daily Quiz]` (outline-light)
- Stats row (CSS count-up on scroll): `40+ Free Tools` / `5M+ Searches/Month` / `190+ Countries` / `0 Signup Needed`

### Section 2 — Category Grid *(primary SEO section)*
- H2: "What Would You Like to Do Today?"
- 8 cards, Bootstrap col-lg-3 col-md-4 col-6
- Each: category gradient bg, emoji (3rem), name, tool count, "Explore →" link
- Cards link to all 8 category pages — primary internal linking hub

### Section 3 — Popular Tools
- H2: "Most Popular Tools"
- 6 tool cards, horizontal scroll mobile / 3-col desktop
- Each: white card, 4px category-colour top border, icon, name, searches badge, CTA

| Tool | Searches | Link |
|---|---|---|
| Sleep Calculator | 2.2M/mo | /sleep-calculator |
| TDEE Calculator | 3.5M/mo | /calorie-calculator |
| BMI Calculator | 4M/mo | /bmi-calculator |
| GK Quiz | 2M/mo | /quiz/general-knowledge |
| Typing Speed Test | 2.5M/mo | /typing-speed-test |
| Age Calculator | 1.8M/mo | /age-calculator |

### Section 4 — Daily Quiz Banner
- Full-width gradient `#e94560` → `#c0392b`
- Today's quiz topic from DB + difficulty stars
- "Start Today's Quiz →" white button + countdown to midnight

### Section 5 — Kids Zone Highlight
- `#e8f7f7` background
- H2: "Fun Learning for Kids 👶"
- 4 compact activity cards
- "No ads. No data. No accounts." message

### Section 6 — How It Works
- `#f8f9fa` background, 3 steps
- Pick a tool → Instant results → Share with friends

### Section 7 — Footer

---

## JSON-LD Schema (add to @section('schema'))

```json
{
  "@context": "https://schema.org",
  "@type": "WebSite",
  "name": "MindSnap",
  "url": "https://mindsnap.co",
  "potentialAction": {
    "@type": "SearchAction",
    "target": "https://mindsnap.co/search?q={search_term_string}",
    "query-input": "required name=search_term_string"
  }
}
```

---

## Claude Prompt

```
Build the MindSnap.co homepage.

FILE: resources/views/home.blade.php
CONTROLLER: HomeController@index passes: $dailyQuiz, $popularTools

@extends('layouts.app')
@section('title','Free Health Calculators & Brain Quizzes for Everyone | MindSnap')
@section('description','MindSnap — free health tools, sleep calculators and brain quizzes for all ages. No signup. Works worldwide.')
@section('canonical','https://mindsnap.co')

Build all 7 sections as specified above.
Add WebSite JSON-LD schema in @section('schema').
CSS count-up animation using Intersection Observer for stats row.
Mobile: all sections stack correctly at 375px, no horizontal scroll.
Category grid cards have hover lift effect (transform translateY -4px).
```
