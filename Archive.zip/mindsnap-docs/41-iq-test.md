# 41 — IQ Test Questions

**Route:** `GET /iq-test`  
**File:** Uses `resources/views/quizzes/quiz.blade.php` (shared template)  
**SEO Keyword:** `free iq test questions` — 1,000,000/month  
**H1:** `IQ Test Questions — Test Your Knowledge Free`  
**Title:** `IQ Test Questions — Free Online Questions | MindSnap`  
**Meta:** `Free iq test questions. Free IQ test with pattern recognition, logic and spatial reasoning questions. No signup needed.`

---

## What This Quiz Contains

Free IQ test with pattern recognition, logic and spatial reasoning questions.

- **Questions:** 10 per session (randomised from DB pool)
- **Difficulty:** Easy → Medium → Hard progression
- **Time limit:** Optional 30 seconds per question
- **Age group:** All (teens and adults)

---

## FAQ

| # | Question | Answer |
|---|---|---|
| Q1 | What comes next: 2, 4, 8, 16, __? | 32 — each number doubles (×2 pattern). |
| Q2 | If all roses are flowers and some flowers fade quickly, can we conclude all roses fade quickly? | No — this is a logical fallacy. Some flowers fade quickly does not mean all do. |
| Q3 | Which number is the odd one out: 3, 5, 7, 9, 11? | 9 — it is the only non-prime number in the list. |
| Q4 | A bat and ball cost £1.10. The bat costs £1 more than the ball. How much is the ball? | 5p (not 10p) — if ball=5p then bat=£1.05, total=£1.10. |
| Q5 | Is this iq test questions free? | Yes — completely free, no signup, instant results. |

---

## SEO Structure

- Breadcrumb: Home > Quizzes > IQ Test Questions
- Internal links: 2 related quizzes + /quizzes listing page
- Schema: BreadcrumbList + FAQPage

---

## Database Seed

Ask Claude to generate 50 iq test questions questions in the quiz_questions table format:
```
category: 'iq test'
difficulty: mix of easy/medium/hard
age_group: 'all'
```

---

## Claude Prompt

```
Build the IQ Test Questions page for MindSnap.co.
Route: /iq-test
This page uses the shared quiz.blade.php template from Feature 34.

Controller method: QuizController@show('iq test')
Load 10 random questions from quiz_questions where category='iq test'

SEO:
Title: "IQ Test Questions — Free Online Questions | MindSnap"
Meta:  "Free iq test questions. Free IQ test with pattern recognition, logic and spatial reasoning questions. No signup."
H1:    "IQ Test Questions — Test Your Knowledge Free"
Canonical: https://mindsnap.co/iq-test

Add to controller: $meta array with title, description, h1, colour (#e94560), keyword
Pass to quiz.blade.php view

Generate 50 seed questions for this category in QuizSeeder.php
Include: question, option_a-d, correct_option, explanation, difficulty, age_group='all'
```
