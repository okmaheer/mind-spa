# 54 — Memory Test

**Route:** `GET /memory-test`  
**File:** `resources/views/games/memory-test.blade.php`  
**SEO Keyword:** `memory test online` — 500,000/month  
**H1:** `Memory Test — Test visual memory by remembering sequences of highlighted tiles that increase in difficulty`  
**Title:** `Memory Test — Free Online | MindSnap`  
**Meta:** `Free memory test. Test visual memory by remembering sequences of highlighted tiles that increase in difficulty. No signup, play instantly.`

---

## What This Game Does

Test visual memory by remembering sequences of highlighted tiles that increase in difficulty.

---

## JavaScript Logic

```javascript
// 3x3 grid of tiles
// Show a sequence (highlight tiles in order for 1 second each)
// User clicks tiles in same order
// Each successful round: add one more tile to sequence
// Track max level reached
// Score = length of longest correct sequence
```

---

## Result Display

Visual grid with colour flash sequence. Score = max level reached. Average adult: level 7. Share: 'I reached level 9 on the Memory Test!'

---

## SEO Structure
- Breadcrumb: Home > Games > Memory Test
- Internal links: 2 related games + /games category page
- Schema: WebApplication + FAQPage

---

## Claude Prompt

```
Build the Memory Test for MindSnap.co.

FILE: resources/views/games/memory-test.blade.php
ROUTE: GET /memory-test
CATEGORY COLOUR: #ffc107

SEO:
Title: "Memory Test — Free Online | MindSnap"
Meta:  "Free memory test. Test visual memory by remembering sequences of highlighted tiles that increase in difficulty. No signup."
H1:    "Memory Test — Test visual memory by remembering sequences of highlighted tiles that increase in difficulty"

GAME LOGIC (Vanilla JS):
// 3x3 grid of tiles
// Show a sequence (highlight tiles in order for 1 second each)
// User clicks tiles in same order
// Each successful round: add one more tile to sequence
// Track max level reached
// Score = length of longest correct sequence

RESULT:
Visual grid with colour flash sequence. Score = max level reached. Average adult: level 7. Share: 'I reached level 9 on the Memory Test!'

SHARE CARD: Canvas 420×220px with result + mindsnap.co URL
Share buttons: Copy, WhatsApp, Download image

BUILD 12 SECTIONS (standard tool page structure):
1.Breadcrumb 2.H1+badges 3.Game interface 4.Score/result
5.Share card 6.How to play 7.About the test 8.Content 300w
9.FAQ+schema 10.Related games 11.Category link 12.Schemas

MOBILE: Large tap targets (min 48px), works on touchscreen, no horizontal scroll
```
