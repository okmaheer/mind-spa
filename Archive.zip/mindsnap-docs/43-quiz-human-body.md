# 43 — Human Body Quiz

**Route:** `GET /quiz/human-body`  
**File:** Uses `resources/views/quizzes/quiz.blade.php` (shared template)  
**SEO Keyword:** `human body quiz` — 400,000/month  
**H1:** `Human Body Quiz — Test Your Knowledge Free`  
**Title:** `Human Body Quiz — Free Online Questions | MindSnap`  
**Meta:** `Free human body quiz. Test your knowledge of human anatomy, physiology and body systems. No signup needed.`

---

## What This Quiz Contains

Test your knowledge of human anatomy, physiology and body systems.

- **Questions:** 10 per session (randomised from DB pool)
- **Difficulty:** Easy → Medium → Hard progression
- **Time limit:** Optional 30 seconds per question
- **Age group:** All (teens and adults)

---

## FAQ

| # | Question | Answer |
|---|---|---|
| Q1 | How many bones are in the adult human body? | 206 — babies are born with around 270-300 bones that fuse over time. |
| Q2 | What is the largest muscle in the human body? | The gluteus maximus — the main extensor muscle of the hip. |
| Q3 | How long are the small intestines? | Approximately 6-7 metres (20 feet) — despite the name 'small'. |
| Q4 | What is the normal resting heart rate for adults? | 60-100 beats per minute, with athletes often having lower rates of 40-60 bpm. |
| Q5 | Is this human body quiz free? | Yes — completely free, no signup, instant results. |

---

## SEO Structure

- Breadcrumb: Home > Quizzes > Human Body Quiz
- Internal links: 2 related quizzes + /quizzes listing page
- Schema: BreadcrumbList + FAQPage

---

## Database Seed

Ask Claude to generate 50 human body quiz questions in the quiz_questions table format:
```
category: 'human body'
difficulty: mix of easy/medium/hard
age_group: 'all'
```

---

## Claude Prompt

```
Build the Human Body Quiz page for MindSnap.co.
Route: /quiz/human-body
This page uses the shared quiz.blade.php template from Feature 34.

Controller method: QuizController@show('human body')
Load 10 random questions from quiz_questions where category='human body'

SEO:
Title: "Human Body Quiz — Free Online Questions | MindSnap"
Meta:  "Free human body quiz. Test your knowledge of human anatomy, physiology and body systems. No signup."
H1:    "Human Body Quiz — Test Your Knowledge Free"
Canonical: https://mindsnap.co/quiz/human-body

Add to controller: $meta array with title, description, h1, colour (#e94560), keyword
Pass to quiz.blade.php view

Generate 50 seed questions for this category in QuizSeeder.php
Include: question, option_a-d, correct_option, explanation, difficulty, age_group='all'
```
