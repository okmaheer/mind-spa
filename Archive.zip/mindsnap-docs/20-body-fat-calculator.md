# 20 — Body Fat Calculator

**Route:** `GET /body-fat-calculator`  
**File:** `resources/views/calculators/body-fat-calculator.blade.php`  
**Category:** Fitness  
**SEO Keyword:** `body fat percentage calculator` — 1,200,000/month  

---

## SEO

| Field | Value |
|---|---|
| Title | `Body Fat Calculator — Free Body Fat % Estimator | MindSnap` |
| Meta | `Free body fat percentage calculator using the US Navy method. Enter your measurements to estimate body fat and fat mass instantly.` |
| H1 | `Body Fat Calculator — Estimate Your Body Fat Percentage` |
| Canonical | `https://mindsnap.co/body-fat-calculator` |
| Category | [Fitness Tools](/fitness-tools) |

---

## What This Page Does

Body Fat Calculator page on MindSnap.co. Follows the standard 12-section tool page structure.

---

## Inputs

- **Gender:** Male / Female
- **Height:** cm / in
- **Neck circumference:** cm / in
- **Waist circumference:** cm / in (at navel)
- **Hip circumference:** cm / in (women only)

---

## JavaScript Logic

```javascript
// US Navy Method
function calcBodyFat(gender, heightCm, neckCm, waistCm, hipCm) {
  let bf;
  if (gender === 'male') {
    bf = 495 / (1.0324 - 0.19077 * Math.log10(waistCm - neckCm) + 0.15456 * Math.log10(heightCm)) - 450;
  } else {
    bf = 495 / (1.29579 - 0.35004 * Math.log10(waistCm + hipCm - neckCm) + 0.22100 * Math.log10(heightCm)) - 450;
  }
  return { bodyFatPct: +bf.toFixed(1), fatMassKg: +(totalWeightKg * bf / 100).toFixed(1) };
}
```

---

## Result Output

Body fat percentage + fat mass kg + lean mass kg + category (Essential/Athletic/Fitness/Average/Obese) + colour-coded range gauge.

---

## Formula Explanation (Section 7)

US Navy Method: uses neck, waist (and hip for women) circumferences with height to estimate body fat percentage. More accessible than calipers, within 3% accuracy for most people.

---

## Content Section (Section 8)

**H2:** `Body Fat Percentage — What's Healthy for You?`

Body fat ranges by gender and fitness level, why body fat matters more than BMI for health, how to reduce body fat (calorie deficit + resistance training). ~340 words.

---

## FAQ (Section 9)

| # | Question | Answer |
|---|---|---|
| Q1 | What is a healthy body fat percentage? | For men, 10-20% is considered fitness range. For women, 18-28%. Athletes are typically lower. Essential fat (minimum for organ function) is 2-5% for men and 10-13% for women. |
| Q2 | How accurate is the US Navy method? | The US Navy method is accurate within 3-4% for most people. It is less accurate for very lean or very obese individuals. DEXA scanning is the gold standard but requires medical equipment. |
| Q3 | Can I lose fat and gain muscle at the same time? | Yes, especially for beginners or people returning after a break. This is called body recomposition and requires adequate protein (1.8-2.2g/kg), resistance training, and a small calorie deficit or maintenance intake. |
| Q4 | Does body fat percentage matter more than weight? | For health outcomes, body composition (fat vs muscle ratio) matters more than total weight. Two people at the same weight can have very different health profiles depending on their body fat percentage. |
| Q5 | Is MindSnap's Body Fat Calculator free? | Yes — completely free, no signup, no download. Use it instantly on any device. |

---

## Related Tools (Section 10)

1. **BMI Calculator** → `/bmi-calculator`
2. **Ideal Weight Calculator** → `/ideal-weight-calculator`
3. **Fitness Tools** → `/fitness-tools`

---



## Claude Prompt

```
Build the Body Fat Calculator page for MindSnap.co.

FILE: resources/views/calculators/body-fat-calculator.blade.php
ROUTE: GET /body-fat-calculator
CATEGORY COLOUR: #28a745

SEO:
Title:    "Body Fat Calculator — Free Body Fat % Estimator | MindSnap"
Meta:     "Free body fat percentage calculator using the US Navy method. Enter your measurements to estimate body fat and fat mass instantly."
H1:       "Body Fat Calculator — Estimate Your Body Fat Percentage"
Canonical: https://mindsnap.co/body-fat-calculator

BUILD ALL 12 SECTIONS:
1. Breadcrumb: Home > Fitness Tools > Body Fat Calculator + BreadcrumbList schema
2. H1 + 2-sentence description + trust badges (Free/No Signup/Instant/Mobile Friendly)
3. INPUT FORM:
- **Gender:** Male / Female
- **Height:** cm / in
- **Neck circumference:** cm / in
- **Waist circumference:** cm / in (at navel)
- **Hip circumference:** cm / in (women only)
   Labels above inputs. Units toggle where applicable.
   #e94560 Calculate button, full-width mobile, min 52px height.
4. RESULT: fadeIn animation, large result in #28a745, interpretation text
5. SHARE CARD: canvas 420x220px, Copy/WhatsApp/Download buttons
6. HOW TO USE: H2 + 4-5 numbered steps
7. FORMULA: H2 + plain English + formula in styled box
8. CONTENT: H2 "Body Fat Percentage — What's Healthy for You?" + 300-400 words + 2-3 H3 subheadings
9. FAQ: H2 + Bootstrap accordion + 5 Q&As + FAQPage JSON-LD schema
10. RELATED TOOLS: 3 cards — BMI Calculator, Ideal Weight Calculator, Fitness Tools category page
11. CATEGORY LINK: text sentence linking back to /fitness-tools
12. SCHEMAS in @section('schema'):
    - WebApplication JSON-LD
    - BreadcrumbList JSON-LD  
    - FAQPage JSON-LD

VANILLA JS LOGIC:
// US Navy Method
function calcBodyFat(gender, heightCm, neckCm, waistCm, hipCm) {
  let bf;
  if (gender === 'male') {
    bf = 495 / (1.0324 - 0.19077 * Math.log10(waistCm - neckCm) + 0.15456 * Math.log10(heightCm)) - 450;
  } else {
    bf = 495 / (1.29579 - 0.35004 * Math.log10(waistCm + hipCm - neckCm) + 0.22100 * Math.log10(heightCm)) - 450;
  }
  return { bodyFatPct: +bf.toFixed(1), fatMassKg: +(totalWeightKg * bf / 100).toFixed(1) };
}

MOBILE: all inputs 100% width, 48px height, buttons 52px, test at 375px
PERFORMANCE: defer all JS, lazy load images
```
