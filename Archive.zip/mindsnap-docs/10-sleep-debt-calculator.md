# 10 — Sleep Debt Calculator

**Route:** `GET /sleep-debt-calculator`  
**File:** `resources/views/calculators/sleep-debt-calculator.blade.php`  
**Category:** Sleep  
**SEO Keyword:** `sleep debt calculator` — 250,000/month  

---

## SEO

| Field | Value |
|---|---|
| Title | `Sleep Debt Calculator — Track Your Sleep Deficit | MindSnap` |
| Meta | `Free sleep debt calculator. Enter your sleep this week and find out how much sleep you are missing and how to recover it.` |
| H1 | `Sleep Debt Calculator — How Much Sleep Do You Owe Yourself?` |
| Canonical | `https://mindsnap.co/sleep-debt-calculator` |
| Category | [Sleep Tools](/sleep-tools) |

---

## What This Page Does

Sleep Debt Calculator page on MindSnap.co. Follows the standard 12-section tool page structure.

---

## Inputs

- **Sleep per night this week:** 7 fields for Mon-Sun (number inputs, 0-12 hours)
- **Your ideal sleep:** dropdown (6h / 7h / 7.5h / 8h / 9h)

---

## JavaScript Logic

```javascript
function calculateSleepDebt(actualHours, idealHours) {
  const totalActual = actualHours.reduce((a, b) => a + b, 0);
  const totalIdeal  = idealHours * actualHours.length;
  const debt        = Math.max(0, totalIdeal - totalActual);
  const recoveryDays = Math.ceil(debt / 1.5); // can recover ~1.5h extra per night safely
  return { debt, totalActual, totalIdeal, recoveryDays, deficit: (totalIdeal - totalActual) };
}
```

---

## Result Output

Shows total hours slept, total deficit in hours, severity badge (None/Mild/Moderate/Severe), and a recovery plan (how many extra hours per night over how many days).

---

## Formula Explanation (Section 7)

Sleep debt = (Ideal hours per night × 7) − Actual hours slept this week. Recovery rate: safely catch up 1-1.5 extra hours per night without disrupting circadian rhythm.

---

## Content Section (Section 8)

**H2:** `Sleep Debt: What It Is and How to Recover`

Explain cumulative sleep debt, health impacts of chronic deprivation, why you cannot simply sleep 15 hours one day to recover, safe recovery strategies. ~320 words.

---

## FAQ (Section 9)

| # | Question | Answer |
|---|---|---|
| Q1 | Can you fully recover from sleep debt? | Short-term sleep debt (within a week) can be recovered. Chronic sleep debt accumulated over months or years may have lasting effects on health and cognitive function. |
| Q2 | How much extra sleep can I safely add per night? | Sleep researchers recommend adding no more than 1-1.5 extra hours per night when recovering from sleep debt. Drastically changing your sleep time disrupts your circadian rhythm. |
| Q3 | What are the effects of sleep debt? | Sleep debt causes reduced concentration, impaired memory, mood changes, weakened immune function, and increased risk of accidents. Chronic debt is linked to diabetes and heart disease. |
| Q4 | Does a lie-in on weekends help? | A weekend lie-in partially helps short-term debt but creates 'social jet lag' — shifting your sleep timing disrupts your weekday rhythm. Regular consistent sleep is more beneficial. |
| Q5 | Is MindSnap's Sleep Debt Calculator free? | Yes — completely free, no signup, no download. Use it instantly on any device. |

---

## Related Tools (Section 10)

1. **Sleep Cycle Calculator** → `/sleep-calculator`
2. **Nap Calculator** → `/nap-calculator`
3. **Sleep Tools** → `/sleep-tools`

---



## Claude Prompt

```
Build the Sleep Debt Calculator page for MindSnap.co.

FILE: resources/views/calculators/sleep-debt-calculator.blade.php
ROUTE: GET /sleep-debt-calculator
CATEGORY COLOUR: #6c63ff

SEO:
Title:    "Sleep Debt Calculator — Track Your Sleep Deficit | MindSnap"
Meta:     "Free sleep debt calculator. Enter your sleep this week and find out how much sleep you are missing and how to recover it."
H1:       "Sleep Debt Calculator — How Much Sleep Do You Owe Yourself?"
Canonical: https://mindsnap.co/sleep-debt-calculator

BUILD ALL 12 SECTIONS:
1. Breadcrumb: Home > Sleep Tools > Sleep Debt Calculator + BreadcrumbList schema
2. H1 + 2-sentence description + trust badges (Free/No Signup/Instant/Mobile Friendly)
3. INPUT FORM:
- **Sleep per night this week:** 7 fields for Mon-Sun (number inputs, 0-12 hours)
- **Your ideal sleep:** dropdown (6h / 7h / 7.5h / 8h / 9h)
   Labels above inputs. Units toggle where applicable.
   #e94560 Calculate button, full-width mobile, min 52px height.
4. RESULT: fadeIn animation, large result in #6c63ff, interpretation text
5. SHARE CARD: canvas 420x220px, Copy/WhatsApp/Download buttons
6. HOW TO USE: H2 + 4-5 numbered steps
7. FORMULA: H2 + plain English + formula in styled box
8. CONTENT: H2 "Sleep Debt: What It Is and How to Recover" + 300-400 words + 2-3 H3 subheadings
9. FAQ: H2 + Bootstrap accordion + 5 Q&As + FAQPage JSON-LD schema
10. RELATED TOOLS: 3 cards — Sleep Cycle Calculator, Nap Calculator, Sleep Tools category page
11. CATEGORY LINK: text sentence linking back to /sleep-tools
12. SCHEMAS in @section('schema'):
    - WebApplication JSON-LD
    - BreadcrumbList JSON-LD  
    - FAQPage JSON-LD

VANILLA JS LOGIC:
function calculateSleepDebt(actualHours, idealHours) {
  const totalActual = actualHours.reduce((a, b) => a + b, 0);
  const totalIdeal  = idealHours * actualHours.length;
  const debt        = Math.max(0, totalIdeal - totalActual);
  const recoveryDays = Math.ceil(debt / 1.5); // can recover ~1.5h extra per night safely
  return { debt, totalActual, totalIdeal, recoveryDays, deficit: (totalIdeal - totalActual) };
}

MOBILE: all inputs 100% width, 48px height, buttons 52px, test at 375px
PERFORMANCE: defer all JS, lazy load images
```
