# 01 — Project Setup

**Stack:** Laravel 10 + Bootstrap 5 + Vanilla JS + MySQL  
**Hosting:** Namecheap + Cloudflare (free CDN)

---

## Folder Structure

```
mindsnap/
├── app/Http/Controllers/
│   ├── HomeController.php
│   ├── CategoryController.php
│   ├── CalculatorController.php
│   ├── QuizController.php
│   ├── AiQuizController.php
│   ├── KidsController.php
│   ├── GamesController.php
│   └── DailyController.php
├── resources/views/
│   ├── layouts/app.blade.php
│   ├── components/
│   │   ├── navbar.blade.php
│   │   ├── footer.blade.php
│   │   ├── related-tools.blade.php
│   │   ├── ad-slot.blade.php
│   │   ├── share-card.blade.php
│   │   ├── faq-section.blade.php
│   │   └── breadcrumb.blade.php
│   ├── home.blade.php
│   ├── categories/ (8 files)
│   ├── calculators/ (30+ files)
│   ├── quizzes/ (index, quiz, result)
│   ├── kids/ (6 files)
│   ├── games/ (5 files)
│   ├── daily/index.blade.php
│   └── seo/ (4 content pages)
├── routes/web.php
├── database/migrations/
└── database/seeders/
```

---

## All Routes (web.php)

```php
// Core
Route::get('/',                              [HomeController::class,    'index']);
Route::get('/search',                        [HomeController::class,    'search']);

// Category pages
Route::get('/sleep-tools',                   [CategoryController::class, 'sleep']);
Route::get('/fitness-tools',                 [CategoryController::class, 'fitness']);
Route::get('/nutrition-tools',               [CategoryController::class, 'nutrition']);
Route::get('/quizzes',                       [CategoryController::class, 'quizzes']);
Route::get('/kids',                          [CategoryController::class, 'kids']);
Route::get('/life-tools',                    [CategoryController::class, 'life']);
Route::get('/games',                         [CategoryController::class, 'games']);
Route::get('/daily',                         [DailyController::class,   'index']);

// Sleep tools
Route::get('/sleep-calculator',              [CalculatorController::class, 'sleep']);
Route::get('/wake-up-calculator',            [CalculatorController::class, 'wakeUp']);
Route::get('/nap-calculator',                [CalculatorController::class, 'nap']);
Route::get('/baby-sleep-calculator',         [CalculatorController::class, 'babySleep']);
Route::get('/sleep-debt-calculator',         [CalculatorController::class, 'sleepDebt']);
Route::get('/caffeine-sleep-calculator',     [CalculatorController::class, 'caffeine']);
Route::get('/jet-lag-calculator',            [CalculatorController::class, 'jetLag']);
Route::get('/sleep-quality-quiz',            [CalculatorController::class, 'sleepQuality']);

// Fitness tools
Route::get('/bmi-calculator',                [CalculatorController::class, 'bmi']);
Route::get('/calorie-calculator',            [CalculatorController::class, 'calorie']);
Route::get('/calorie-deficit-calculator',    [CalculatorController::class, 'calorieDeficit']);
Route::get('/macro-calculator',              [CalculatorController::class, 'macro']);
Route::get('/protein-calculator',            [CalculatorController::class, 'protein']);
Route::get('/one-rep-max-calculator',        [CalculatorController::class, 'oneRepMax']);
Route::get('/body-fat-calculator',           [CalculatorController::class, 'bodyFat']);
Route::get('/heart-rate-calculator',         [CalculatorController::class, 'heartRate']);
Route::get('/running-pace-calculator',       [CalculatorController::class, 'runningPace']);
Route::get('/ideal-weight-calculator',       [CalculatorController::class, 'idealWeight']);
Route::get('/workout-volume-calculator',     [CalculatorController::class, 'workoutVolume']);

// Nutrition tools
Route::get('/water-intake-calculator',       [CalculatorController::class, 'waterIntake']);
Route::get('/intermittent-fasting-calculator', [CalculatorController::class, 'intermittentFasting']);

// Life tools
Route::get('/age-calculator',               [CalculatorController::class, 'age']);
Route::get('/days-between-dates',           [CalculatorController::class, 'daysBetween']);
Route::get('/days-until-calculator',        [CalculatorController::class, 'daysUntil']);
Route::get('/due-date-calculator',          [CalculatorController::class, 'dueDate']);
Route::get('/ovulation-calculator',         [CalculatorController::class, 'ovulation']);
Route::get('/retirement-calculator',        [CalculatorController::class, 'retirement']);
Route::get('/life-percentage-calculator',   [CalculatorController::class, 'lifePercentage']);

// Quizzes
Route::get('/daily-quiz',                   [QuizController::class, 'daily']);
Route::get('/quiz/{category}',              [QuizController::class, 'show']);
Route::get('/iq-test',                      [QuizController::class, 'iqTest']);
Route::post('/quiz/save-result',            [QuizController::class, 'saveResult']);

// AI Quiz
Route::get('/ai-quiz-generator',            [AiQuizController::class, 'index']);
Route::post('/api/generate-quiz',           [AiQuizController::class, 'generate']);

// Kids Zone
Route::get('/kids/math-puzzles',            [KidsController::class, 'mathPuzzles']);
Route::get('/kids/word-games',              [KidsController::class, 'wordGames']);
Route::get('/kids/science-quiz',            [KidsController::class, 'scienceQuiz']);
Route::get('/kids/animal-quiz',             [KidsController::class, 'animalQuiz']);
Route::get('/kids/spelling-quiz',           [KidsController::class, 'spellingQuiz']);

// Games
Route::get('/typing-speed-test',            [GamesController::class, 'typingSpeed']);
Route::get('/reaction-time-test',           [GamesController::class, 'reactionTime']);
Route::get('/memory-test',                  [GamesController::class, 'memoryTest']);
Route::get('/word-scramble',                [GamesController::class, 'wordScramble']);
Route::get('/color-blind-test',             [GamesController::class, 'colorBlind']);

// SEO content pages
Route::get('/what-time-should-i-sleep',     [HomeController::class, 'sleepGuide']);
Route::get('/how-much-sleep-do-i-need',     [HomeController::class, 'sleepNeedsGuide']);
Route::get('/what-is-a-good-bmi',           [HomeController::class, 'bmiGuide']);
Route::get('/calories-to-lose-weight',      [HomeController::class, 'caloriesGuide']);

// Utility
Route::get('/about',                        [HomeController::class, 'about']);
Route::get('/privacy',                      [HomeController::class, 'privacy']);
Route::get('/sitemap.xml',                  [HomeController::class, 'sitemap']);
```

---

## Database Migrations

```php
// quiz_questions
Schema::create('quiz_questions', function (Blueprint $table) {
    $table->id();
    $table->string('category', 50);
    $table->text('question');
    $table->string('option_a');
    $table->string('option_b');
    $table->string('option_c');
    $table->string('option_d');
    $table->char('correct_option', 1);
    $table->text('explanation')->nullable();
    $table->enum('difficulty', ['easy', 'medium', 'hard'])->default('medium');
    $table->enum('age_group', ['kids', 'teen', 'adult', 'all'])->default('all');
    $table->timestamps();
});

// quiz_attempts
Schema::create('quiz_attempts', function (Blueprint $table) {
    $table->id();
    $table->string('session_id', 100);
    $table->string('category', 50);
    $table->integer('score');
    $table->integer('total_questions');
    $table->integer('time_taken_seconds')->nullable();
    $table->timestamp('completed_at');
});

// daily_quizzes
Schema::create('daily_quizzes', function (Blueprint $table) {
    $table->id();
    $table->date('date')->unique();
    $table->string('topic', 100);
    $table->json('question_ids');
    $table->boolean('is_active')->default(true);
    $table->timestamps();
});

// health_tips
Schema::create('health_tips', function (Blueprint $table) {
    $table->id();
    $table->text('tip');
    $table->string('category', 50);
    $table->integer('day_number')->unique(); // 1-365
});
```

---

## .env Variables

```env
APP_NAME=MindSnap
APP_URL=https://mindsnap.co
APP_ENV=production
APP_DEBUG=false

DB_CONNECTION=mysql
DB_HOST=localhost
DB_DATABASE=mindsnap
DB_USERNAME=your_user
DB_PASSWORD=your_password

CLAUDE_API_KEY=sk-ant-xxxx
ADSENSE_PUBLISHER_ID=ca-pub-xxxxxxxxxx
ADSENSE_ENABLED=true
```

---

## Claude Prompt

```
Set up the MindSnap.co Laravel 10 project.

1. Create all folders in the structure above
2. Create web.php with ALL routes listed above
3. Create stub controller files — each method just returns a view() for now
4. Create all 4 database migrations with the schemas above
5. Create app.blade.php master layout (detailed in file 03)
6. Add .env.example with all variables listed above

Do not build any views yet — just the skeleton.
Confirm each file created with its path.
```
