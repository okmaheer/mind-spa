# 47 — Kids Math Puzzles

**Route:** `GET /kids/math-puzzles`  
**File:** `resources/views/kids/math-puzzles.blade.php`  
**SEO Keyword:** `math puzzles for kids`  
**H1:** `Kids Math Puzzles — Free Games for Kids`  
**Title:** `Kids Math Puzzles — Free Online | MindSnap Kids Zone`  
**Meta:** `Free kids math puzzles for children. Counting, addition, subtraction, multiplication puzzles for children. Safe, ad-free, no accounts.`

---

## What This Page Is

Counting, addition, subtraction, multiplication puzzles for children.

### Age Differentiation
Ages 5-7: visual counting. Ages 8-10: addition/subtraction. Ages 11-12: multiplication/division/fractions.

---

## Features

Simple addition problems displayed visually with emoji counters (🍎+🍎=?). Multiplication tables. Number pattern puzzles. Missing number sequences.

---

## Kids Zone Design Rules Apply
- Minimum 18px font
- Minimum 48×48px tap targets
- No ads
- Encouraging messages only (no "Wrong!" — use "Great try! The answer was...")
- Stars rating instead of percentage
- Large colourful buttons

---

## Claude Prompt

```
Build the Kids Math Puzzles page for MindSnap.co Kids Zone.

FILE: resources/views/kids/math-puzzles.blade.php
ROUTE: GET /kids/math-puzzles

DESIGN RULES: min 18px font, 48×48px tap targets, NO ads, encouraging messages, star rating.

Content: Simple addition problems displayed visually with emoji counters (🍎+🍎=?). Multiplication tables. Number pattern puzzles. Missing number sequences.
Age selector inherited from Kids Zone home (localStorage key 'ms_kid_age').
Filter difficulty based on age selection.

SEO:
Title: "Kids Math Puzzles — Free Online | MindSnap Kids Zone"
Meta: "Free kids math puzzles for children. Counting, addition, subtraction, multiplication puzzles for children. Safe, ad-free."
H1: "Kids Math Puzzles — Free Games for Kids"
Internal links: Kids Zone home + 2 related kids activities
FAQPage schema with questions parents ask.
```
