# 42 — World War 2 Quiz

**Route:** `GET /quiz/world-war-2`  
**File:** Uses `resources/views/quizzes/quiz.blade.php` (shared template)  
**SEO Keyword:** `world war 2 quiz` — 500,000/month  
**H1:** `World War 2 Quiz — Test Your Knowledge Free`  
**Title:** `World War 2 Quiz — Free Online Questions | MindSnap`  
**Meta:** `Free world war 2 quiz. Test your knowledge of World War 2 — battles, leaders, dates and key events. No signup needed.`

---

## What This Quiz Contains

Test your knowledge of World War 2 — battles, leaders, dates and key events.

- **Questions:** 10 per session (randomised from DB pool)
- **Difficulty:** Easy → Medium → Hard progression
- **Time limit:** Optional 30 seconds per question
- **Age group:** All (teens and adults)

---

## FAQ

| # | Question | Answer |
|---|---|---|
| Q1 | In what year did WW2 begin? | 1939 — Germany invaded Poland on September 1, 1939. |
| Q2 | What was the codename for the D-Day invasion? | Operation Overlord — the Allied invasion of Normandy on June 6, 1944. |
| Q3 | Which country suffered the most casualties in WW2? | The Soviet Union — with an estimated 27 million deaths. |
| Q4 | What was the Manhattan Project? | The secret US research programme that developed the first nuclear weapons. |
| Q5 | Is this world war 2 quiz free? | Yes — completely free, no signup, instant results. |

---

## SEO Structure

- Breadcrumb: Home > Quizzes > World War 2 Quiz
- Internal links: 2 related quizzes + /quizzes listing page
- Schema: BreadcrumbList + FAQPage

---

## Database Seed

Ask Claude to generate 50 world war 2 quiz questions in the quiz_questions table format:
```
category: 'world war 2'
difficulty: mix of easy/medium/hard
age_group: 'all'
```

---

## Claude Prompt

```
Build the World War 2 Quiz page for MindSnap.co.
Route: /quiz/world-war-2
This page uses the shared quiz.blade.php template from Feature 34.

Controller method: QuizController@show('world war 2')
Load 10 random questions from quiz_questions where category='world war 2'

SEO:
Title: "World War 2 Quiz — Free Online Questions | MindSnap"
Meta:  "Free world war 2 quiz. Test your knowledge of World War 2 — battles, leaders, dates and key events. No signup."
H1:    "World War 2 Quiz — Test Your Knowledge Free"
Canonical: https://mindsnap.co/quiz/world-war-2

Add to controller: $meta array with title, description, h1, colour (#e94560), keyword
Pass to quiz.blade.php view

Generate 50 seed questions for this category in QuizSeeder.php
Include: question, option_a-d, correct_option, explanation, difficulty, age_group='all'
```
