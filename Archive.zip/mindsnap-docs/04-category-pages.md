# MindSnap.co — Feature 04: Category Pages

---

## What These Pages Do

Each category page is a standalone SEO landing page. They rank for searches like "free sleep tools online" or "free fitness calculators" and funnel users into individual tool pages.

**8 category pages total** — each one is its own door into the site from Google.

---

## Routes & Files

| Category | Route | File | SEO Keyword | Monthly Searches |
|---|---|---|---|---|
| Sleep | `/sleep-tools` | `categories/sleep.blade.php` | free sleep tools online | 800,000 |
| Fitness | `/fitness-tools` | `categories/fitness.blade.php` | free fitness calculators | 1,200,000 |
| Nutrition | `/nutrition-tools` | `categories/nutrition.blade.php` | free nutrition calculators | 600,000 |
| Quizzes | `/quizzes` | `categories/quizzes.blade.php` | free quiz website | 2,000,000 |
| Kids Zone | `/kids` | `categories/kids.blade.php` | free learning games for kids | 900,000 |
| Life Tools | `/life-tools` | `categories/life.blade.php` | free life calculators | 400,000 |
| Games | `/games` | `categories/games.blade.php` | free brain games online | 1,500,000 |
| Daily | `/daily` | `daily/index.blade.php` | daily brain challenge | 300,000 |

---

## Page Structure (same template for all 8)

### Section 1 — Category Hero

```
Background: category colour gradient (solid → lighter shade)
Height: 300px desktop, 200px mobile

[Large emoji icon — 4rem]
H1: "[Category Name] — Free [Category] Tools Online"
Subtext: brief 1-sentence description of this category

Breadcrumb below H1:
  Home > [Category Name]
```

### Section 2 — Tools Grid

```
H2: "All [Category] Tools"

Bootstrap grid: col-lg-4 col-md-6 col-12

Each tool card:
  ┌─────────────────────────────────┐
  │ ████ 4px left border (cat col)  │
  │ [SVG icon]                      │
  │ Tool Name (H3, linked)          │
  │ One-line description            │
  │ 🔍 X,XXX,XXX searches/month     │
  │ [Use Free Tool →]  #e94560 btn  │
  └─────────────────────────────────┘

Hover effect: card lifts slightly
```

### Section 3 — About This Category *(SEO content)*

```
2-column layout: text left (60%), illustration right (40%)
Mobile: single column

150–200 words of natural content
Include target keyword 3-4 times naturally
Use H3 subheadings within this section

Example for Sleep category:
  H3: "Why Sleep Timing Matters"
  H3: "How Our Sleep Tools Help"
```

### Section 4 — Related Categories

```
H2: "Explore More Free Tools"
3 cards linking to related categories

Sleep → Fitness → Nutrition (logical flow)
Quiz → Kids → Games
Life → Sleep → Fitness
```

### Section 5 — FAQ

```
H2: "Frequently Asked Questions"
5 questions specific to this category
Bootstrap accordion
FAQPage JSON-LD schema
```

---

## SEO Per Category Page

### Title Tag Formulas

```
Sleep:     "Free Sleep Tools & Calculators Online | MindSnap"           (52 chars)
Fitness:   "Free Fitness Calculators Online | MindSnap"                  (44 chars)
Nutrition: "Free Nutrition Calculators Online | MindSnap"                (46 chars)
Quizzes:   "Free Quiz Website — Test Your Knowledge Online | MindSnap"  (57 chars)
Kids:      "Free Learning Games for Kids Online | MindSnap"             (47 chars)
Life:      "Free Life & Date Calculators Online | MindSnap"             (47 chars)
Games:     "Free Brain Games Online — Play & Learn | MindSnap"          (50 chars)
```

### Meta Descriptions

```
Sleep:     "Free sleep calculators and tools. Sleep cycle calculator, wake-up time, baby sleep, caffeine cut-off and more. No signup needed."
Fitness:   "Free fitness calculators. BMI, TDEE, calorie deficit, macros, one rep max and more. Instant results, no signup required."
Quizzes:   "Free quiz website with hundreds of quizzes. General knowledge, history, science, biology and more. No signup, play instantly."
Kids:      "Free educational games and quizzes for kids aged 5-12. Math puzzles, word games, science quizzes. Safe, ad-free, no accounts."
```

---

## Tools List Per Category

### Sleep Tools
1. Sleep Cycle Calculator — `/sleep-calculator`
2. Wake-Up Time Calculator — `/wake-up-calculator`
3. Nap Calculator — `/nap-calculator`
4. Baby Sleep Calculator — `/baby-sleep-calculator`
5. Sleep Debt Calculator — `/sleep-debt-calculator`
6. Caffeine Cut-Off Calculator — `/caffeine-sleep-calculator`
7. Jet Lag Calculator — `/jet-lag-calculator`
8. Sleep Quality Quiz — `/sleep-quality-quiz`

### Fitness Tools
1. BMI Calculator — `/bmi-calculator`
2. TDEE / Calorie Calculator — `/calorie-calculator`
3. Calorie Deficit Calculator — `/calorie-deficit-calculator`
4. Macro Calculator — `/macro-calculator`
5. Protein Calculator — `/protein-calculator`
6. One Rep Max Calculator — `/one-rep-max-calculator`
7. Body Fat Calculator — `/body-fat-calculator`
8. Heart Rate Zone Calculator — `/heart-rate-calculator`
9. Running Pace Calculator — `/running-pace-calculator`
10. Ideal Weight Calculator — `/ideal-weight-calculator`
11. Workout Volume Calculator — `/workout-volume-calculator`

### Nutrition Tools
1. Water Intake Calculator — `/water-intake-calculator`
2. Intermittent Fasting Calculator — `/intermittent-fasting-calculator`
3. Meal Plan Generator — `/meal-plan-generator`
4. Recipe Calorie Calculator — `/recipe-calorie-calculator`

### Life Tools
1. Age Calculator — `/age-calculator`
2. Days Between Dates — `/days-between-dates`
3. Days Until Calculator — `/days-until-calculator`
4. Pregnancy Due Date — `/due-date-calculator`
5. Ovulation Calculator — `/ovulation-calculator`
6. Retirement Countdown — `/retirement-calculator`
7. Life % Calculator — `/life-percentage-calculator`

### Games
1. Typing Speed Test — `/typing-speed-test`
2. Reaction Time Test — `/reaction-time-test`
3. Memory Test — `/memory-test`
4. Word Scramble — `/word-scramble`
5. Color Blind Test — `/color-blind-test`
6. Speed Reading Test — `/speed-reading-test`
7. Daily Word Game — `/daily-word`

---

## Controller Logic

```php
// CategoryController.php
public function sleep()
{
    $tools = [
        ['name' => 'Sleep Cycle Calculator', 'slug' => 'sleep-calculator', 
         'desc' => 'Find your perfect bedtime based on 90-minute sleep cycles.',
         'searches' => '2,200,000', 'icon' => 'moon'],
        // ... all sleep tools
    ];

    return view('categories.sleep', [
        'tools'    => $tools,
        'category' => 'Sleep',
        'colour'   => '#6c63ff',
        'keyword'  => 'free sleep tools online',
    ]);
}

// Same pattern for all 8 categories
```

---

## Claude Prompt — Category Page Template

```
Build the Sleep Tools category page for MindSnap.co.
Use this as the template for all 8 category pages.

FILE: resources/views/categories/sleep.blade.php
ROUTE: GET /sleep-tools

@extends('layouts.app')
@section('title', 'Free Sleep Tools & Calculators Online | MindSnap')
@section('description', 'Free sleep calculators and tools. Sleep cycle calculator, wake-up time, baby sleep, caffeine cut-off and more. No signup needed.')
@section('canonical', 'https://mindsnap.co/sleep-tools')

SECTION 1 — HERO (300px height)
Background: linear-gradient(135deg, #6c63ff, #a29bf7)
Breadcrumb: Home > Sleep Tools (with BreadcrumbList schema)
H1: "Sleep Tools — Free Sleep Calculators Online"
Subtext: "8 free sleep calculators to optimise your rest and wake-up time"

SECTION 2 — TOOLS GRID
H2: "All Free Sleep Tools"
8 tool cards in Bootstrap col-lg-4 col-md-6 col-12
Each card uses the tool data from $tools array (passed from controller)
Card structure: left border #6c63ff, icon emoji, H3 (linked), description, search volume badge, CTA button

SECTION 3 — ABOUT (SEO content, 150-200 words)
H2: "Free Sleep Tools — What You Can Calculate"
H3: "Why Sleep Timing Matters for Your Health"
  ~75 words about sleep cycles, keyword "free sleep tools" used naturally
H3: "How MindSnap Sleep Calculators Work"
  ~75 words explaining the tools, include "sleep calculator" naturally

SECTION 4 — RELATED CATEGORIES
H2: "Explore More Free Tools"
3 cards: Fitness Tools (/fitness-tools), Nutrition Tools (/nutrition-tools), Daily Challenge (/daily)

SECTION 5 — FAQ
H2: "Frequently Asked Questions"
5 questions about sleep tools with Bootstrap accordion
Add FAQPage JSON-LD schema

Add BreadcrumbList schema in @section('schema')
```

---

*Previous: [03-homepage.md](./03-homepage.md)*  
*Next: [05-calculator-tool-pages.md](./05-calculator-tool-pages.md)*
