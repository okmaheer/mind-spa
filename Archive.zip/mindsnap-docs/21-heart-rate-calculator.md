# 21 — Heart Rate Zone Calculator

**Route:** `GET /heart-rate-calculator`  
**File:** `resources/views/calculators/heart-rate-calculator.blade.php`  
**Category:** Fitness  
**SEO Keyword:** `heart rate zone calculator` — 500,000/month  

---

## SEO

| Field | Value |
|---|---|
| Title | `Heart Rate Zone Calculator — Free Training Zones | MindSnap` |
| Meta | `Free heart rate zone calculator. Enter your age and resting heart rate to find your 5 training zones for fat burning, cardio and peak performance.` |
| H1 | `Heart Rate Zone Calculator — Find Your Training Zones` |
| Canonical | `https://mindsnap.co/heart-rate-calculator` |
| Category | [Fitness Tools](/fitness-tools) |

---

## What This Page Does

Heart Rate Zone Calculator page on MindSnap.co. Follows the standard 12-section tool page structure.

---

## Inputs

- **Age:** number input
- **Resting heart rate:** bpm (measure on waking)
- **Max heart rate:** optional override (default: 220 - age)

---

## JavaScript Logic

```javascript
function calcHRZones(age, restingHR, maxHROverride) {
  const maxHR = maxHROverride || (220 - age);
  const reserve = maxHR - restingHR; // Heart Rate Reserve (Karvonen method)
  const zones = [
    { name:'Zone 1 — Recovery',    pct:[50,60],  colour:'#17a2b8' },
    { name:'Zone 2 — Fat Burn',    pct:[60,70],  colour:'#28a745' },
    { name:'Zone 3 — Aerobic',     pct:[70,80],  colour:'#ffc107' },
    { name:'Zone 4 — Threshold',   pct:[80,90],  colour:'#fd7e14' },
    { name:'Zone 5 — Max Effort',  pct:[90,100], colour:'#dc3545' },
  ];
  return zones.map(z => ({
    ...z,
    min: Math.round(restingHR + (reserve * z.pct[0] / 100)),
    max: Math.round(restingHR + (reserve * z.pct[1] / 100)),
  }));
}
```

---

## Result Output

5 heart rate zones shown as coloured bars with bpm ranges and descriptions of what each zone achieves (fat burn, cardio fitness, VO2 max etc.).

---

## Formula Explanation (Section 7)

Karvonen method: Target HR = Resting HR + (HRR × % intensity). HRR (Heart Rate Reserve) = Max HR - Resting HR. Max HR estimate: 220 - age.

---

## Content Section (Section 8)

**H2:** `Heart Rate Zones — What Each Zone Does for Your Body`

Explain each zone, why Zone 2 is best for fat loss and endurance base, when to use higher zones, how to measure heart rate during exercise. ~330 words.

---

## FAQ (Section 9)

| # | Question | Answer |
|---|---|---|
| Q1 | What is heart rate reserve? | Heart rate reserve (HRR) is the difference between your maximum and resting heart rate. The Karvonen formula uses HRR to calculate more personalised training zones than the simple percentage method. |
| Q2 | Which heart rate zone burns the most fat? | Zone 2 (60-70% max HR) uses the highest percentage of fat as fuel. However, higher intensity zones burn more total calories despite using less fat proportionally. |
| Q3 | How do I measure my resting heart rate? | Measure your resting heart rate first thing in the morning before getting out of bed. Count beats for 60 seconds or 30 seconds and multiply by 2. Average adult is 60-80 bpm. |
| Q4 | Is 220 minus age accurate for max heart rate? | 220-age is a widely used estimate but individual variation is high (±10-12 bpm). A more accurate formula is 208 - (0.7 × age). A true max HR can only be found via a graded exercise test. |
| Q5 | Is MindSnap's Heart Rate Zone Calculator free? | Yes — completely free, no signup, no download. Use it instantly on any device. |

---

## Related Tools (Section 10)

1. **Running Pace Calculator** → `/running-pace-calculator`
2. **TDEE Calculator** → `/calorie-calculator`
3. **Fitness Tools** → `/fitness-tools`

---



## Claude Prompt

```
Build the Heart Rate Zone Calculator page for MindSnap.co.

FILE: resources/views/calculators/heart-rate-calculator.blade.php
ROUTE: GET /heart-rate-calculator
CATEGORY COLOUR: #28a745

SEO:
Title:    "Heart Rate Zone Calculator — Free Training Zones | MindSnap"
Meta:     "Free heart rate zone calculator. Enter your age and resting heart rate to find your 5 training zones for fat burning, cardio and peak performance."
H1:       "Heart Rate Zone Calculator — Find Your Training Zones"
Canonical: https://mindsnap.co/heart-rate-calculator

BUILD ALL 12 SECTIONS:
1. Breadcrumb: Home > Fitness Tools > Heart Rate Zone Calculator + BreadcrumbList schema
2. H1 + 2-sentence description + trust badges (Free/No Signup/Instant/Mobile Friendly)
3. INPUT FORM:
- **Age:** number input
- **Resting heart rate:** bpm (measure on waking)
- **Max heart rate:** optional override (default: 220 - age)
   Labels above inputs. Units toggle where applicable.
   #e94560 Calculate button, full-width mobile, min 52px height.
4. RESULT: fadeIn animation, large result in #28a745, interpretation text
5. SHARE CARD: canvas 420x220px, Copy/WhatsApp/Download buttons
6. HOW TO USE: H2 + 4-5 numbered steps
7. FORMULA: H2 + plain English + formula in styled box
8. CONTENT: H2 "Heart Rate Zones — What Each Zone Does for Your Body" + 300-400 words + 2-3 H3 subheadings
9. FAQ: H2 + Bootstrap accordion + 5 Q&As + FAQPage JSON-LD schema
10. RELATED TOOLS: 3 cards — Running Pace Calculator, TDEE Calculator, Fitness Tools category page
11. CATEGORY LINK: text sentence linking back to /fitness-tools
12. SCHEMAS in @section('schema'):
    - WebApplication JSON-LD
    - BreadcrumbList JSON-LD  
    - FAQPage JSON-LD

VANILLA JS LOGIC:
function calcHRZones(age, restingHR, maxHROverride) {
  const maxHR = maxHROverride || (220 - age);
  const reserve = maxHR - restingHR; // Heart Rate Reserve (Karvonen method)
  const zones = [
    { name:'Zone 1 — Recovery',    pct:[50,60],  colour:'#17a2b8' },
    { name:'Zone 2 — Fat Burn',    pct:[60,70],  colour:'#28a745' },
    { name:'Zone 3 — Aerobic',     pct:[70,80],  colour:'#ffc107' },
    { name:'Zone 4 — Threshold',   pct:[80,90],  colour:'#fd7e14' },
    { name:'Zone 5 — Max Effort',  pct:[90,100], colour:'#dc3545' },
  ];
  return zones.map(z => ({
    ...z,
    min: Math.round(restingHR + (reserve * z.pct[0] / 100)),
    max: Math.round(restingHR + (reserve * z.pct[1] / 100)),
  }));
}

MOBILE: all inputs 100% width, 48px height, buttons 52px, test at 375px
PERFORMANCE: defer all JS, lazy load images
```
