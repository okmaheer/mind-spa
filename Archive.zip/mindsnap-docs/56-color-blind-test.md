# 56 — Color Blind Test

**Route:** `GET /color-blind-test`  
**File:** `resources/views/games/color-blind-test.blade.php`  
**SEO Keyword:** `color blind test online` — 1,200,000/month  
**H1:** `Color Blind Test — Free Ishihara-style colour blindness screening test with 10 plates`  
**Title:** `Color Blind Test — Free Online | MindSnap`  
**Meta:** `Free color blind test. Free Ishihara-style colour blindness screening test with 10 plates. No signup, play instantly.`

---

## What This Game Does

Free Ishihara-style colour blindness screening test with 10 plates.

---

## JavaScript Logic

```javascript
// Show circular dot pattern images (CSS-generated — no external images needed)
// User selects what number/shape they see from 4 options
// Test covers: red-green (deuteranopia), blue-yellow (tritanopia), total
// Note: This is a SCREENING test, not a medical diagnosis
// Always show disclaimer to see an optometrist for official diagnosis
```

---

## Result Display

10 test plates, result: likely normal / possible red-green / possible blue-yellow / consult optometrist. Medical disclaimer prominent. Share: 'I took the free colour blind test at MindSnap.co'

---

## SEO Structure
- Breadcrumb: Home > Games > Color Blind Test
- Internal links: 2 related games + /games category page
- Schema: WebApplication + FAQPage

---

## Claude Prompt

```
Build the Color Blind Test for MindSnap.co.

FILE: resources/views/games/color-blind-test.blade.php
ROUTE: GET /color-blind-test
CATEGORY COLOUR: #ffc107

SEO:
Title: "Color Blind Test — Free Online | MindSnap"
Meta:  "Free color blind test. Free Ishihara-style colour blindness screening test with 10 plates. No signup."
H1:    "Color Blind Test — Free Ishihara-style colour blindness screening test with 10 plates"

GAME LOGIC (Vanilla JS):
// Show circular dot pattern images (CSS-generated — no external images needed)
// User selects what number/shape they see from 4 options
// Test covers: red-green (deuteranopia), blue-yellow (tritanopia), total
// Note: This is a SCREENING test, not a medical diagnosis
// Always show disclaimer to see an optometrist for official diagnosis

RESULT:
10 test plates, result: likely normal / possible red-green / possible blue-yellow / consult optometrist. Medical disclaimer prominent. Share: 'I took the free colour blind test at MindSnap.co'

SHARE CARD: Canvas 420×220px with result + mindsnap.co URL
Share buttons: Copy, WhatsApp, Download image

BUILD 12 SECTIONS (standard tool page structure):
1.Breadcrumb 2.H1+badges 3.Game interface 4.Score/result
5.Share card 6.How to play 7.About the test 8.Content 300w
9.FAQ+schema 10.Related games 11.Category link 12.Schemas

MOBILE: Large tap targets (min 48px), works on touchscreen, no horizontal scroll
```
