# 25 — Water Intake Calculator

**Route:** `GET /water-intake-calculator`  
**File:** `resources/views/calculators/water-intake-calculator.blade.php`  
**Category:** Nutrition  
**SEO Keyword:** `how much water should i drink daily` — 600,000/month  

---

## SEO

| Field | Value |
|---|---|
| Title | `Water Intake Calculator — Daily Water Needs | MindSnap` |
| Meta | `Free water intake calculator. Find out how much water you should drink daily based on your weight, activity level and climate. Instant results.` |
| H1 | `Water Intake Calculator — How Much Water Should I Drink?` |
| Canonical | `https://mindsnap.co/water-intake-calculator` |
| Category | [Nutrition Tools](/nutrition-tools) |

---

## What This Page Does

Water Intake Calculator page on MindSnap.co. Follows the standard 12-section tool page structure.

---

## Inputs

- **Body weight:** kg/lbs
- **Activity level:** Low / Moderate / High / Athlete
- **Climate:** Temperate / Warm / Hot / Very Hot
- **Output unit:** Litres / Glasses (250ml) / Fluid oz

---

## JavaScript Logic

```javascript
function calcWater(weightKg, activity, climate) {
  const base = weightKg * 0.033; // litres
  const activityAdj = { low:0, moderate:0.35, high:0.7, athlete:1.2 };
  const climateAdj  = { temperate:0, warm:0.3, hot:0.6, very_hot:1.0 };
  const total = base + activityAdj[activity] + climateAdj[climate];
  return {
    litres:  +total.toFixed(1),
    glasses: Math.round(total / 0.25),
    flOz:    Math.round(total * 33.814)
  };
}
```

---

## Result Output

Daily water target in litres, glasses, and fluid oz. Hourly breakdown (if awake 16 hours). Tips on how to spread intake throughout the day.

---

## Formula Explanation (Section 7)

Base: 33ml per kg bodyweight. Activity adjustment: +350ml (moderate) to +1200ml (athlete). Climate adjustment: +300ml (warm) to +1000ml (very hot).

---

## Content Section (Section 8)

**H2:** `Daily Water Intake — Why Hydration Matters`

Explain dehydration signs, water needs vs thirst signal, role of food in hydration, myths (coffee doesn't dehydrate you significantly), electrolytes for athletes. ~330 words.

---

## FAQ (Section 9)

| # | Question | Answer |
|---|---|---|
| Q1 | Is 8 glasses of water a day accurate? | The '8 glasses a day' rule is a rough average. Actual needs depend on your weight, activity, climate and diet. This calculator gives a personalised estimate based on your specific factors. |
| Q2 | Does coffee count toward daily water intake? | Yes. Despite being a mild diuretic, coffee contributes to daily fluid intake. Studies show moderate coffee consumption (up to 4 cups) does not cause net fluid loss in regular drinkers. |
| Q3 | How do I know if I am dehydrated? | Dark yellow or amber urine is the most reliable indicator of dehydration. Pale yellow is ideal. Other signs include headache, fatigue, dry mouth, and reduced concentration. |
| Q4 | Do I need more water when exercising? | Yes — aim for 400-600ml 2 hours before exercise, 150-250ml every 15-20 minutes during, and 450-675ml per 0.5kg lost after exercise. Sweat rate varies by individual and conditions. |
| Q5 | Is MindSnap's Water Intake Calculator free? | Yes — completely free, no signup, no download. Use it instantly on any device. |

---

## Related Tools (Section 10)

1. **TDEE Calculator** → `/calorie-calculator`
2. **Protein Calculator** → `/protein-calculator`
3. **Nutrition Tools** → `/nutrition-tools`

---



## Claude Prompt

```
Build the Water Intake Calculator page for MindSnap.co.

FILE: resources/views/calculators/water-intake-calculator.blade.php
ROUTE: GET /water-intake-calculator
CATEGORY COLOUR: #fd7e14

SEO:
Title:    "Water Intake Calculator — Daily Water Needs | MindSnap"
Meta:     "Free water intake calculator. Find out how much water you should drink daily based on your weight, activity level and climate. Instant results."
H1:       "Water Intake Calculator — How Much Water Should I Drink?"
Canonical: https://mindsnap.co/water-intake-calculator

BUILD ALL 12 SECTIONS:
1. Breadcrumb: Home > Nutrition Tools > Water Intake Calculator + BreadcrumbList schema
2. H1 + 2-sentence description + trust badges (Free/No Signup/Instant/Mobile Friendly)
3. INPUT FORM:
- **Body weight:** kg/lbs
- **Activity level:** Low / Moderate / High / Athlete
- **Climate:** Temperate / Warm / Hot / Very Hot
- **Output unit:** Litres / Glasses (250ml) / Fluid oz
   Labels above inputs. Units toggle where applicable.
   #e94560 Calculate button, full-width mobile, min 52px height.
4. RESULT: fadeIn animation, large result in #fd7e14, interpretation text
5. SHARE CARD: canvas 420x220px, Copy/WhatsApp/Download buttons
6. HOW TO USE: H2 + 4-5 numbered steps
7. FORMULA: H2 + plain English + formula in styled box
8. CONTENT: H2 "Daily Water Intake — Why Hydration Matters" + 300-400 words + 2-3 H3 subheadings
9. FAQ: H2 + Bootstrap accordion + 5 Q&As + FAQPage JSON-LD schema
10. RELATED TOOLS: 3 cards — TDEE Calculator, Protein Calculator, Nutrition Tools category page
11. CATEGORY LINK: text sentence linking back to /nutrition-tools
12. SCHEMAS in @section('schema'):
    - WebApplication JSON-LD
    - BreadcrumbList JSON-LD  
    - FAQPage JSON-LD

VANILLA JS LOGIC:
function calcWater(weightKg, activity, climate) {
  const base = weightKg * 0.033; // litres
  const activityAdj = { low:0, moderate:0.35, high:0.7, athlete:1.2 };
  const climateAdj  = { temperate:0, warm:0.3, hot:0.6, very_hot:1.0 };
  const total = base + activityAdj[activity] + climateAdj[climate];
  return {
    litres:  +total.toFixed(1),
    glasses: Math.round(total / 0.25),
    flOz:    Math.round(total * 33.814)
  };
}

MOBILE: all inputs 100% width, 48px height, buttons 52px, test at 375px
PERFORMANCE: defer all JS, lazy load images
```
