# 37 — Biology Quiz

**Route:** `GET /quiz/biology`  
**File:** Uses `resources/views/quizzes/quiz.blade.php` (shared template)  
**SEO Keyword:** `biology quiz questions` — 800,000/month  
**H1:** `Biology Quiz — Test Your Knowledge Free`  
**Title:** `Biology Quiz — Free Online Questions | MindSnap`  
**Meta:** `Free biology quiz. Test your biology knowledge covering cells, genetics, anatomy, evolution and ecology. No signup needed.`

---

## What This Quiz Contains

Test your biology knowledge covering cells, genetics, anatomy, evolution and ecology.

- **Questions:** 10 per session (randomised from DB pool)
- **Difficulty:** Easy → Medium → Hard progression
- **Time limit:** Optional 30 seconds per question
- **Age group:** All (teens and adults)

---

## FAQ

| # | Question | Answer |
|---|---|---|
| Q1 | What is the powerhouse of the cell? | The mitochondria — it produces ATP energy through cellular respiration. |
| Q2 | How many chromosomes do humans have? | 46 chromosomes — arranged in 23 pairs. |
| Q3 | What carries oxygen in red blood cells? | Haemoglobin — an iron-containing protein that binds to oxygen. |
| Q4 | What is the largest organ in the human body? | The skin — covering approximately 1.7-2 square metres in adults. |
| Q5 | Is this biology quiz free? | Yes — completely free, no signup, instant results. |

---

## SEO Structure

- Breadcrumb: Home > Quizzes > Biology Quiz
- Internal links: 2 related quizzes + /quizzes listing page
- Schema: BreadcrumbList + FAQPage

---

## Database Seed

Ask Claude to generate 50 biology quiz questions in the quiz_questions table format:
```
category: 'biology'
difficulty: mix of easy/medium/hard
age_group: 'all'
```

---

## Claude Prompt

```
Build the Biology Quiz page for MindSnap.co.
Route: /quiz/biology
This page uses the shared quiz.blade.php template from Feature 34.

Controller method: QuizController@show('biology')
Load 10 random questions from quiz_questions where category='biology'

SEO:
Title: "Biology Quiz — Free Online Questions | MindSnap"
Meta:  "Free biology quiz. Test your biology knowledge covering cells, genetics, anatomy, evolution and ecology. No signup."
H1:    "Biology Quiz — Test Your Knowledge Free"
Canonical: https://mindsnap.co/quiz/biology

Add to controller: $meta array with title, description, h1, colour (#e94560), keyword
Pass to quiz.blade.php view

Generate 50 seed questions for this category in QuizSeeder.php
Include: question, option_a-d, correct_option, explanation, difficulty, age_group='all'
```
