# 34 — Quiz System Core

The quiz engine powers all quiz pages. Build this once — all individual quizzes reuse it.

---

## Files

| File | Purpose |
|---|---|
| `quizzes/index.blade.php` | All quizzes listing page |
| `quizzes/quiz.blade.php` | Quiz interface (reused for all quiz types) |
| `quizzes/result.blade.php` | Score + answer review |
| `QuizController.php` | Routes all quiz traffic |
| `quiz_questions` table | All question content |
| `quiz_attempts` table | Saved scores |

---

## Quiz Interface Design

```
[Category Badge]  History Quiz              ★★★☆☆
████████████████████░░░░░░  Question 7/10   ⏱ 0:23

  Q7. In what year did World War 2 end?

  ┌──────────────┐  ┌──────────────┐
  │   A.  1943   │  │   B.  1944   │
  └──────────────┘  └──────────────┘
  ┌──────────────┐  ┌──────────────┐
  │ C.  1945  ✓  │  │   D.  1946   │
  └──────────────┘  └──────────────┘

  ✓ Correct! WWII ended on September 2, 1945.

                          [Next Question →]
```

### Answer Button States
- Unselected: white bg, `#e0e0e0` border
- Selected (before reveal): `#cce5ff` blue
- Correct: `#d4edda` green + ✓
- Wrong: `#f8d7da` red + ✗ + show correct answer green
- Explanation shown after any answer

---

## Result Page

```
Score rating system:
10/10  → 🏆 Genius!
8-9/10 → ⭐ Expert
6-7/10 → 👍 Good
4-5/10 → 📚 Keep Learning
0-3/10 → 💪 Try Again
```

Canvas share card (420×220px):
```
┌────────────────────────────────────┐
│ 🧠 MindSnap.co                    │
│   I scored  8/10                   │
│   History Quiz                     │
│   Can you beat me?                 │
│   mindsnap.co/quiz/history        │
└────────────────────────────────────┘
```

---

## JavaScript Core

```javascript
// Embedded in quiz.blade.php via @section('scripts')
const questions = @json($questions);  // from controller
let current=0, score=0, answers=[], startTime=Date.now();

function loadQuestion(i) {
  const q = questions[i];
  document.getElementById('question-text').textContent = q.question;
  ['a','b','c','d'].forEach(opt => {
    document.getElementById(`btn-${opt}`).textContent = q[`option_${opt}`];
    document.getElementById(`btn-${opt}`).className = 'btn btn-option w-100 mb-2 text-start p-3';
    document.getElementById(`btn-${opt}`).disabled = false;
  });
  document.getElementById('explanation').classList.add('d-none');
  document.getElementById('next-btn').classList.add('d-none');
  updateProgress(i);
}

function selectAnswer(chosen) {
  const q = questions[current];
  answers.push({q:q.question, chosen, correct:q.correct_option, explanation:q.explanation});
  if (chosen === q.correct_option) score++;
  document.getElementById(`btn-${chosen}`).classList.add(chosen===q.correct_option?'btn-correct':'btn-wrong');
  if (chosen !== q.correct_option)
    document.getElementById(`btn-${q.correct_option}`).classList.add('btn-correct');
  ['a','b','c','d'].forEach(o => document.getElementById(`btn-${o}`).disabled=true);
  document.getElementById('explanation').textContent = q.explanation;
  document.getElementById('explanation').classList.remove('d-none');
  document.getElementById('next-btn').classList.remove('d-none');
  setTimeout(nextQuestion, 3000); // auto-advance
}

function nextQuestion() {
  if (++current >= questions.length) { submitQuiz(); return; }
  loadQuestion(current);
}

function submitQuiz() {
  document.getElementById('quiz-score').value = score;
  document.getElementById('quiz-answers').value = JSON.stringify(answers);
  document.getElementById('quiz-time').value = Math.round((Date.now()-startTime)/1000);
  document.getElementById('quiz-form').submit();
}

document.addEventListener('DOMContentLoaded', () => loadQuestion(0));
```

---

## Claude Prompt

```
Build the complete quiz system for MindSnap.co.

FILES:
- resources/views/quizzes/index.blade.php
- resources/views/quizzes/quiz.blade.php
- resources/views/quizzes/result.blade.php
- app/Http/Controllers/QuizController.php
- database/seeders/QuizSeeder.php (100 general knowledge questions)

QUIZ INTERFACE:
- Load questions from $questions (JSON passed from controller)
- Progress bar + question counter + optional 30s timer (toggle to disable)
- Answer buttons: col-md-6 col-12 grid (2 per row desktop, 1 mobile)
- Min 48px button height, full-width on mobile
- Colour feedback on click + explanation text + auto-advance 3s
- KIDS MODE: detect /kids/* URL prefix — larger text, no timer, star score, encouraging messages

RESULT PAGE:
- CSS count-up animation to final score
- Rating badge system (5 tiers)
- Canvas share card 420x220px
- navigator.share API for mobile, clipboard fallback desktop
- Full Q&A review below score

CONTROLLER methods: index(), show($category), daily(), iqTest(), saveResult()
SEEDER: 100 GK questions covering geography, history, science, pop culture
```
