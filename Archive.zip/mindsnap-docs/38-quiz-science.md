# 38 — Science Quiz

**Route:** `GET /quiz/science`  
**File:** Uses `resources/views/quizzes/quiz.blade.php` (shared template)  
**SEO Keyword:** `science trivia questions` — 600,000/month  
**H1:** `Science Quiz — Test Your Knowledge Free`  
**Title:** `Science Quiz — Free Online Questions | MindSnap`  
**Meta:** `Free science quiz. Test your science knowledge across physics, chemistry, earth science and space. No signup needed.`

---

## What This Quiz Contains

Test your science knowledge across physics, chemistry, earth science and space.

- **Questions:** 10 per session (randomised from DB pool)
- **Difficulty:** Easy → Medium → Hard progression
- **Time limit:** Optional 30 seconds per question
- **Age group:** All (teens and adults)

---

## FAQ

| # | Question | Answer |
|---|---|---|
| Q1 | What is the speed of light? | Approximately 299,792 km/s (186,000 miles/s) in a vacuum. |
| Q2 | What element has the atomic number 1? | Hydrogen — the lightest and most abundant element in the universe. |
| Q3 | What force keeps planets in orbit? | Gravity — described by Newton's law of universal gravitation. |
| Q4 | What is the hardest natural substance? | Diamond — a form of carbon with a Mohs hardness of 10. |
| Q5 | Is this science quiz free? | Yes — completely free, no signup, instant results. |

---

## SEO Structure

- Breadcrumb: Home > Quizzes > Science Quiz
- Internal links: 2 related quizzes + /quizzes listing page
- Schema: BreadcrumbList + FAQPage

---

## Database Seed

Ask Claude to generate 50 science quiz questions in the quiz_questions table format:
```
category: 'science'
difficulty: mix of easy/medium/hard
age_group: 'all'
```

---

## Claude Prompt

```
Build the Science Quiz page for MindSnap.co.
Route: /quiz/science
This page uses the shared quiz.blade.php template from Feature 34.

Controller method: QuizController@show('science')
Load 10 random questions from quiz_questions where category='science'

SEO:
Title: "Science Quiz — Free Online Questions | MindSnap"
Meta:  "Free science quiz. Test your science knowledge across physics, chemistry, earth science and space. No signup."
H1:    "Science Quiz — Test Your Knowledge Free"
Canonical: https://mindsnap.co/quiz/science

Add to controller: $meta array with title, description, h1, colour (#e94560), keyword
Pass to quiz.blade.php view

Generate 50 seed questions for this category in QuizSeeder.php
Include: question, option_a-d, correct_option, explanation, difficulty, age_group='all'
```
