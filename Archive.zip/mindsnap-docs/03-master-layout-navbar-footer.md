# 03 — Master Layout, Navbar & Footer

---

## app.blade.php

**File:** `resources/views/layouts/app.blade.php`

### Full Structure

```blade
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="csrf-token" content="{{ csrf_token() }}">

  <title>@yield('title', 'Free Health Tools & Brain Quizzes | MindSnap')</title>
  <meta name="description" content="@yield('description', 'MindSnap — free health calculators, sleep tools and brain quizzes for everyone.')">
  <link rel="canonical" href="@yield('canonical', 'https://mindsnap.co')">

  {{-- Open Graph --}}
  <meta property="og:title"       content="@yield('title')">
  <meta property="og:description" content="@yield('description')">
  <meta property="og:url"         content="@yield('canonical')">
  <meta property="og:image"       content="@yield('og_image', asset('images/og-default.jpg'))">
  <meta property="og:type"        content="website">
  <meta name="twitter:card"       content="summary_large_image">

  {{-- Fonts --}}
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

  {{-- Bootstrap 5 --}}
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

  {{-- Custom CSS (design system variables) --}}
  <style>
    :root {
      --primary-dark:#1a1a2e; --primary-mid:#0f3460; --primary-cta:#e94560;
      --bg:#f8f9fa; --card:#ffffff; --text:#555; --border:#e0e0e0;
      --sleep:#6c63ff; --fitness:#28a745; --nutrition:#fd7e14;
      --quiz:#e94560; --kids:#17a2b8; --life:#6f42c1; --games:#ffc107;
    }
    body { font-family:'Inter',sans-serif; background:var(--bg); color:var(--text); font-size:16px; }
    .btn-cta { background:var(--primary-cta); color:#fff; border-radius:8px; padding:12px 28px; font-weight:500; min-height:48px; border:none; }
    .btn-cta:hover { background:#c73652; color:#fff; }
    .tool-card { border-radius:12px; box-shadow:0 4px 20px rgba(0,0,0,.08); transition:transform .2s; }
    .tool-card:hover { transform:translateY(-4px); }
    .result-box { background:#f0f2f5; border-radius:8px; padding:20px 24px; animation:fadeIn .3s ease; }
    @keyframes fadeIn { from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:translateY(0)} }
    h1{font-size:clamp(1.8rem,4vw,2.5rem); font-weight:700; color:var(--primary-dark);}
    h2{font-size:clamp(1.4rem,3vw,2rem); font-weight:700; color:var(--primary-mid);}
    @media(max-width:768px){section{padding:40px 0!important;} .card{padding:16px!important;}}
  </style>

  {{-- Page-specific schema --}}
  @yield('schema')

  @if(config('adsense.enabled'))
  <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"
          data-ad-client="{{ config('adsense.publisher_id') }}"></script>
  @endif
</head>
<body>

  @include('components.navbar')

  <main>
    @yield('content')
  </main>

  @include('components.footer')

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" defer></script>
  @yield('scripts')
</body>
</html>
```

---

## Navbar

**File:** `resources/views/components/navbar.blade.php`

### What It Contains
- Sticky top, background `#1a1a2e`
- Logo: brain SVG + "MindSnap" white text
- 7 category links with mega-dropdowns (desktop)
- "Daily Quiz" pill button + search icon (right)
- Hamburger → full-screen overlay with category tiles (mobile)
- Search modal with live JS search

### Dropdown Contents Per Category

| Category | Icon | Items |
|---|---|---|
| Sleep | 😴 | Sleep Calc, Wake-Up, Nap, Baby Sleep, Sleep Debt, Caffeine, Jet Lag |
| Fitness | 💪 | BMI, TDEE, Deficit, Macros, Protein, 1RM, Body Fat, Heart Rate, Running Pace |
| Nutrition | 🥗 | Water Intake, IF Calculator |
| Brain Quiz | 🧠 | Daily Quiz, GK, History, Biology, Science, Geography, AI Generator |
| Kids Zone | 👶 | Math Puzzles, Word Games, Science, Animals, Spelling |
| Life Tools | ⏰ | Age, Days Between, Days Until, Pregnancy, Ovulation, Retirement |
| Games | 🎮 | Typing Speed, Reaction Time, Memory, Word Scramble, Color Blind |

---

## Footer

**File:** `resources/views/components/footer.blade.php`

### Layout

```
──── top border 3px #e94560 ────

COL 1              COL 2            COL 3              COL 4
MindSnap logo      Health Tools     Quizzes & Games    Company
Tagline            Sleep Calc       Daily Quiz         About
Works worldwide    BMI Calc         GK Quiz            Privacy
No signup          TDEE Calc        History Quiz       Contact
Social icons       Water Intake     Typing Speed       Sitemap
                   Protein          Reaction Time      [Safe for Kids ✓]

──────────── © 2025 MindSnap.co  |  Sleep Fitness Nutrition Quizzes Kids Games ────────────
```

---

## Claude Prompt

```
Build app.blade.php, navbar.blade.php, and footer.blade.php for MindSnap.co.

Use the exact code structure shown above.

NAVBAR SPECIFICS:
- Bootstrap navbar-dark, sticky-top
- Mega-dropdown: show tool cards in 3-column grid on hover (desktop)
- Mobile: offcanvas or full-screen overlay with 8 category tiles (2×4 grid)
- Each tile: solid category colour bg, emoji, name, link to category page
- Accordion inside each tile showing individual tools
- Search modal: Bootstrap modal, full-screen, input with live JS filtering
  Pass $toolsArray from controller as @json($tools) for JS to search

FOOTER SPECIFICS:
- 4-column Bootstrap grid (col-lg-3 col-md-6 col-12)
- All links: color:rgba(255,255,255,0.8), hover: #e94560
- Bottom bar: d-flex justify-content-between
- Category pills: Bootstrap badge bg-secondary with hover state

TEST: confirm navbar collapses correctly at 375px with no horizontal scroll
```
