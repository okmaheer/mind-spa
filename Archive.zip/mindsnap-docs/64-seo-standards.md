# 64 — SEO Standards (Master Rules)

> Paste the quick reference at the bottom into every Claude session.

---

## Every Page Must Have

| Requirement | Rule |
|---|---|
| Title tag | Keyword first, `\| MindSnap` last, max 60 chars |
| Meta description | Keyword in first 10 words, max 155 chars, soft CTA |
| H1 (exactly one) | Contains exact keyword, max 70 chars |
| H2 tags (3-6) | Keyword variations, logical hierarchy |
| H3 tags | FAQ answers, how-to steps, sub-sections |
| Content | 200-400 words, natural keywords, H3 subheadings |
| FAQ section | 5 questions minimum + FAQPage JSON-LD |
| Canonical URL | Self-referencing, correct URL |
| WebApplication schema | Every tool page |
| BreadcrumbList schema | Every page |
| FAQPage schema | Every page |
| Open Graph tags | og:title, description, image, url |
| Internal links | 2 related tools + parent category page |
| Alt text | All images descriptive |
| Mobile | Perfect at 375px |
| Speed | Under 2 seconds, 90+ PageSpeed |

---

## Title Tag Formulas

```
TOOL:     [Tool Name] — Free Online [Type] | MindSnap    (max 60)
QUIZ:     [Topic] Quiz — [X] Questions Free | MindSnap
CATEGORY: Free [Category] Tools Online | MindSnap
CONTENT:  [Question?] — [Answer Hook] | MindSnap
HOME:     Free Health Calculators & Brain Quizzes | MindSnap
```

---

## Schema Templates

### WebApplication (all tool pages)
```json
{"@context":"https://schema.org","@type":"WebApplication",
 "name":"[Tool] | MindSnap","url":"https://mindsnap.co/[slug]",
 "applicationCategory":"HealthApplication","operatingSystem":"Any",
 "offers":{"@type":"Offer","price":"0","priceCurrency":"USD"}}
```

### BreadcrumbList (all pages)
```json
{"@context":"https://schema.org","@type":"BreadcrumbList",
 "itemListElement":[
   {"@type":"ListItem","position":1,"name":"Home","item":"https://mindsnap.co"},
   {"@type":"ListItem","position":2,"name":"[Category]","item":"https://mindsnap.co/[cat]"},
   {"@type":"ListItem","position":3,"name":"[Tool]","item":"https://mindsnap.co/[slug]"}
 ]}
```

---

## Quick Reference (paste into every Claude session)

```
MindSnap.co SEO RULES — apply to every page:

Title: [Keyword first] — [Benefit] | MindSnap  (max 60 chars)
Meta: keyword in first 10 words, max 155 chars, ends with soft CTA
H1: exactly one, contains target keyword, max 70 chars
H2: 3-6 per page using keyword variations
Content: 200-400 words, H3 subheadings, natural keywords 3-5x
FAQ: 5 questions + FAQPage JSON-LD schema
Schemas: WebApplication + BreadcrumbList + FAQPage on every tool page
Internal links: 2 related tools + category page (descriptive anchor text)
Mobile: 375px first, 48px tap targets, 16px min font, 100% input width
Speed: defer all JS, lazy images with width+height, Cloudflare caching

Tool page 12 sections (always this order):
1.Breadcrumb 2.H1+badges 3.Form 4.Result 5.Share
6.How to Use 7.Formula 8.Content 9.FAQ 10.Related 11.Category 12.Schemas
```
