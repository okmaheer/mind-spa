# 09 — Baby Sleep Calculator

**Route:** `GET /baby-sleep-calculator`  
**File:** `resources/views/calculators/baby-sleep-calculator.blade.php`  
**Category:** Sleep  
**SEO Keyword:** `baby sleep schedule` — 600,000/month  

---

## SEO

| Field | Value |
|---|---|
| Title | `Baby Sleep Calculator — Free Baby Sleep Schedule | MindSnap` |
| Meta | `Free baby sleep calculator. Find how much sleep your baby needs and get a nap schedule based on their age in months. No signup.` |
| H1 | `Baby Sleep Calculator — Schedule by Age` |
| Canonical | `https://mindsnap.co/baby-sleep-calculator` |
| Category | [Sleep Tools](/sleep-tools) |

---

## What This Page Does

Baby Sleep Calculator page on MindSnap.co. Follows the standard 12-section tool page structure.

---

## Inputs

- **Baby age:** months (0-36) — number input or slider
- **Wake-up time:** hour + minute (what time baby wakes in morning)

---

## JavaScript Logic

```javascript
const SLEEP_NEEDS = [
  { maxMonths: 3,  totalHours: 16, naps: 4, napLength: 45,  nightHours: 8 },
  { maxMonths: 6,  totalHours: 15, naps: 3, napLength: 60,  nightHours: 10 },
  { maxMonths: 9,  totalHours: 14, naps: 2, napLength: 90,  nightHours: 11 },
  { maxMonths: 12, totalHours: 14, naps: 2, napLength: 90,  nightHours: 11 },
  { maxMonths: 18, totalHours: 13, naps: 1, napLength: 90,  nightHours: 11 },
  { maxMonths: 24, totalHours: 13, naps: 1, napLength: 60,  nightHours: 11 },
  { maxMonths: 36, totalHours: 12, naps: 1, napLength: 60,  nightHours: 11 },
];
function getBabySchedule(ageMonths, wakeTimeMinutes) {
  const needs = SLEEP_NEEDS.find(s => ageMonths <= s.maxMonths) || SLEEP_NEEDS[SLEEP_NEEDS.length-1];
  // Generate nap times evenly spaced from wake time
  const napTimes = [];
  let currentTime = wakeTimeMinutes;
  const awakeWindows = distributeAwakeWindows(needs, wakeTimeMinutes);
  // ...returns array of nap start/end times and bedtime
  return { needs, napTimes, bedtime: calculateBedtime(wakeTimeMinutes, needs) };
}
```

---

## Result Output

Visual daily schedule showing wake time, each nap with start/end, and bedtime. Shows total sleep hours and awake windows. Colour-coded timeline bar.

---

## Formula Explanation (Section 7)

Based on AAP (American Academy of Pediatrics) recommended sleep totals by age. Naps spaced according to age-appropriate awake windows (1-4 hours depending on age).

---

## Content Section (Section 8)

**H2:** `Baby Sleep by Age — How Much Is Normal?`

Table of sleep needs by age, awake windows, nap transitions (4→3→2→1 nap), signs of overtiredness. ~350 words. Include medical disclaimer.

---

## FAQ (Section 9)

| # | Question | Answer |
|---|---|---|
| Q1 | How much sleep does a newborn need? | Newborns (0-3 months) need 14-17 hours of sleep per day across multiple short sleep periods. They cannot yet distinguish day from night. |
| Q2 | When do babies drop to one nap? | Most babies transition from two naps to one nap between 15-18 months. Signs include resisting the second nap or difficulty falling asleep at bedtime. |
| Q3 | What is an awake window? | An awake window is the time between sleep periods that a baby can comfortably stay awake without becoming overtired. Newborns have 45-60 minute windows; 1-year-olds can manage 3-4 hours. |
| Q4 | Why does my baby fight sleep? | Overtiredness is the most common cause. When babies miss their sleep window, cortisol (a stress hormone) makes it harder to fall asleep. Watch for tired cues like eye rubbing. |
| Q5 | Is MindSnap's Baby Sleep Calculator free? | Yes — completely free, no signup, no download. Use it instantly on any device. |

---

## Related Tools (Section 10)

1. **Sleep Cycle Calculator** → `/sleep-calculator`
2. **Nap Calculator** → `/nap-calculator`
3. **Sleep Tools** → `/sleep-tools`

---



## Claude Prompt

```
Build the Baby Sleep Calculator page for MindSnap.co.

FILE: resources/views/calculators/baby-sleep-calculator.blade.php
ROUTE: GET /baby-sleep-calculator
CATEGORY COLOUR: #6c63ff

SEO:
Title:    "Baby Sleep Calculator — Free Baby Sleep Schedule | MindSnap"
Meta:     "Free baby sleep calculator. Find how much sleep your baby needs and get a nap schedule based on their age in months. No signup."
H1:       "Baby Sleep Calculator — Schedule by Age"
Canonical: https://mindsnap.co/baby-sleep-calculator

BUILD ALL 12 SECTIONS:
1. Breadcrumb: Home > Sleep Tools > Baby Sleep Calculator + BreadcrumbList schema
2. H1 + 2-sentence description + trust badges (Free/No Signup/Instant/Mobile Friendly)
3. INPUT FORM:
- **Baby age:** months (0-36) — number input or slider
- **Wake-up time:** hour + minute (what time baby wakes in morning)
   Labels above inputs. Units toggle where applicable.
   #e94560 Calculate button, full-width mobile, min 52px height.
4. RESULT: fadeIn animation, large result in #6c63ff, interpretation text
5. SHARE CARD: canvas 420x220px, Copy/WhatsApp/Download buttons
6. HOW TO USE: H2 + 4-5 numbered steps
7. FORMULA: H2 + plain English + formula in styled box
8. CONTENT: H2 "Baby Sleep by Age — How Much Is Normal?" + 300-400 words + 2-3 H3 subheadings
9. FAQ: H2 + Bootstrap accordion + 5 Q&As + FAQPage JSON-LD schema
10. RELATED TOOLS: 3 cards — Sleep Cycle Calculator, Nap Calculator, Sleep Tools category page
11. CATEGORY LINK: text sentence linking back to /sleep-tools
12. SCHEMAS in @section('schema'):
    - WebApplication JSON-LD
    - BreadcrumbList JSON-LD  
    - FAQPage JSON-LD

VANILLA JS LOGIC:
const SLEEP_NEEDS = [
  { maxMonths: 3,  totalHours: 16, naps: 4, napLength: 45,  nightHours: 8 },
  { maxMonths: 6,  totalHours: 15, naps: 3, napLength: 60,  nightHours: 10 },
  { maxMonths: 9,  totalHours: 14, naps: 2, napLength: 90,  nightHours: 11 },
  { maxMonths: 12, totalHours: 14, naps: 2, napLength: 90,  nightHours: 11 },
  { maxMonths: 18, totalHours: 13, naps: 1, napLength: 90,  nightHours: 11 },
  { maxMonths: 24, totalHours: 13, naps: 1, napLength: 60,  nightHours: 11 },
  { maxMonths: 36, totalHours: 12, naps: 1, napLength: 60,  nightHours: 11 },
];
function getBabySchedule(ageMonths, wakeTimeMinutes) {
  const needs = SLEEP_NEEDS.find(s => ageMonths <= s.maxMonths) || SLEEP_NEEDS[SLEEP_NEEDS.length-1];
  // Generate nap times evenly spaced from wake time
  const napTimes = [];
  let currentTime = wakeTimeMinutes;
  const awakeWindows = distributeAwakeWindows(needs, wakeTimeMinutes);
  // ...returns array of nap start/end times and bedtime
  return { needs, napTimes, bedtime: calculateBedtime(wakeTimeMinutes, needs) };
}

MOBILE: all inputs 100% width, 48px height, buttons 52px, test at 375px
PERFORMANCE: defer all JS, lazy load images
```
