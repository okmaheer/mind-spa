# 12 — Jet Lag Calculator

**Route:** `GET /jet-lag-calculator`  
**File:** `resources/views/calculators/jet-lag-calculator.blade.php`  
**Category:** Sleep  
**SEO Keyword:** `jet lag calculator` — 300,000/month  

---

## SEO

| Field | Value |
|---|---|
| Title | `Jet Lag Calculator — Recovery Time & Tips | MindSnap` |
| Meta | `Free jet lag calculator. Enter your flight route and find out how many days to recover and what time to sleep to beat jet lag faster.` |
| H1 | `Jet Lag Calculator — How Long to Recover & Beat Jet Lag` |
| Canonical | `https://mindsnap.co/jet-lag-calculator` |
| Category | [Sleep Tools](/sleep-tools) |

---

## What This Page Does

Jet Lag Calculator page on MindSnap.co. Follows the standard 12-section tool page structure.

---

## Inputs

- **Departure timezone:** select from list
- **Arrival timezone:** select from list
- **Flight direction:** East / West (auto-detected from timezones)
- **Arrival date/time:** date + time inputs

---

## JavaScript Logic

```javascript
function calculateJetLag(fromTZ, toTZ, direction) {
  const hourDiff  = Math.abs(getTimezoneOffset(fromTZ, toTZ));
  // East travel = harder, takes longer to recover
  const recoveryDays = direction === 'east'
    ? Math.ceil(hourDiff * 1.5)   // 1 day per ~40 min timezone east
    : Math.ceil(hourDiff);         // 1 day per hour timezone west
  // Generate sleep adjustment schedule: shift 1-2 hours per day
  const schedule = generateAdjustmentSchedule(hourDiff, direction, recoveryDays);
  return { hourDiff, recoveryDays, schedule, bodyClockTime: getBodyClockTime(fromTZ, toTZ) };
}
```

---

## Result Output

Shows timezone difference, estimated recovery days, your body clock time at destination, and a day-by-day sleep adjustment schedule to recover faster.

---

## Formula Explanation (Section 7)

Recovery time: eastward travel ~1 day per 40-minute timezone crossed. Westward ~1 day per hour. Body adjusts 1-2 hours per day. Complete darkness/light exposure at correct times speeds recovery.

---

## Content Section (Section 8)

**H2:** `How to Beat Jet Lag — Science-Based Tips`

Explain why east travel is harder, the role of melatonin and light exposure, pre-flight adjustment strategies, hydration, avoiding alcohol on flights. ~340 words.

---

## FAQ (Section 9)

| # | Question | Answer |
|---|---|---|
| Q1 | Why is eastward travel harder for jet lag? | Eastward travel requires advancing your circadian rhythm (sleeping earlier), which the body finds harder than delaying it. The body's natural rhythm is slightly longer than 24 hours, making westward shifts easier. |
| Q2 | How long does jet lag last? | Jet lag typically lasts 1 day for every 1-2 time zones crossed. Eastward travel can take 50% longer to recover from than westward travel across the same distance. |
| Q3 | Does melatonin help with jet lag? | Yes, melatonin taken at the destination's bedtime can help reset your circadian rhythm. The typical dose is 0.5-5mg. Consult a doctor before use, especially with other medications. |
| Q4 | What foods or drinks make jet lag worse? | Alcohol and caffeine both worsen jet lag. Alcohol disrupts REM sleep and dehydrates you. Caffeine in the wrong timezone delays your body clock adjustment. |
| Q5 | Is MindSnap's Jet Lag Calculator free? | Yes — completely free, no signup, no download. Use it instantly on any device. |

---

## Related Tools (Section 10)

1. **Sleep Cycle Calculator** → `/sleep-calculator`
2. **Caffeine Cut-Off Calculator** → `/caffeine-sleep-calculator`
3. **Sleep Tools** → `/sleep-tools`

---



## Claude Prompt

```
Build the Jet Lag Calculator page for MindSnap.co.

FILE: resources/views/calculators/jet-lag-calculator.blade.php
ROUTE: GET /jet-lag-calculator
CATEGORY COLOUR: #6c63ff

SEO:
Title:    "Jet Lag Calculator — Recovery Time & Tips | MindSnap"
Meta:     "Free jet lag calculator. Enter your flight route and find out how many days to recover and what time to sleep to beat jet lag faster."
H1:       "Jet Lag Calculator — How Long to Recover & Beat Jet Lag"
Canonical: https://mindsnap.co/jet-lag-calculator

BUILD ALL 12 SECTIONS:
1. Breadcrumb: Home > Sleep Tools > Jet Lag Calculator + BreadcrumbList schema
2. H1 + 2-sentence description + trust badges (Free/No Signup/Instant/Mobile Friendly)
3. INPUT FORM:
- **Departure timezone:** select from list
- **Arrival timezone:** select from list
- **Flight direction:** East / West (auto-detected from timezones)
- **Arrival date/time:** date + time inputs
   Labels above inputs. Units toggle where applicable.
   #e94560 Calculate button, full-width mobile, min 52px height.
4. RESULT: fadeIn animation, large result in #6c63ff, interpretation text
5. SHARE CARD: canvas 420x220px, Copy/WhatsApp/Download buttons
6. HOW TO USE: H2 + 4-5 numbered steps
7. FORMULA: H2 + plain English + formula in styled box
8. CONTENT: H2 "How to Beat Jet Lag — Science-Based Tips" + 300-400 words + 2-3 H3 subheadings
9. FAQ: H2 + Bootstrap accordion + 5 Q&As + FAQPage JSON-LD schema
10. RELATED TOOLS: 3 cards — Sleep Cycle Calculator, Caffeine Cut-Off Calculator, Sleep Tools category page
11. CATEGORY LINK: text sentence linking back to /sleep-tools
12. SCHEMAS in @section('schema'):
    - WebApplication JSON-LD
    - BreadcrumbList JSON-LD  
    - FAQPage JSON-LD

VANILLA JS LOGIC:
function calculateJetLag(fromTZ, toTZ, direction) {
  const hourDiff  = Math.abs(getTimezoneOffset(fromTZ, toTZ));
  // East travel = harder, takes longer to recover
  const recoveryDays = direction === 'east'
    ? Math.ceil(hourDiff * 1.5)   // 1 day per ~40 min timezone east
    : Math.ceil(hourDiff);         // 1 day per hour timezone west
  // Generate sleep adjustment schedule: shift 1-2 hours per day
  const schedule = generateAdjustmentSchedule(hourDiff, direction, recoveryDays);
  return { hourDiff, recoveryDays, schedule, bodyClockTime: getBodyClockTime(fromTZ, toTZ) };
}

MOBILE: all inputs 100% width, 48px height, buttons 52px, test at 375px
PERFORMANCE: defer all JS, lazy load images
```
