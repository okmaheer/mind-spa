# 26 — Intermittent Fasting Calculator

**Route:** `GET /intermittent-fasting-calculator`  
**File:** `resources/views/calculators/intermittent-fasting-calculator.blade.php`  
**Category:** Nutrition  
**SEO Keyword:** `intermittent fasting calculator` — 800,000/month  

---

## SEO

| Field | Value |
|---|---|
| Title | `Intermittent Fasting Calculator — Free IF Timer | MindSnap` |
| Meta | `Free intermittent fasting calculator. Set your fasting schedule (16:8, 18:6, 5:2) and get your exact eating window and fasting start time.` |
| H1 | `Intermittent Fasting Calculator — Find Your Eating Window` |
| Canonical | `https://mindsnap.co/intermittent-fasting-calculator` |
| Category | [Nutrition Tools](/nutrition-tools) |

---

## What This Page Does

Intermittent Fasting Calculator page on MindSnap.co. Follows the standard 12-section tool page structure.

---

## Inputs

- **IF protocol:** 16:8 / 18:6 / 20:4 / 5:2 / OMAD (One Meal)
- **Wake-up time:** hour + minute
- **Preferred eating window start:** or auto-calculate from wake time

---

## JavaScript Logic

```javascript
const IF_PROTOCOLS = {
  '16:8': { fasting:16, eating:8, description:'Most popular, good for beginners' },
  '18:6': { fasting:18, eating:6, description:'More results, harder to maintain' },
  '20:4': { fasting:20, eating:4, description:'Advanced, significant results' },
  'omad': { fasting:23, eating:1, description:'One meal a day — very advanced' },
};
function calcIFWindow(protocol, wakeTimeMinutes, eatStartMinutes) {
  const { fasting, eating } = IF_PROTOCOLS[protocol];
  const eatEnd   = (eatStartMinutes + eating * 60) % 1440;
  const fastStart = eatEnd;
  const fastEnd   = (fastStart + fasting * 60) % 1440;
  return { eatStart: minutesToTime(eatStartMinutes), eatEnd: minutesToTime(eatEnd),
           fastStart: minutesToTime(fastStart), fastEnd: minutesToTime(fastEnd) };
}
```

---

## Result Output

Eating window start/end times, fasting window start/end times, countdown timer to next eating window (live updating), and colour-coded 24-hour timeline.

---

## Formula Explanation (Section 7)

16:8 example: eat from 12pm to 8pm (8-hour window), fast from 8pm to 12pm next day (16-hour window). Fasting window should include sleep time.

---

## Content Section (Section 8)

**H2:** `Intermittent Fasting — Which Protocol Is Right for You?`

Explain IF types, who should avoid IF (pregnant women, history of eating disorders, Type 1 diabetics without doctor approval), benefits backed by research, common mistakes. ~340 words.

---

## FAQ (Section 9)

| # | Question | Answer |
|---|---|---|
| Q1 | What is intermittent fasting? | Intermittent fasting is an eating pattern that cycles between periods of fasting and eating. It does not specify which foods to eat, only when to eat them. The most popular protocol is 16:8. |
| Q2 | Can I drink water during fasting? | Yes — water, black coffee, plain tea, and other zero-calorie drinks do not break a fast. Avoid drinks with calories, sugar, or dairy during the fasting window. |
| Q3 | Is intermittent fasting safe? | IF is safe for most healthy adults. It is not recommended for pregnant or breastfeeding women, people with a history of eating disorders, Type 1 diabetics, or those who are underweight. Consult a doctor if unsure. |
| Q4 | Will intermittent fasting make me lose muscle? | Muscle loss is minimal with IF when protein intake is adequate (1.6-2g/kg) and resistance training is maintained. Short fasting windows of 16-20 hours do not trigger significant muscle breakdown. |
| Q5 | Is MindSnap's Intermittent Fasting Calculator free? | Yes — completely free, no signup, no download. Use it instantly on any device. |

---

## Related Tools (Section 10)

1. **Water Intake Calculator** → `/water-intake-calculator`
2. **TDEE Calculator** → `/calorie-calculator`
3. **Nutrition Tools** → `/nutrition-tools`

---



## Claude Prompt

```
Build the Intermittent Fasting Calculator page for MindSnap.co.

FILE: resources/views/calculators/intermittent-fasting-calculator.blade.php
ROUTE: GET /intermittent-fasting-calculator
CATEGORY COLOUR: #fd7e14

SEO:
Title:    "Intermittent Fasting Calculator — Free IF Timer | MindSnap"
Meta:     "Free intermittent fasting calculator. Set your fasting schedule (16:8, 18:6, 5:2) and get your exact eating window and fasting start time."
H1:       "Intermittent Fasting Calculator — Find Your Eating Window"
Canonical: https://mindsnap.co/intermittent-fasting-calculator

BUILD ALL 12 SECTIONS:
1. Breadcrumb: Home > Nutrition Tools > Intermittent Fasting Calculator + BreadcrumbList schema
2. H1 + 2-sentence description + trust badges (Free/No Signup/Instant/Mobile Friendly)
3. INPUT FORM:
- **IF protocol:** 16:8 / 18:6 / 20:4 / 5:2 / OMAD (One Meal)
- **Wake-up time:** hour + minute
- **Preferred eating window start:** or auto-calculate from wake time
   Labels above inputs. Units toggle where applicable.
   #e94560 Calculate button, full-width mobile, min 52px height.
4. RESULT: fadeIn animation, large result in #fd7e14, interpretation text
5. SHARE CARD: canvas 420x220px, Copy/WhatsApp/Download buttons
6. HOW TO USE: H2 + 4-5 numbered steps
7. FORMULA: H2 + plain English + formula in styled box
8. CONTENT: H2 "Intermittent Fasting — Which Protocol Is Right for You?" + 300-400 words + 2-3 H3 subheadings
9. FAQ: H2 + Bootstrap accordion + 5 Q&As + FAQPage JSON-LD schema
10. RELATED TOOLS: 3 cards — Water Intake Calculator, TDEE Calculator, Nutrition Tools category page
11. CATEGORY LINK: text sentence linking back to /nutrition-tools
12. SCHEMAS in @section('schema'):
    - WebApplication JSON-LD
    - BreadcrumbList JSON-LD  
    - FAQPage JSON-LD

VANILLA JS LOGIC:
const IF_PROTOCOLS = {
  '16:8': { fasting:16, eating:8, description:'Most popular, good for beginners' },
  '18:6': { fasting:18, eating:6, description:'More results, harder to maintain' },
  '20:4': { fasting:20, eating:4, description:'Advanced, significant results' },
  'omad': { fasting:23, eating:1, description:'One meal a day — very advanced' },
};
function calcIFWindow(protocol, wakeTimeMinutes, eatStartMinutes) {
  const { fasting, eating } = IF_PROTOCOLS[protocol];
  const eatEnd   = (eatStartMinutes + eating * 60) % 1440;
  const fastStart = eatEnd;
  const fastEnd   = (fastStart + fasting * 60) % 1440;
  return { eatStart: minutesToTime(eatStartMinutes), eatEnd: minutesToTime(eatEnd),
           fastStart: minutesToTime(fastStart), fastEnd: minutesToTime(fastEnd) };
}

MOBILE: all inputs 100% width, 48px height, buttons 52px, test at 375px
PERFORMANCE: defer all JS, lazy load images
```
