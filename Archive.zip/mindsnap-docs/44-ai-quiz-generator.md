# 44 — AI Quiz Generator

**Route:** `GET /ai-quiz-generator` (page) + `POST /api/generate-quiz` (AJAX)  
**File:** `resources/views/quizzes/ai-generator.blade.php`  
**Controller:** `AiQuizController`  
**SEO Keyword:** `ai quiz generator` — 300,000/month  
**H1:** `AI Quiz Generator — Create a Quiz on Any Topic Instantly`  
**Title:** `AI Quiz Generator — Free Quiz Maker on Any Topic | MindSnap`  
**Meta:** `Free AI quiz generator. Type any topic and get 10 multiple choice questions instantly. Powered by Claude AI. No signup.`

---

## What It Does

User types any topic → Claude API generates 10 MCQ questions → quiz renders immediately using shared quiz engine.

**This is MindSnap's biggest differentiator.** No competitor offers this.

---

## Page Design

```
[🤖 AI Quiz Generator]
"Type any topic. Get 10 questions in seconds."

┌────────────────────────────────────────┐
│ e.g. "Ancient Rome", "Black Holes"...  │ [Generate Quiz →]
└────────────────────────────────────────┘

Popular topics:
[🏛 Ancient Rome] [🚀 Space] [⚽ Football] [🎬 Movies]
[🧬 DNA] [🌍 Climate] [💻 Tech] [🐋 Ocean Life]
```

Loading state: spinner + "Generating your quiz on [topic]..."  
Error state: friendly message + try again

---

## Controller Logic

```php
// AiQuizController.php

public function generate(Request $request)
{
    $topic    = strip_tags(trim($request->input('topic')));
    $cacheKey = 'ai_quiz_' . Str::slug($topic);

    if (cache()->has($cacheKey)) {
        return response()->json(cache()->get($cacheKey));
    }

    $response = Http::withHeaders([
        'x-api-key'         => config('services.claude.key'),
        'anthropic-version' => '2023-06-01',
        'content-type'      => 'application/json',
    ])->post('https://api.anthropic.com/v1/messages', [
        'model'      => 'claude-sonnet-4-20250514',
        'max_tokens' => 2000,
        'messages'   => [[
            'role'    => 'user',
            'content' => "Generate exactly 10 multiple choice questions about: {$topic}
Return ONLY a valid JSON array. No markdown, no preamble.
Each object: {question, option_a, option_b, option_c, option_d, correct_option (a/b/c/d), explanation}
Questions: first 3 easy, middle 4 medium, last 3 hard."
        ]]
    ]);

    $questions = json_decode($response->json('content.0.text'), true);
    cache()->put($cacheKey, $questions, now()->addHours(24));
    return response()->json($questions);
}
```

---

## Frontend AJAX

```javascript
document.getElementById('generate-btn').addEventListener('click', async () => {
  const topic = document.getElementById('topic-input').value.trim();
  if (!topic) return;
  showLoading(topic);
  try {
    const res = await fetch('/api/generate-quiz', {
      method:'POST',
      headers:{'Content-Type':'application/json','X-CSRF-TOKEN':csrfToken},
      body:JSON.stringify({topic})
    });
    const questions = await res.json();
    if (questions.error) { showError(questions.error); return; }
    renderQuiz(questions, topic); // uses same renderQuiz() as quiz.blade.php
  } catch { showError('Could not generate quiz. Please try again.'); }
});
```

---

## Claude Prompt

```
Build the AI quiz generator for MindSnap.co.

FILES:
- resources/views/quizzes/ai-generator.blade.php
- app/Http/Controllers/AiQuizController.php

PAGE: Input + popular topic pills + loading state + error state
After generation: hide form, show quiz using same JS engine as quiz.blade.php
Show "AI Generated" badge in quiz header

CONTROLLER:
- index(): render page with $popularTopics array
- generate(): validate topic (max 100 chars, strip tags) → check cache → call Claude API → cache 24h → return JSON

Config: CLAUDE_API_KEY in services.php
Route protection: rate limit to 10 requests per minute per IP (Laravel throttle middleware)

SEO:
- FAQPage schema with 5 questions about AI quiz generation
- WebApplication JSON-LD schema
- This page targets "quiz generator", "make a quiz online", "ai quiz maker"
```
