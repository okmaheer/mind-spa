# 18 — Protein Calculator

**Route:** `GET /protein-calculator`  
**File:** `resources/views/calculators/protein-calculator.blade.php`  
**Category:** Fitness  
**SEO Keyword:** `protein intake calculator` — 700,000/month  

---

## SEO

| Field | Value |
|---|---|
| Title | `Protein Calculator — Free Daily Protein Intake Tool | MindSnap` |
| Meta | `Free protein intake calculator. Find your daily protein needs based on your weight, activity level and fitness goal. Instant results.` |
| H1 | `Protein Calculator — How Much Protein Do You Need Daily?` |
| Canonical | `https://mindsnap.co/protein-calculator` |
| Category | [Fitness Tools](/fitness-tools) |

---

## What This Page Does

Protein Calculator page on MindSnap.co. Follows the standard 12-section tool page structure.

---

## Inputs

- **Body weight:** kg/lbs
- **Activity level:** Sedentary / Moderate / Active / Very Active
- **Goal:** Maintain muscle / Build muscle / Lose fat / Athletic performance
- **Age group:** Under 65 / 65+ (older adults need more)

---

## JavaScript Logic

```javascript
const PROTEIN_MULTIPLIERS = {
  sedentary_maintain:  0.8,  // g per kg
  moderate_maintain:   1.2,
  active_maintain:     1.4,
  sedentary_loss:      1.6,
  active_loss:         2.0,
  muscle_gain:         2.0,
  athletic:            2.2,
};
function calcProtein(weightKg, activity, goal, isOlder) {
  const key = `${activity}_${goal}`;
  const multiplier = PROTEIN_MULTIPLIERS[key] || 1.2;
  const adjusted   = isOlder ? multiplier * 1.2 : multiplier; // older adults +20%
  return {
    minG: Math.round(weightKg * multiplier),
    targetG: Math.round(weightKg * adjusted),
    maxG: Math.round(weightKg * 2.5),
    perMeal: Math.round((weightKg * adjusted) / 4), // spread across 4 meals
  };
}
```

---

## Result Output

Daily protein target in grams + per-meal suggestion + example foods list showing how to hit the target (e.g. 3 chicken breasts = 120g protein).

---

## Formula Explanation (Section 7)

Minimum: 0.8g/kg (sedentary). Active adults: 1.4-1.6g/kg. Muscle building: 1.8-2.2g/kg. Upper safe limit: ~2.5g/kg. Older adults (65+) need 20-40% more to prevent muscle loss.

---

## Content Section (Section 8)

**H2:** `Daily Protein Needs — How to Hit Your Target`

Explain protein's role in muscle repair, satiety, metabolism. How to spread intake across meals. High-protein foods list. Protein timing (around exercise). ~330 words.

---

## FAQ (Section 9)

| # | Question | Answer |
|---|---|---|
| Q1 | How much protein do I need to build muscle? | To build muscle, aim for 1.6-2.2g of protein per kilogram of body weight per day. Research shows that spreading this across 3-4 meals maximises muscle protein synthesis. |
| Q2 | Can too much protein be harmful? | For healthy adults, high protein intake up to 2.5g/kg is generally safe. People with kidney disease should consult a doctor before increasing protein intake significantly. |
| Q3 | What are the best high-protein foods? | Top sources include chicken breast (31g/100g), Greek yogurt (10g/100g), eggs (13g/100g), tuna (30g/100g), lentils (9g/100g cooked), and cottage cheese (11g/100g). |
| Q4 | Do I need protein shakes? | No — whole food sources are equally effective and more nutritious. Protein shakes are a convenient supplement when whole foods are not available, but are not necessary. |
| Q5 | Is MindSnap's Protein Calculator free? | Yes — completely free, no signup, no download. Use it instantly on any device. |

---

## Related Tools (Section 10)

1. **Macro Calculator** → `/macro-calculator`
2. **TDEE Calculator** → `/calorie-calculator`
3. **Fitness Tools** → `/fitness-tools`

---



## Claude Prompt

```
Build the Protein Calculator page for MindSnap.co.

FILE: resources/views/calculators/protein-calculator.blade.php
ROUTE: GET /protein-calculator
CATEGORY COLOUR: #28a745

SEO:
Title:    "Protein Calculator — Free Daily Protein Intake Tool | MindSnap"
Meta:     "Free protein intake calculator. Find your daily protein needs based on your weight, activity level and fitness goal. Instant results."
H1:       "Protein Calculator — How Much Protein Do You Need Daily?"
Canonical: https://mindsnap.co/protein-calculator

BUILD ALL 12 SECTIONS:
1. Breadcrumb: Home > Fitness Tools > Protein Calculator + BreadcrumbList schema
2. H1 + 2-sentence description + trust badges (Free/No Signup/Instant/Mobile Friendly)
3. INPUT FORM:
- **Body weight:** kg/lbs
- **Activity level:** Sedentary / Moderate / Active / Very Active
- **Goal:** Maintain muscle / Build muscle / Lose fat / Athletic performance
- **Age group:** Under 65 / 65+ (older adults need more)
   Labels above inputs. Units toggle where applicable.
   #e94560 Calculate button, full-width mobile, min 52px height.
4. RESULT: fadeIn animation, large result in #28a745, interpretation text
5. SHARE CARD: canvas 420x220px, Copy/WhatsApp/Download buttons
6. HOW TO USE: H2 + 4-5 numbered steps
7. FORMULA: H2 + plain English + formula in styled box
8. CONTENT: H2 "Daily Protein Needs — How to Hit Your Target" + 300-400 words + 2-3 H3 subheadings
9. FAQ: H2 + Bootstrap accordion + 5 Q&As + FAQPage JSON-LD schema
10. RELATED TOOLS: 3 cards — Macro Calculator, TDEE Calculator, Fitness Tools category page
11. CATEGORY LINK: text sentence linking back to /fitness-tools
12. SCHEMAS in @section('schema'):
    - WebApplication JSON-LD
    - BreadcrumbList JSON-LD  
    - FAQPage JSON-LD

VANILLA JS LOGIC:
const PROTEIN_MULTIPLIERS = {
  sedentary_maintain:  0.8,  // g per kg
  moderate_maintain:   1.2,
  active_maintain:     1.4,
  sedentary_loss:      1.6,
  active_loss:         2.0,
  muscle_gain:         2.0,
  athletic:            2.2,
};
function calcProtein(weightKg, activity, goal, isOlder) {
  const key = `${activity}_${goal}`;
  const multiplier = PROTEIN_MULTIPLIERS[key] || 1.2;
  const adjusted   = isOlder ? multiplier * 1.2 : multiplier; // older adults +20%
  return {
    minG: Math.round(weightKg * multiplier),
    targetG: Math.round(weightKg * adjusted),
    maxG: Math.round(weightKg * 2.5),
    perMeal: Math.round((weightKg * adjusted) / 4), // spread across 4 meals
  };
}

MOBILE: all inputs 100% width, 48px height, buttons 52px, test at 375px
PERFORMANCE: defer all JS, lazy load images
```
