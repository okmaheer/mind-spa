# 39 — Geography Quiz

**Route:** `GET /quiz/geography`  
**File:** Uses `resources/views/quizzes/quiz.blade.php` (shared template)  
**SEO Keyword:** `geography quiz online` — 900,000/month  
**H1:** `Geography Quiz — Test Your Knowledge Free`  
**Title:** `Geography Quiz — Free Online Questions | MindSnap`  
**Meta:** `Free geography quiz. Test your knowledge of countries, capitals, rivers, mountains and world geography. No signup needed.`

---

## What This Quiz Contains

Test your knowledge of countries, capitals, rivers, mountains and world geography.

- **Questions:** 10 per session (randomised from DB pool)
- **Difficulty:** Easy → Medium → Hard progression
- **Time limit:** Optional 30 seconds per question
- **Age group:** All (teens and adults)

---

## FAQ

| # | Question | Answer |
|---|---|---|
| Q1 | What is the longest river in the world? | The Nile in Africa at approximately 6,650 km, though some measurements put the Amazon first. |
| Q2 | Which country has the most time zones? | France — with 12 time zones across its overseas territories. |
| Q3 | What is the smallest country in the world? | Vatican City — with an area of just 0.44 square kilometres. |
| Q4 | Which mountain is the tallest above sea level? | Mount Everest at 8,849 metres (2023 measurement) in the Himalayas. |
| Q5 | Is this geography quiz free? | Yes — completely free, no signup, instant results. |

---

## SEO Structure

- Breadcrumb: Home > Quizzes > Geography Quiz
- Internal links: 2 related quizzes + /quizzes listing page
- Schema: BreadcrumbList + FAQPage

---

## Database Seed

Ask Claude to generate 50 geography quiz questions in the quiz_questions table format:
```
category: 'geography'
difficulty: mix of easy/medium/hard
age_group: 'all'
```

---

## Claude Prompt

```
Build the Geography Quiz page for MindSnap.co.
Route: /quiz/geography
This page uses the shared quiz.blade.php template from Feature 34.

Controller method: QuizController@show('geography')
Load 10 random questions from quiz_questions where category='geography'

SEO:
Title: "Geography Quiz — Free Online Questions | MindSnap"
Meta:  "Free geography quiz. Test your knowledge of countries, capitals, rivers, mountains and world geography. No signup."
H1:    "Geography Quiz — Test Your Knowledge Free"
Canonical: https://mindsnap.co/quiz/geography

Add to controller: $meta array with title, description, h1, colour (#e94560), keyword
Pass to quiz.blade.php view

Generate 50 seed questions for this category in QuizSeeder.php
Include: question, option_a-d, correct_option, explanation, difficulty, age_group='all'
```
