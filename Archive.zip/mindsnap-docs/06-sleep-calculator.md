# 06 — Sleep Cycle Calculator

**Route:** `GET /sleep-calculator`  
**File:** `resources/views/calculators/sleep-calculator.blade.php`  
**Category:** Sleep  
**SEO Keyword:** `sleep cycle calculator` — 2,200,000/month  

---

## SEO

| Field | Value |
|---|---|
| Title | `Sleep Cycle Calculator — Free Bedtime Tool | MindSnap` |
| Meta | `Free sleep cycle calculator. Enter your wake-up time and get perfect bedtimes based on 90-minute sleep cycles. No signup.` |
| H1 | `Sleep Cycle Calculator — Find Your Perfect Bedtime` |
| Canonical | `https://mindsnap.co/sleep-calculator` |
| Category | [Sleep Tools](/sleep-tools) |

---

## What This Page Does

Sleep Cycle Calculator page on MindSnap.co. Follows the standard 12-section tool page structure.

---

## Inputs

- **Mode toggle:** "I want to wake up at..." / "I want to go to bed at..."
- **Time input:** hour + minute selects (12hr or 24hr format)
- **Optional:** minutes to fall asleep (default 14, range 5-30)

---

## JavaScript Logic

```javascript
const CYCLE = 90; // minutes per cycle
const FALL_ASLEEP = 14; // default minutes to fall asleep

function calculate(wakeTimeMinutes, fallAsleepMinutes) {
  const results = [];
  for (let cycles = 6; cycles >= 3; cycles--) {
    const totalSleep = cycles * CYCLE;
    const bedtime = wakeTimeMinutes - totalSleep - fallAsleepMinutes;
    const normalised = ((bedtime % 1440) + 1440) % 1440; // handle past midnight
    results.push({
      bedtime: minutesToTime(normalised),
      cycles,
      hours: (totalSleep / 60).toFixed(1),
      quality: cycles >= 5 ? 'Excellent' : cycles === 4 ? 'Good' : 'Minimum'
    });
  }
  return results;
}
```

---

## Result Output

4 bedtime options shown as Bootstrap cards. Each card shows: bedtime, number of cycles, total hours, quality badge (Excellent/Good/Minimum). Recommended option (6 cycles) highlighted in category colour.

---

## Formula Explanation (Section 7)

Bedtime = Wake time − (Number of cycles × 90 min) − Fall-asleep time. Default: 5 cycles (7.5h) + 14min = 7h 44min before wake time.

---

## Content Section (Section 8)

**H2:** `Sleep Cycles: Why Timing Your Sleep Matters`

Explain 90-minute REM cycles, why waking mid-cycle feels bad, recommended cycles by age (adults 5-6), how the calculator works. ~300 words. Link to caffeine-sleep-calculator naturally.

---

## FAQ (Section 9)

| # | Question | Answer |
|---|---|---|
| Q1 | What is a sleep cycle? | A sleep cycle is approximately 90 minutes of sleep that includes light sleep, deep sleep, and REM stages. Most adults need 5-6 complete cycles per night. |
| Q2 | How accurate is this sleep calculator? | The calculator uses the standard 90-minute cycle with a 14-minute fall-asleep average. Individual times vary — adjust the fall-asleep slider for better accuracy. |
| Q3 | How many sleep cycles do I need? | Adults need 5-6 cycles (7.5-9 hours). Teens need 6-7 cycles. Children need more. Waking at the end of a cycle — rather than mid-cycle — reduces morning grogginess. |
| Q4 | What is the best time to wake up? | The best wake time is at the end of a sleep cycle. Use this calculator to find times that align with your natural cycle endpoint and stick to a consistent schedule. |
| Q5 | Is MindSnap's Sleep Cycle Calculator free? | Yes — completely free, no signup, no download. Use it instantly on any device. |

---

## Related Tools (Section 10)

1. **Caffeine Cut-Off Calculator** → `/caffeine-sleep-calculator`
2. **Sleep Debt Calculator** → `/sleep-debt-calculator`
3. **Sleep Tools** → `/sleep-tools`

---



## Claude Prompt

```
Build the Sleep Cycle Calculator page for MindSnap.co.

FILE: resources/views/calculators/sleep-calculator.blade.php
ROUTE: GET /sleep-calculator
CATEGORY COLOUR: #6c63ff

SEO:
Title:    "Sleep Cycle Calculator — Free Bedtime Tool | MindSnap"
Meta:     "Free sleep cycle calculator. Enter your wake-up time and get perfect bedtimes based on 90-minute sleep cycles. No signup."
H1:       "Sleep Cycle Calculator — Find Your Perfect Bedtime"
Canonical: https://mindsnap.co/sleep-calculator

BUILD ALL 12 SECTIONS:
1. Breadcrumb: Home > Sleep Tools > Sleep Cycle Calculator + BreadcrumbList schema
2. H1 + 2-sentence description + trust badges (Free/No Signup/Instant/Mobile Friendly)
3. INPUT FORM:
- **Mode toggle:** "I want to wake up at..." / "I want to go to bed at..."
- **Time input:** hour + minute selects (12hr or 24hr format)
- **Optional:** minutes to fall asleep (default 14, range 5-30)
   Labels above inputs. Units toggle where applicable.
   #e94560 Calculate button, full-width mobile, min 52px height.
4. RESULT: fadeIn animation, large result in #6c63ff, interpretation text
5. SHARE CARD: canvas 420x220px, Copy/WhatsApp/Download buttons
6. HOW TO USE: H2 + 4-5 numbered steps
7. FORMULA: H2 + plain English + formula in styled box
8. CONTENT: H2 "Sleep Cycles: Why Timing Your Sleep Matters" + 300-400 words + 2-3 H3 subheadings
9. FAQ: H2 + Bootstrap accordion + 5 Q&As + FAQPage JSON-LD schema
10. RELATED TOOLS: 3 cards — Caffeine Cut-Off Calculator, Sleep Debt Calculator, Sleep Tools category page
11. CATEGORY LINK: text sentence linking back to /sleep-tools
12. SCHEMAS in @section('schema'):
    - WebApplication JSON-LD
    - BreadcrumbList JSON-LD  
    - FAQPage JSON-LD

VANILLA JS LOGIC:
const CYCLE = 90; // minutes per cycle
const FALL_ASLEEP = 14; // default minutes to fall asleep

function calculate(wakeTimeMinutes, fallAsleepMinutes) {
  const results = [];
  for (let cycles = 6; cycles >= 3; cycles--) {
    const totalSleep = cycles * CYCLE;
    const bedtime = wakeTimeMinutes - totalSleep - fallAsleepMinutes;
    const normalised = ((bedtime % 1440) + 1440) % 1440; // handle past midnight
    results.push({
      bedtime: minutesToTime(normalised),
      cycles,
      hours: (totalSleep / 60).toFixed(1),
      quality: cycles >= 5 ? 'Excellent' : cycles === 4 ? 'Good' : 'Minimum'
    });
  }
  return results;
}

MOBILE: all inputs 100% width, 48px height, buttons 52px, test at 375px
PERFORMANCE: defer all JS, lazy load images
```
