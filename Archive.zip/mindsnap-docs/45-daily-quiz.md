# 45 — Daily Quiz & Daily Challenge Page

**Routes:**  
- `GET /daily-quiz` → today's quiz (uses quiz.blade.php)  
- `GET /daily` → Daily Challenge hub page  
**Controller:** `DailyController`

---

## Daily Challenge Hub Page (/daily)

**H1:** `Daily Brain Challenge — New Quiz Every Day`  
**Title:** `Daily Brain Challenge — Free Daily Quiz | MindSnap`  
**Meta:** `Free daily quiz and brain challenge. New questions every day. Build your streak. No signup.`

### 6 Sections

**1. Hero**
- Today's date (large), streak counter from localStorage, tagline

**2. Today's Quiz**
- Topic from `daily_quizzes` table, difficulty, "X played today", Start button, midnight countdown

**3. Brain Teaser**
- Riddle/logic puzzle + "Reveal Answer" Bootstrap collapse + share button

**4. Health Tip**
- From `health_tips` table (day_number = dayOfYear), category icon

**5. Streak System (localStorage)**
```javascript
const today = new Date().toDateString();
const last  = localStorage.getItem('ms_last_visit');
let streak  = parseInt(localStorage.getItem('ms_streak')||'0');
if (last === yesterday()) { streak++; }
else if (last !== today)  { streak = 1; }
localStorage.setItem('ms_streak', streak);
localStorage.setItem('ms_last_visit', today);
// Milestones: 7, 30, 100 days — CSS confetti animation
```

**6. This Week**
- 7 date cards, today highlighted #e94560, past days greyed

---

## Cron Job — Auto-generate daily quizzes

```php
// app/Console/Commands/GenerateDailyQuiz.php
// Artisan command: quiz:generate-daily
// Cron on Namecheap: 0 23 * * * php artisan quiz:generate-daily
// Picks random category, selects 10 random question IDs, saves to daily_quizzes table
```

---

## Claude Prompt

```
Build the Daily Challenge hub page and daily quiz system for MindSnap.co.

FILES:
- resources/views/daily/index.blade.php  (hub page)
- app/Http/Controllers/DailyController.php
- app/Console/Commands/GenerateDailyQuiz.php

DAILY HUB PAGE: all 6 sections as specified above
STREAK SYSTEM: localStorage, milestones at 7/30/100 days with confetti animation
CRON COMMAND: generates tomorrow's quiz at 11pm each night

CONTROLLER:
public function index() {
  $daily    = DailyQuiz::where('date', today())->first();
  $tip      = HealthTip::where('day_number', today()->dayOfYear)->first();
  $thisWeek = DailyQuiz::whereBetween('date', [now()->startOfWeek(), now()->endOfWeek()])->get();
  return view('daily.index', compact('daily','tip','thisWeek'));
}

SEO NOTE: This page updates daily = Google crawls it daily = benefits entire domain ranking.
Add structured data for daily quiz (Event schema optional).
```
