# 19 — One Rep Max Calculator

**Route:** `GET /one-rep-max-calculator`  
**File:** `resources/views/calculators/one-rep-max-calculator.blade.php`  
**Category:** Fitness  
**SEO Keyword:** `one rep max calculator` — 1,800,000/month  

---

## SEO

| Field | Value |
|---|---|
| Title | `One Rep Max Calculator — Free 1RM Estimator | MindSnap` |
| Meta | `Free one rep max calculator. Enter the weight you lifted and reps completed to estimate your 1RM for any exercise. Multiple formulas.` |
| H1 | `One Rep Max Calculator — Estimate Your 1RM` |
| Canonical | `https://mindsnap.co/one-rep-max-calculator` |
| Category | [Fitness Tools](/fitness-tools) |

---

## What This Page Does

One Rep Max Calculator page on MindSnap.co. Follows the standard 12-section tool page structure.

---

## Inputs

- **Weight lifted:** kg/lbs
- **Reps completed:** number (1-30)
- **Exercise name:** optional label for result

---

## JavaScript Logic

```javascript
// Multiple formulas — show all, average them
function calc1RM(weight, reps) {
  if (reps === 1) return weight;
  return {
    epley:    Math.round(weight * (1 + reps / 30)),
    brzycki:  Math.round(weight * (36 / (37 - reps))),
    lander:   Math.round((100 * weight) / (101.3 - 2.67123 * reps)),
    lombardi: Math.round(weight * Math.pow(reps, 0.1)),
    average:  null // calculated from above 4
  };
}
function getPercentages(oneRM) {
  return [100,95,90,85,80,75,70,65,60,55,50].map(pct => ({
    pct, weight: Math.round(oneRM * pct / 100),
    reps: pctToReps(pct)
  }));
}
```

---

## Result Output

Estimated 1RM (average of 4 formulas) + full percentage table (50%-100% of 1RM with corresponding weight and rep ranges). Useful for programming training loads.

---

## Formula Explanation (Section 7)

Epley: 1RM = weight × (1 + reps/30). Brzycki: 1RM = weight × 36/(37-reps). Average of Epley, Brzycki, Lander, Lombardi formulas for best accuracy.

---

## Content Section (Section 8)

**H2:** `How to Use Your 1RM for Training`

Explain what 1RM is, training zones (60-70% endurance, 70-80% hypertrophy, 80-90% strength, 90-100% power), why testing 1RM directly is risky for beginners. ~320 words.

---

## FAQ (Section 9)

| # | Question | Answer |
|---|---|---|
| Q1 | What is a 1 rep max? | A one rep max (1RM) is the maximum weight you can lift for a single repetition with proper form. It is used to calculate training loads across different rep ranges and programming. |
| Q2 | How accurate is this calculator? | Estimated 1RM formulas are most accurate when based on 3-10 reps. Accuracy decreases for higher rep ranges. The calculator averages four established formulas for better precision. |
| Q3 | What percentage of 1RM should I train at? | For strength: 80-90% (2-5 reps). For hypertrophy: 65-80% (6-15 reps). For endurance: 50-65% (15+ reps). Most training programs use 70-85% for a balance of strength and muscle. |
| Q4 | Should I test my 1RM directly? | Beginners should avoid direct 1RM testing as it increases injury risk. Estimated 1RM from this calculator is safer and accurate enough for programming purposes. |
| Q5 | Is MindSnap's One Rep Max Calculator free? | Yes — completely free, no signup, no download. Use it instantly on any device. |

---

## Related Tools (Section 10)

1. **Workout Volume Calculator** → `/workout-volume-calculator`
2. **BMI Calculator** → `/bmi-calculator`
3. **Fitness Tools** → `/fitness-tools`

---



## Claude Prompt

```
Build the One Rep Max Calculator page for MindSnap.co.

FILE: resources/views/calculators/one-rep-max-calculator.blade.php
ROUTE: GET /one-rep-max-calculator
CATEGORY COLOUR: #28a745

SEO:
Title:    "One Rep Max Calculator — Free 1RM Estimator | MindSnap"
Meta:     "Free one rep max calculator. Enter the weight you lifted and reps completed to estimate your 1RM for any exercise. Multiple formulas."
H1:       "One Rep Max Calculator — Estimate Your 1RM"
Canonical: https://mindsnap.co/one-rep-max-calculator

BUILD ALL 12 SECTIONS:
1. Breadcrumb: Home > Fitness Tools > One Rep Max Calculator + BreadcrumbList schema
2. H1 + 2-sentence description + trust badges (Free/No Signup/Instant/Mobile Friendly)
3. INPUT FORM:
- **Weight lifted:** kg/lbs
- **Reps completed:** number (1-30)
- **Exercise name:** optional label for result
   Labels above inputs. Units toggle where applicable.
   #e94560 Calculate button, full-width mobile, min 52px height.
4. RESULT: fadeIn animation, large result in #28a745, interpretation text
5. SHARE CARD: canvas 420x220px, Copy/WhatsApp/Download buttons
6. HOW TO USE: H2 + 4-5 numbered steps
7. FORMULA: H2 + plain English + formula in styled box
8. CONTENT: H2 "How to Use Your 1RM for Training" + 300-400 words + 2-3 H3 subheadings
9. FAQ: H2 + Bootstrap accordion + 5 Q&As + FAQPage JSON-LD schema
10. RELATED TOOLS: 3 cards — Workout Volume Calculator, BMI Calculator, Fitness Tools category page
11. CATEGORY LINK: text sentence linking back to /fitness-tools
12. SCHEMAS in @section('schema'):
    - WebApplication JSON-LD
    - BreadcrumbList JSON-LD  
    - FAQPage JSON-LD

VANILLA JS LOGIC:
// Multiple formulas — show all, average them
function calc1RM(weight, reps) {
  if (reps === 1) return weight;
  return {
    epley:    Math.round(weight * (1 + reps / 30)),
    brzycki:  Math.round(weight * (36 / (37 - reps))),
    lander:   Math.round((100 * weight) / (101.3 - 2.67123 * reps)),
    lombardi: Math.round(weight * Math.pow(reps, 0.1)),
    average:  null // calculated from above 4
  };
}
function getPercentages(oneRM) {
  return [100,95,90,85,80,75,70,65,60,55,50].map(pct => ({
    pct, weight: Math.round(oneRM * pct / 100),
    reps: pctToReps(pct)
  }));
}

MOBILE: all inputs 100% width, 48px height, buttons 52px, test at 375px
PERFORMANCE: defer all JS, lazy load images
```
