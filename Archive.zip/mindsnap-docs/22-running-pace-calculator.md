# 22 — Running Pace Calculator

**Route:** `GET /running-pace-calculator`  
**File:** `resources/views/calculators/running-pace-calculator.blade.php`  
**Category:** Fitness  
**SEO Keyword:** `running pace calculator` — 900,000/month  

---

## SEO

| Field | Value |
|---|---|
| Title | `Running Pace Calculator — Free Race Pace Tool | MindSnap` |
| Meta | `Free running pace calculator. Calculate your pace per km or mile, target finish time, or training splits for 5K, 10K, half marathon and marathon.` |
| H1 | `Running Pace Calculator — Find Your Target Pace` |
| Canonical | `https://mindsnap.co/running-pace-calculator` |
| Category | [Fitness Tools](/fitness-tools) |

---

## What This Page Does

Running Pace Calculator page on MindSnap.co. Follows the standard 12-section tool page structure.

---

## Inputs

- **Mode toggle:** Calculate pace / Calculate finish time / Calculate distance
- **Distance:** km/miles (or race preset: 5K, 10K, Half, Full)
- **Time:** hours + minutes + seconds
- **Units:** km/miles toggle

---

## JavaScript Logic

```javascript
function calcPace(distanceKm, totalSeconds) {
  const paceSecPerKm = totalSeconds / distanceKm;
  return {
    pacePerKm: secondsToMMSS(paceSecPerKm),
    pacePerMile: secondsToMMSS(paceSecPerKm * 1.60934),
    speedKph: +(distanceKm / (totalSeconds / 3600)).toFixed(1),
    splits: generateSplits(distanceKm, paceSecPerKm)
  };
}
function calcFinishTime(distanceKm, paceSecPerKm) {
  return secondsToHHMMSS(distanceKm * paceSecPerKm);
}
```

---

## Result Output

Pace per km and per mile, finish time, speed in km/h and mph, kilometre/mile splits table. Option to print splits for race day.

---

## Formula Explanation (Section 7)

Pace (min/km) = total time (seconds) ÷ distance (km) ÷ 60. Finish time = pace (sec/km) × distance. Speed (km/h) = distance ÷ time (hours).

---

## Content Section (Section 8)

**H2:** `How to Use Pace for Better Running`

Explain easy pace vs race pace, how to set realistic goals, negative splits strategy, pacing by effort vs HR vs GPS. ~320 words.

---

## FAQ (Section 9)

| # | Question | Answer |
|---|---|---|
| Q1 | What is a good running pace? | A good pace depends entirely on your fitness level and goals. Average recreational runners run 5K at 6-8 min/km. Elite runners average under 3:30/km. Focus on your own improvement. |
| Q2 | What is a negative split? | A negative split means running the second half of a race faster than the first. Most race records are set with negative splits as it prevents early burnout and allows finishing strong. |
| Q3 | How do I calculate my pace for a race goal? | Divide your goal finish time by the race distance. For example, a 25-minute 5K target = 25 ÷ 5 = 5:00 min/km pace. This calculator does that automatically for any distance. |
| Q4 | What pace should I run my long runs at? | Long runs should be run at 60-75% of maximum effort — roughly 60-90 seconds per km slower than your 10K pace. The goal is building aerobic base and time on feet, not speed. |
| Q5 | Is MindSnap's Running Pace Calculator free? | Yes — completely free, no signup, no download. Use it instantly on any device. |

---

## Related Tools (Section 10)

1. **Heart Rate Zone Calculator** → `/heart-rate-calculator`
2. **One Rep Max Calculator** → `/one-rep-max-calculator`
3. **Fitness Tools** → `/fitness-tools`

---



## Claude Prompt

```
Build the Running Pace Calculator page for MindSnap.co.

FILE: resources/views/calculators/running-pace-calculator.blade.php
ROUTE: GET /running-pace-calculator
CATEGORY COLOUR: #28a745

SEO:
Title:    "Running Pace Calculator — Free Race Pace Tool | MindSnap"
Meta:     "Free running pace calculator. Calculate your pace per km or mile, target finish time, or training splits for 5K, 10K, half marathon and marathon."
H1:       "Running Pace Calculator — Find Your Target Pace"
Canonical: https://mindsnap.co/running-pace-calculator

BUILD ALL 12 SECTIONS:
1. Breadcrumb: Home > Fitness Tools > Running Pace Calculator + BreadcrumbList schema
2. H1 + 2-sentence description + trust badges (Free/No Signup/Instant/Mobile Friendly)
3. INPUT FORM:
- **Mode toggle:** Calculate pace / Calculate finish time / Calculate distance
- **Distance:** km/miles (or race preset: 5K, 10K, Half, Full)
- **Time:** hours + minutes + seconds
- **Units:** km/miles toggle
   Labels above inputs. Units toggle where applicable.
   #e94560 Calculate button, full-width mobile, min 52px height.
4. RESULT: fadeIn animation, large result in #28a745, interpretation text
5. SHARE CARD: canvas 420x220px, Copy/WhatsApp/Download buttons
6. HOW TO USE: H2 + 4-5 numbered steps
7. FORMULA: H2 + plain English + formula in styled box
8. CONTENT: H2 "How to Use Pace for Better Running" + 300-400 words + 2-3 H3 subheadings
9. FAQ: H2 + Bootstrap accordion + 5 Q&As + FAQPage JSON-LD schema
10. RELATED TOOLS: 3 cards — Heart Rate Zone Calculator, One Rep Max Calculator, Fitness Tools category page
11. CATEGORY LINK: text sentence linking back to /fitness-tools
12. SCHEMAS in @section('schema'):
    - WebApplication JSON-LD
    - BreadcrumbList JSON-LD  
    - FAQPage JSON-LD

VANILLA JS LOGIC:
function calcPace(distanceKm, totalSeconds) {
  const paceSecPerKm = totalSeconds / distanceKm;
  return {
    pacePerKm: secondsToMMSS(paceSecPerKm),
    pacePerMile: secondsToMMSS(paceSecPerKm * 1.60934),
    speedKph: +(distanceKm / (totalSeconds / 3600)).toFixed(1),
    splits: generateSplits(distanceKm, paceSecPerKm)
  };
}
function calcFinishTime(distanceKm, paceSecPerKm) {
  return secondsToHHMMSS(distanceKm * paceSecPerKm);
}

MOBILE: all inputs 100% width, 48px height, buttons 52px, test at 375px
PERFORMANCE: defer all JS, lazy load images
```
