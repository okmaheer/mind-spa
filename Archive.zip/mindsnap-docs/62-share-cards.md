# 62 — Shareable Result Cards

Every calculator and quiz result generates a shareable image card using the HTML Canvas API.

---

## Canvas Card Spec (420×220px)

```
┌────────────────────────────────────────┐
│ 🧠 MindSnap.co                         │ ← white text on dark gradient
├────────────────────────────────────────┤
│                                        │
│   [Large result: e.g. "8/10"]         │ ← category colour
│   [Tool/Quiz Name]                    │
│   [Short result text]                 │
│                                        │
├────────────────────────────────────────┤
│ mindsnap.co                  [URL]    │ ← footer bar
└────────────────────────────────────────┘
```

---

## Canvas Generation Code

```javascript
function generateShareCard(type, data) {
  const canvas = document.getElementById('share-canvas');
  const ctx    = canvas.getContext('2d');
  canvas.width = 420; canvas.height = 220;

  // Background gradient
  const grad = ctx.createLinearGradient(0,0,420,220);
  grad.addColorStop(0, '#1a1a2e');
  grad.addColorStop(1, '#0f3460');
  ctx.fillStyle = grad;
  ctx.fillRect(0,0,420,220);

  // Top bar
  ctx.fillStyle = categoryColour(data.category);
  ctx.fillRect(0,0,420,6);

  // Logo
  ctx.fillStyle = 'rgba(255,255,255,0.6)';
  ctx.font = '14px Inter, sans-serif';
  ctx.fillText('🧠 MindSnap.co', 20, 30);

  // Main result
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 52px Inter, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(data.result, 210, 120);

  // Subtitle
  ctx.font = '16px Inter, sans-serif';
  ctx.fillStyle = 'rgba(255,255,255,0.8)';
  ctx.fillText(data.subtitle, 210, 150);

  // CTA
  ctx.font = '13px Inter, sans-serif';
  ctx.fillStyle = 'rgba(255,255,255,0.5)';
  ctx.fillText('Can you beat me? mindsnap.co', 210, 190);
}
```

---

## Share Buttons

```javascript
// 1. Copy link
document.getElementById('copy-btn').addEventListener('click', () => {
  navigator.clipboard.writeText(window.location.href);
  showToast('Link copied!');
});

// 2. WhatsApp
document.getElementById('whatsapp-btn').addEventListener('click', () => {
  window.open(`https://wa.me/?text=${encodeURIComponent(shareText + ' ' + window.location.href)}`);
});

// 3. Download image
document.getElementById('download-btn').addEventListener('click', () => {
  const link = document.createElement('a');
  link.download = 'mindsnap-result.png';
  link.href = canvas.toDataURL();
  link.click();
});

// 4. Mobile native share
if (navigator.share) {
  document.getElementById('native-share-btn').classList.remove('d-none');
  document.getElementById('native-share-btn').addEventListener('click', () => {
    navigator.share({ title: 'MindSnap Result', text: shareText, url: location.href });
  });
}
```

---

## Claude Prompt

```
Build the share card system as a reusable Blade component for MindSnap.co.

FILE: resources/views/components/share-card.blade.php

COMPONENT ACCEPTS:
- $result (the main value: "8/10", "23.4", "87 WPM")
- $subtitle (tool name or quiz name)
- $shareText (pre-written share message)
- $category (for colour coding)

CANVAS: 420×220px, dark gradient background, category colour accent bar
BUTTONS: Copy Link, WhatsApp, Download PNG, Native Share (if supported)
SHOW/HIDE: Hidden by default. Reveal with fadeIn when result is calculated.

Include this component in every calculator and quiz page:
<x-share-card :result="null" :subtitle="'Sleep Calculator'" :category="'sleep'" />
JavaScript populates result after calculation.
```
