# 27 — Age Calculator

**Route:** `GET /age-calculator`  
**File:** `resources/views/calculators/age-calculator.blade.php`  
**Category:** Life  
**SEO Keyword:** `how old am i exactly` — 1,800,000/month  

---

## SEO

| Field | Value |
|---|---|
| Title | `Age Calculator — Exact Age in Years, Months & Days | MindSnap` |
| Meta | `Free age calculator. Find your exact age in years, months, days, hours and minutes. Also shows your next birthday countdown and day you were born.` |
| H1 | `Age Calculator — How Old Am I Exactly?` |
| Canonical | `https://mindsnap.co/age-calculator` |
| Category | [Life Tools](/life-tools) |

---

## What This Page Does

Age Calculator page on MindSnap.co. Follows the standard 12-section tool page structure.

---

## Inputs

- **Date of birth:** date picker (day / month / year)
- **Calculate age as of:** today (default) or a specific date

---

## JavaScript Logic

```javascript
function calcAge(dob, asOfDate) {
  const diff = asOfDate - dob;
  const years  = asOfDate.getFullYear() - dob.getFullYear();
  const months = asOfDate.getMonth() - dob.getMonth();
  const days   = asOfDate.getDate() - dob.getDate();
  // Adjust for negative months/days
  const adjusted = adjustAge(years, months, days);
  const totalDays  = Math.floor(diff / 86400000);
  const totalHours = Math.floor(diff / 3600000);
  const nextBirthday = calcNextBirthday(dob, asOfDate);
  const dayBorn = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'][dob.getDay()];
  return { ...adjusted, totalDays, totalHours, nextBirthday, dayBorn };
}
```

---

## Result Output

Exact age in years/months/days, total days alive, total hours alive (live counter), day of week born, next birthday countdown (days + a fun fact about birthday month).

---

## Formula Explanation (Section 7)

Age = difference between DOB and today broken into years, months, and days accounting for leap years and varying month lengths.

---

## Content Section (Section 8)

**H2:** `Fun Facts About Your Age`

Explain leap year calculation, famous people born on same date option, historical events on birth date, what was #1 song the week they were born (fun idea). ~280 words.

---

## FAQ (Section 9)

| # | Question | Answer |
|---|---|---|
| Q1 | How is exact age calculated? | Exact age is calculated by finding the difference between your date of birth and today's date, accounting for varying month lengths and leap years to give years, months, and remaining days. |
| Q2 | How do leap years affect age calculation? | People born on February 29 (leap day) legally celebrate their birthday on February 28 or March 1 in non-leap years, depending on country. This calculator handles leap years correctly. |
| Q3 | Can I calculate someone else's age? | Yes — simply enter their date of birth. You can also use the 'as of date' option to calculate how old someone will be on a future date or how old they were on a past date. |
| Q4 | What is the oldest confirmed human age? | The oldest verified human age is 122 years and 164 days, achieved by Jeanne Calment of France (1875-1997). The current world's oldest living person is typically in their 115-120s. |
| Q5 | Is MindSnap's Age Calculator free? | Yes — completely free, no signup, no download. Use it instantly on any device. |

---

## Related Tools (Section 10)

1. **Days Between Dates** → `/days-between-dates`
2. **Retirement Countdown** → `/retirement-calculator`
3. **Life Tools** → `/life-tools`

---



## Claude Prompt

```
Build the Age Calculator page for MindSnap.co.

FILE: resources/views/calculators/age-calculator.blade.php
ROUTE: GET /age-calculator
CATEGORY COLOUR: #6f42c1

SEO:
Title:    "Age Calculator — Exact Age in Years, Months & Days | MindSnap"
Meta:     "Free age calculator. Find your exact age in years, months, days, hours and minutes. Also shows your next birthday countdown and day you were born."
H1:       "Age Calculator — How Old Am I Exactly?"
Canonical: https://mindsnap.co/age-calculator

BUILD ALL 12 SECTIONS:
1. Breadcrumb: Home > Life Tools > Age Calculator + BreadcrumbList schema
2. H1 + 2-sentence description + trust badges (Free/No Signup/Instant/Mobile Friendly)
3. INPUT FORM:
- **Date of birth:** date picker (day / month / year)
- **Calculate age as of:** today (default) or a specific date
   Labels above inputs. Units toggle where applicable.
   #e94560 Calculate button, full-width mobile, min 52px height.
4. RESULT: fadeIn animation, large result in #6f42c1, interpretation text
5. SHARE CARD: canvas 420x220px, Copy/WhatsApp/Download buttons
6. HOW TO USE: H2 + 4-5 numbered steps
7. FORMULA: H2 + plain English + formula in styled box
8. CONTENT: H2 "Fun Facts About Your Age" + 300-400 words + 2-3 H3 subheadings
9. FAQ: H2 + Bootstrap accordion + 5 Q&As + FAQPage JSON-LD schema
10. RELATED TOOLS: 3 cards — Days Between Dates, Retirement Countdown, Life Tools category page
11. CATEGORY LINK: text sentence linking back to /life-tools
12. SCHEMAS in @section('schema'):
    - WebApplication JSON-LD
    - BreadcrumbList JSON-LD  
    - FAQPage JSON-LD

VANILLA JS LOGIC:
function calcAge(dob, asOfDate) {
  const diff = asOfDate - dob;
  const years  = asOfDate.getFullYear() - dob.getFullYear();
  const months = asOfDate.getMonth() - dob.getMonth();
  const days   = asOfDate.getDate() - dob.getDate();
  // Adjust for negative months/days
  const adjusted = adjustAge(years, months, days);
  const totalDays  = Math.floor(diff / 86400000);
  const totalHours = Math.floor(diff / 3600000);
  const nextBirthday = calcNextBirthday(dob, asOfDate);
  const dayBorn = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'][dob.getDay()];
  return { ...adjusted, totalDays, totalHours, nextBirthday, dayBorn };
}

MOBILE: all inputs 100% width, 48px height, buttons 52px, test at 375px
PERFORMANCE: defer all JS, lazy load images
```
