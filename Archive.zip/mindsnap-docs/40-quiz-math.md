# 40 — Math Quiz

**Route:** `GET /quiz/math`  
**File:** Uses `resources/views/quizzes/quiz.blade.php` (shared template)  
**SEO Keyword:** `math quiz questions` — 1,200,000/month  
**H1:** `Math Quiz — Test Your Knowledge Free`  
**Title:** `Math Quiz — Free Online Questions | MindSnap`  
**Meta:** `Free math quiz. Test your maths skills with problems covering arithmetic, algebra, geometry and logic. No signup needed.`

---

## What This Quiz Contains

Test your maths skills with problems covering arithmetic, algebra, geometry and logic.

- **Questions:** 10 per session (randomised from DB pool)
- **Difficulty:** Easy → Medium → Hard progression
- **Time limit:** Optional 30 seconds per question
- **Age group:** All (teens and adults)

---

## FAQ

| # | Question | Answer |
|---|---|---|
| Q1 | What is 15% of 200? | 30 — calculated as 200 × 0.15 = 30. |
| Q2 | What is the square root of 144? | 12 — because 12 × 12 = 144. |
| Q3 | How many sides does a hexagon have? | 6 — from the Greek 'hex' meaning six. |
| Q4 | What is the value of Pi to 2 decimal places? | 3.14 — Pi is approximately 3.14159265... |
| Q5 | Is this math quiz free? | Yes — completely free, no signup, instant results. |

---

## SEO Structure

- Breadcrumb: Home > Quizzes > Math Quiz
- Internal links: 2 related quizzes + /quizzes listing page
- Schema: BreadcrumbList + FAQPage

---

## Database Seed

Ask Claude to generate 50 math quiz questions in the quiz_questions table format:
```
category: 'math'
difficulty: mix of easy/medium/hard
age_group: 'all'
```

---

## Claude Prompt

```
Build the Math Quiz page for MindSnap.co.
Route: /quiz/math
This page uses the shared quiz.blade.php template from Feature 34.

Controller method: QuizController@show('math')
Load 10 random questions from quiz_questions where category='math'

SEO:
Title: "Math Quiz — Free Online Questions | MindSnap"
Meta:  "Free math quiz. Test your maths skills with problems covering arithmetic, algebra, geometry and logic. No signup."
H1:    "Math Quiz — Test Your Knowledge Free"
Canonical: https://mindsnap.co/quiz/math

Add to controller: $meta array with title, description, h1, colour (#e94560), keyword
Pass to quiz.blade.php view

Generate 50 seed questions for this category in QuizSeeder.php
Include: question, option_a-d, correct_option, explanation, difficulty, age_group='all'
```
