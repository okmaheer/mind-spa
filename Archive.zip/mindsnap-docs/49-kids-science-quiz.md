# 49 — Kids Science Quiz

**Route:** `GET /kids/science-quiz`  
**File:** `resources/views/kids/science-quiz.blade.php`  
**SEO Keyword:** `science quiz for kids`  
**H1:** `Kids Science Quiz — Free Games for Kids`  
**Title:** `Kids Science Quiz — Free Online | MindSnap Kids Zone`  
**Meta:** `Free kids science quiz for children. Fun science questions about animals, plants, space, weather and the human body for kids. Safe, ad-free, no accounts.`

---

## What This Page Is

Fun science questions about animals, plants, space, weather and the human body for kids.

### Age Differentiation
Ages 5-7: animals and nature. Ages 8-10: human body and space. Ages 11-12: chemistry and physics basics.

---

## Features

Multiple choice with images described in alt text. 'Did you know?' facts after each answer. No timer.

---

## Kids Zone Design Rules Apply
- Minimum 18px font
- Minimum 48×48px tap targets
- No ads
- Encouraging messages only (no "Wrong!" — use "Great try! The answer was...")
- Stars rating instead of percentage
- Large colourful buttons

---

## Claude Prompt

```
Build the Kids Science Quiz page for MindSnap.co Kids Zone.

FILE: resources/views/kids/science-quiz.blade.php
ROUTE: GET /kids/science-quiz

DESIGN RULES: min 18px font, 48×48px tap targets, NO ads, encouraging messages, star rating.

Content: Multiple choice with images described in alt text. 'Did you know?' facts after each answer. No timer.
Age selector inherited from Kids Zone home (localStorage key 'ms_kid_age').
Filter difficulty based on age selection.

SEO:
Title: "Kids Science Quiz — Free Online | MindSnap Kids Zone"
Meta: "Free kids science quiz for children. Fun science questions about animals, plants, space, weather and the human body for kids. Safe, ad-free."
H1: "Kids Science Quiz — Free Games for Kids"
Internal links: Kids Zone home + 2 related kids activities
FAQPage schema with questions parents ask.
```
