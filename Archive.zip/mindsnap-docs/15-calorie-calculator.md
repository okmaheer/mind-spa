# 15 — TDEE Calculator

**Route:** `GET /calorie-calculator`  
**File:** `resources/views/calculators/calorie-calculator.blade.php`  
**Category:** Fitness  
**SEO Keyword:** `tdee calculator` — 3,500,000/month  

---

## SEO

| Field | Value |
|---|---|
| Title | `TDEE Calculator — Free Daily Calorie Calculator | MindSnap` |
| Meta | `Free TDEE calculator. Find your Total Daily Energy Expenditure based on age, weight, height and activity. Includes calorie goals for weight loss and gain.` |
| H1 | `TDEE Calculator — Find Your Daily Calorie Needs` |
| Canonical | `https://mindsnap.co/calorie-calculator` |
| Category | [Fitness Tools](/fitness-tools) |

---

## What This Page Does

TDEE Calculator page on MindSnap.co. Follows the standard 12-section tool page structure.

---

## Inputs

- **Age:** number input
- **Gender:** Male / Female
- **Weight:** kg/lbs toggle
- **Height:** cm / ft+in toggle
- **Activity level:** Sedentary / Lightly Active / Moderately Active / Very Active / Extremely Active

---

## JavaScript Logic

```javascript
// Mifflin-St Jeor BMR
function calcBMR(weightKg, heightCm, age, gender) {
  const base = (10 * weightKg) + (6.25 * heightCm) - (5 * age);
  return gender === 'male' ? base + 5 : base - 161;
}
const ACTIVITY = {
  sedentary:1.2, lightly_active:1.375, moderately_active:1.55, very_active:1.725, extremely_active:1.9
};
function calcTDEE(bmr, activity) { return Math.round(bmr * ACTIVITY[activity]); }
function getGoals(tdee) {
  return { maintain:tdee, mild_loss:tdee-250, weight_loss:tdee-500,
           aggressive:tdee-750, mild_gain:tdee+250, weight_gain:tdee+500 };
}
function getMacros(calories, goal='balanced') {
  // 40% protein, 30% carbs, 30% fat for weight loss
  return { protein:Math.round(calories*0.30/4), carbs:Math.round(calories*0.40/4), fat:Math.round(calories*0.30/9) };
}
```

---

## Result Output

5 calorie goal cards (Maintain / Mild Loss / Weight Loss / Aggressive Loss / Weight Gain) each showing daily calories and a macro breakdown bar (protein/carb/fat grams).

---

## Formula Explanation (Section 7)

BMR (Mifflin-St Jeor) = (10×weight) + (6.25×height) - (5×age) + 5 (male) or -161 (female). TDEE = BMR × activity multiplier (1.2 to 1.9).

---

## Content Section (Section 8)

**H2:** `Understanding Your TDEE — The Foundation of Weight Management`

Explain BMR vs TDEE, why activity level is the biggest variable, how to use TDEE for weight goals, common mistakes (eating too little). ~350 words.

---

## FAQ (Section 9)

| # | Question | Answer |
|---|---|---|
| Q1 | What is TDEE? | TDEE (Total Daily Energy Expenditure) is the total calories you burn in a day including all activity. It is calculated from your BMR (calories burned at rest) multiplied by your activity level. |
| Q2 | How accurate is this TDEE calculator? | The Mifflin-St Jeor formula is the most validated equation for estimating TDEE, accurate within 10% for most people. Individual metabolism varies — treat the result as a starting point. |
| Q3 | How many calories should I eat to lose weight? | A deficit of 500 calories per day below your TDEE creates approximately 0.5kg of fat loss per week. Do not eat fewer than 1200 calories (women) or 1500 calories (men) without medical supervision. |
| Q4 | Should I eat my TDEE to maintain weight? | Yes — eating at your TDEE means consuming the same calories you burn, maintaining your current weight. Consistently eating below TDEE causes weight loss; above causes weight gain. |
| Q5 | Is MindSnap's TDEE Calculator free? | Yes — completely free, no signup, no download. Use it instantly on any device. |

---

## Related Tools (Section 10)

1. **Calorie Deficit Calculator** → `/calorie-deficit-calculator`
2. **Macro Calculator** → `/macro-calculator`
3. **Fitness Tools** → `/fitness-tools`

---



## Claude Prompt

```
Build the TDEE Calculator page for MindSnap.co.

FILE: resources/views/calculators/calorie-calculator.blade.php
ROUTE: GET /calorie-calculator
CATEGORY COLOUR: #28a745

SEO:
Title:    "TDEE Calculator — Free Daily Calorie Calculator | MindSnap"
Meta:     "Free TDEE calculator. Find your Total Daily Energy Expenditure based on age, weight, height and activity. Includes calorie goals for weight loss and gain."
H1:       "TDEE Calculator — Find Your Daily Calorie Needs"
Canonical: https://mindsnap.co/calorie-calculator

BUILD ALL 12 SECTIONS:
1. Breadcrumb: Home > Fitness Tools > TDEE Calculator + BreadcrumbList schema
2. H1 + 2-sentence description + trust badges (Free/No Signup/Instant/Mobile Friendly)
3. INPUT FORM:
- **Age:** number input
- **Gender:** Male / Female
- **Weight:** kg/lbs toggle
- **Height:** cm / ft+in toggle
- **Activity level:** Sedentary / Lightly Active / Moderately Active / Very Active / Extremely Active
   Labels above inputs. Units toggle where applicable.
   #e94560 Calculate button, full-width mobile, min 52px height.
4. RESULT: fadeIn animation, large result in #28a745, interpretation text
5. SHARE CARD: canvas 420x220px, Copy/WhatsApp/Download buttons
6. HOW TO USE: H2 + 4-5 numbered steps
7. FORMULA: H2 + plain English + formula in styled box
8. CONTENT: H2 "Understanding Your TDEE — The Foundation of Weight Management" + 300-400 words + 2-3 H3 subheadings
9. FAQ: H2 + Bootstrap accordion + 5 Q&As + FAQPage JSON-LD schema
10. RELATED TOOLS: 3 cards — Calorie Deficit Calculator, Macro Calculator, Fitness Tools category page
11. CATEGORY LINK: text sentence linking back to /fitness-tools
12. SCHEMAS in @section('schema'):
    - WebApplication JSON-LD
    - BreadcrumbList JSON-LD  
    - FAQPage JSON-LD

VANILLA JS LOGIC:
// Mifflin-St Jeor BMR
function calcBMR(weightKg, heightCm, age, gender) {
  const base = (10 * weightKg) + (6.25 * heightCm) - (5 * age);
  return gender === 'male' ? base + 5 : base - 161;
}
const ACTIVITY = {
  sedentary:1.2, lightly_active:1.375, moderately_active:1.55, very_active:1.725, extremely_active:1.9
};
function calcTDEE(bmr, activity) { return Math.round(bmr * ACTIVITY[activity]); }
function getGoals(tdee) {
  return { maintain:tdee, mild_loss:tdee-250, weight_loss:tdee-500,
           aggressive:tdee-750, mild_gain:tdee+250, weight_gain:tdee+500 };
}
function getMacros(calories, goal='balanced') {
  // 40% protein, 30% carbs, 30% fat for weight loss
  return { protein:Math.round(calories*0.30/4), carbs:Math.round(calories*0.40/4), fat:Math.round(calories*0.30/9) };
}

MOBILE: all inputs 100% width, 48px height, buttons 52px, test at 375px
PERFORMANCE: defer all JS, lazy load images
```
