# 53 — Reaction Time Test

**Route:** `GET /reaction-time-test`  
**File:** `resources/views/games/reaction-time-test.blade.php`  
**SEO Keyword:** `reaction time test` — 800,000/month  
**H1:** `Reaction Time Test — Measure reaction time in milliseconds across 5 rounds with population comparison`  
**Title:** `Reaction Time Test — Free Online | MindSnap`  
**Meta:** `Free reaction time test. Measure reaction time in milliseconds across 5 rounds with population comparison. No signup, play instantly.`

---

## What This Game Does

Measure reaction time in milliseconds across 5 rounds with population comparison.

---

## JavaScript Logic

```javascript
// Full-width coloured box starts red
// After random delay (2-7 seconds) turns green
// Record ms from green to click
// Anti-cheat: if clicked before green = "Too early!" restart round
// 5 rounds, show average
const RATINGS = [{max:200,'Superhuman'},{max:250,'Pro Athlete'},{max:300,'Above Average'},{max:350,'Average'},{max:999,'Below Average'}];
```

---

## Result Display

5 round results table, average in ms, category badge, comparison chart. Share card: 'My reaction time is 243ms — I am Above Average!'

---

## SEO Structure
- Breadcrumb: Home > Games > Reaction Time Test
- Internal links: 2 related games + /games category page
- Schema: WebApplication + FAQPage

---

## Claude Prompt

```
Build the Reaction Time Test for MindSnap.co.

FILE: resources/views/games/reaction-time-test.blade.php
ROUTE: GET /reaction-time-test
CATEGORY COLOUR: #ffc107

SEO:
Title: "Reaction Time Test — Free Online | MindSnap"
Meta:  "Free reaction time test. Measure reaction time in milliseconds across 5 rounds with population comparison. No signup."
H1:    "Reaction Time Test — Measure reaction time in milliseconds across 5 rounds with population comparison"

GAME LOGIC (Vanilla JS):
// Full-width coloured box starts red
// After random delay (2-7 seconds) turns green
// Record ms from green to click
// Anti-cheat: if clicked before green = "Too early!" restart round
// 5 rounds, show average
const RATINGS = [{max:200,'Superhuman'},{max:250,'Pro Athlete'},{max:300,'Above Average'},{max:350,'Average'},{max:999,'Below Average'}];

RESULT:
5 round results table, average in ms, category badge, comparison chart. Share card: 'My reaction time is 243ms — I am Above Average!'

SHARE CARD: Canvas 420×220px with result + mindsnap.co URL
Share buttons: Copy, WhatsApp, Download image

BUILD 12 SECTIONS (standard tool page structure):
1.Breadcrumb 2.H1+badges 3.Game interface 4.Score/result
5.Share card 6.How to play 7.About the test 8.Content 300w
9.FAQ+schema 10.Related games 11.Category link 12.Schemas

MOBILE: Large tap targets (min 48px), works on touchscreen, no horizontal scroll
```
